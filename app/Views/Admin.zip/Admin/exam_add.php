<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>

<?php
	if(isset($info)){

			$header = 'Edit Exam';
			$id = $info->eid;
			$exam_name = $info->exam_name;
			$short_name = $info->short_name;
			$term_id = $info->term_id;
			$session_id = $info->session_id;
			
			$exam_start_date = DateTime::createFromFormat('Y-m-d',$info->exam_start_date);
	        $exam_start_date = $exam_start_date->format('d/m/Y');				
			
			$exam_end_date = DateTime::createFromFormat('Y-m-d',$info->exam_end_date);
	        $exam_end_date = $exam_end_date->format('d/m/Y');
			
			$campus_id = $sessionData['campusid'];
			//$session_id = $sessionData['sessionid'];

	}else{
			$header = 'Add Exam';
			$id = '';
			$exam_name = '';
			$short_name = '';
			$term_id = '';
			$session_id = '';
			$exam_start_date = '';
			$exam_end_date = '';
			$status = 1;
			$campus_id = $sessionData['campusid'];
			$session_id = $sessionData['sessionid'];
		}
	?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
           Exam
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Exam</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
       	<div class="card-header p-0 pt-1 border-bottom-0">
        <ul class="nav nav-tabs">
          <li class="nav-item"><a class="nav-link" href="<?php echo '#/exam';?>">Exams</a></li>
          <?php if($id == ''){ ?>
          <li class="nav-item"><a class="nav-link active" href="<?php echo '#/exam?m=add';?>"><?php echo $header;?></a></li>
          <?php }else{ ?>
          <li class="nav-item"><a class="nav-link active" href="<?php echo '#/exam?m=edit&id=' . $id;?>"><?php echo $header;?></a></li>
          <?php } ?>
        </ul>
        <div class="card-body">
        <div class="tab-content">
          <?php
			echo form_open('c=exam&m=save', 'role="form" id="user-edit-form"');
			echo form_hidden('id', $id);
			echo form_hidden('campus_id', $campus_id);
			?>
        <div id="exam_list">  
        <div class="">  
       	<div class="row">
				<div class="col-lg-4">
					<div class="form-group">
						<label for="exam_name">Exam Name</label>
						<input type="text" name="exam_name"  value="<?php echo $exam_name; ?>" placeholder="Exam Name" class="form-control "  />
					</div>
				</div>
				<div class="col-lg-4">
					<div class="form-group">
						<label for="short_name">Short Name</label>
						<input type="text" name="short_name"value="<?php echo $short_name; ?>" placeholder="Short Name" class="form-control"  />
					</div>
         		</div>
         		<div class="col-lg-4">
         			<div class="form-group">
         				<label for="term_id">Term</label>
	         			<select name="term_session_id" id="term_session_id" class="form-control">
	         				<option value="">Select Term</option>';
	         				<?php foreach($termsinfo as $terminfo){	?>
	         					<option value="<?php echo $terminfo['term_session_id']; ?>"
	         						<?php if($terminfo['term_session_id'] == $term_id){ 
	         							echo 'selected="selected"';
	         						} ?>
	         					>
	         					<?php echo $terminfo['name']; ?>
	         					</option>
	         				<?php } ?>
	         			</select>
         			</div>
         		</div>
         		<div class="col-lg-12" id="dateRange">
         		</div>
         	</div>
     </div>
 </div>	
<div class="form-group">
    <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
    <button type="reset" class="btn btn-default">Reset</button>
    <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
</div>
<?php echo form_close();?> </div>
      </div>
    </div>
  </div>
  </div>
  </div>
</section>
<!-- /.content -->
<script type="text/javascript">
$(function(){

$("#term_session_id").change(function(){
        var term_session_id = $('#term_session_id').val();
         $.ajax({
            url:'<?php echo site_url('c=exam&m=getDateRange');?>', 
            type: "POST",
            data:{term_session_id:term_session_id },
            success:function(res){
            	//console.log(res);
 			   $("#dateRange").html(res);
 			   $("#loader-1").css("display", "none");
			 }
         });
    });

	$('#user-edit-form').validate({
		rules:{
			exam_name:{
				required:true,

			},
			exam_start_date:{
				required:true,
			}
		},
		messages:{
			exam_name:{
				required:'Exam Name is Required',
			},
			exam_start_date:{
				required:'Exam start date is Required',
				remote:'Exam start date is exists'
			}
		}
	});
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			return $('#user-edit-form').valid();
			$('#submitBtn').html("Saving");
      		$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
			$('#submitBtn').html("Save");
      		$('#submitBtn').prop('disabled', false);
			var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
				<?php
				if($id == ''){
					?>
					location.href = '#/exam';
					<?php
				}else{
					?>
					location.href = '#/exam?m=edit&id=<?php echo $id;?>&after=edit';
					<?php
				}
				?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
});
</script>
<?= $this->endSection() ?>