<html dir="rtl" lang="ur">
<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>
<link rel="stylesheet" href="<?= base_url('resource/bootstrap-switch/css/bootstrap3/bootstrap-switch.min.css') ?>" />
<style>
@media print {
  .pagebreak { page-break-before: always; }
  #user-edit-form { display: none; }
}
.chalanwrapper { border: 1px solid #000000; text-align: center; float: left; width: 100%; font-size: 15px; line-height: 22px; }
th, td { text-align: left; padding-left: 10px; }
.chalanrows { border-bottom: 1px solid #000000; padding-left: 10px; }
.feeinfo { font-size: 12px; border: 1px solid #000000; border-bottom: none; margin: 3px; float: left; width: 98%; line-height: 25px; }
.chalancolleft, .chalancolright { border-bottom: 1px solid #000000; width: 50%; float: left; padding-left: 10px; text-align: left; }
.feetable { margin: 3px; line-height: 25px; text-align: left; padding-left: 10px; font-size: 13px; }
</style>
<?php
$cls_sec_id = $cls_sec_id ?? '';
$fee_month = $fee_month ?? '';
$fine_after_due_date = $fine_after_due_date ?? '';
$footer_line1 = $footer_line1 ?? '';
$show_line1 = $show_line1 ?? '';
$footer_line2 = $footer_line2 ?? '';
$show_line2 = $show_line2 ?? '';
?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Fee Chalan</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
          <li class="breadcrumb-item active">Fee Chalan</li>
        </ol>
      </div>
    </div>
  </div>
</section>
<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <form action="<?= base_url('admin/fee-chalan/pdf') ?>" id="user-edit-form" method="get">
        <div class="row">
          <div class="col-lg-4 form-group">
            <label>Fee Month:</label>
            <input type="month" class="form-control" name="fee_month" value="<?= esc($fee_month) ?>">
          </div>
          <div class="col-lg-4 form-group">
            <label><strong>Class</strong></label>
            <select class="form-control" name="cls_sec_id">
              <option value="">All Classes</option>
              <?php foreach ($sectionsclassinfo ?? [] as $sectionvalue): ?>
                <option value="<?= esc($sectionvalue['section_id']) ?>" <?= $cls_sec_id == $sectionvalue['section_id'] ? 'selected' : '' ?>><?= esc($sectionvalue['sectionclassname']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-sm-2">
            <label>Display Fine</label>
            <input class="form-control" type="checkbox" name="fine_after_due_date" value="1" <?= $fine_after_due_date == 1 ? 'checked' : '' ?>>
          </div>
          <div class="col-lg-4 form-group">
            <label>Footer Lines 1:</label>
            <input type="text" class="form-control" name="footer_line1" value="<?= esc($footer_line1) ?>">
          </div>
          <div class="col-lg-4 form-group">
            <label>Footer Lines 2:</label>
            <input type="text" class="form-control" name="footer_line2" value="<?= esc($footer_line2) ?>">
          </div>
          <div class="col-lg-2 form-group">
            <label>Show Footer Line 1:</label>
            <input type="checkbox" class="form-control" name="show_line1" value="1" <?= $show_line1 == 1 ? 'checked' : '' ?>>
          </div>
          <div class="col-lg-2 form-group">
            <label>Show Footer Line 2:</label>
            <input type="checkbox" class="form-control" name="show_line2" value="1" <?= $show_line2 == 1 ? 'checked' : '' ?>>
          </div>
          <div class="col-sm-2">
            <input class="btn btn-primary" type="submit" value="View" style="margin-bottom: 25px;">
          </div>
        </div>
      </form>
      <div class="card card-primary card-outline card-tabs">
        <div class="card-body">
          <?php if (!empty($data)): ?>
            <?php foreach ($data as $student_info): ?>
              <div class="pagebreak" style="overflow: hidden; clear: both;">
                <?php foreach (['Bank Copy', 'School Copy', 'Student Copy'] as $copyType): ?>
                  <div style="width:32%; float:left; margin-left:1%;">
                    <div dir="rtl" lang="ur"> <?= esc($student_info['chalan_h_msg']) ?></div>
                    <div class="chalanwrapper">
                      <div class="row">
                        <div class="col-sm-3 ml-2 mt-2"></div>
                        <div class="col-sm-8" style="font-weight:bold;"><?= $copyType ?></div><br />
                        <div class="col-sm-3 ml-2 mt-2"><img style="width: 100%;" src="<?= base_url('system-logo/' . $student_info['logo']) ?>"></div>
                        <div class="col-sm-8"><span style="font-weight:bold;font-size: 16px;"><?= esc($student_info['system_name']) ?></span><br />
                        <?= esc($student_info['campus_name']) ?>, <?= esc($student_info['location']) ?></div>
                      </div>
                      <div class="ml-2 mt-2" style="text-align: left;">
                        <?= esc($student_info['bank_name']) ?>, <?= esc($student_info['bank_address']) ?>, <?= esc($student_info['bank_code']) ?><br />
                        <?php if ($student_info['bank_acc']): ?>
                          Account No: <?= esc($student_info['bank_acc']) ?><br />
                        <?php endif; ?>
                      </div>
                      <div class="feeinfo">
                        <div class="chalanrows">Chalan# <?= esc($student_info['chalan_id']) ?> <span style="float: right; margin-right: 10px;">Family#: <?= esc($student_info['parent_id']) ?></span><span style="float:right; margin-right: 10px;">Reg#: <?= esc($student_info['reg_no']) ?></span></div>
                        <div class="chalanrows">Name: <?= esc($student_info['student_name']) ?></div>
                        <div class="chalanrows">Father Name: <?= esc($student_info['f_name']) ?></div>
                        <div class="chalancolleft"><?= esc($student_info['class_name']) ?></div>
                        <div class="chalancolright">Fee Month: <?= esc($student_info['fee_month']) ?></div>
                        <div class="chalancolleft">Issue Date: <?= esc($student_info['issue_date']) ?></div>
                        <div class="chalancolright"><strong>Due Date: <?= esc($student_info['due_date']) ?></strong></div>
                      </div>
                      <table width="98%" border="1" class="feetable">
                        <tr>
                          <th>Particulars</th>
                          <th>Amount</th>
                          <th>Discount</th>
                        </tr>
                        <?php
                          $total = 0;
                          $nCount = 0;
                          $arialSum = 0;
                          foreach ($student_info['student_fee'] as $fee_info):
                            $total += $fee_info['amount'];
                            if ($nCount < 5):
                        ?>
                          <tr>
                            <td><?= esc($fee_info['fee_name']) ?> (<?= esc($fee_info['fee_month']) ?>)</td>
                            <td><?= esc($fee_info['amount']) ?>/-</td>
                            <td><?= $fee_info['is_monthly_fee'] == 1 ? esc($fee_info['discount']) : '' ?></td>
                          </tr>
                        <?php else:
                          $arialSum += ($fee_info['amount'] - $fee_info['discount']);
                        endif;
                        if ($fee_info['is_monthly_fee'] == 1) {
                          $total -= $fee_info['discount'];
                        }
                        $nCount++;
                        endforeach;
                        if ($arialSum > 0): ?>
                          <tr>
                            <td>Arrears</td>
                            <td><?= $arialSum ?>/-</td>
                            <td></td>
                          </tr>
                        <?php endif;
                        for ($i = $nCount; $i < 5; $i++): ?>
                          <tr><td style="height: 34px;"></td><td></td><td></td></tr>
                        <?php endfor;
                        foreach ($student_info['fee_fine'] as $value):
                          $total += $value['fine_amount']; ?>
                          <tr><td>Fine(<?= esc($value['fee_month']) ?>)</td><td><?= esc($value['fine_amount']) ?></td><td></td></tr>
                        <?php endforeach;
                          $late_fee_fine = $student_info['fine_type'] == 'per_day_fine' ? $student_info['late_fee_fine'] * 15 : $student_info['late_fee_fine'];
                        ?>
                        <tr><td><strong>Payable Within Due Date</strong></td><td><strong><?= $total ?>/-</strong></td><td></td></tr>
                        <?php if ($fine_after_due_date == 1): ?>
                          <tr><td>Late Fee Fine</td><td><?= $late_fee_fine ?>/-</td><td></td></tr>
                          <tr><td><strong>Payable After Due Date</strong></td><td><strong><?= $total + $late_fee_fine ?>/-</strong></td><td></td></tr>
                        <?php endif; ?>
                      </table>
                      <br>
                      <div style="text-align: left; margin-left: 5px;"><?= esc($student_info['chalan_f_msg']) ?></div>
                    </div>
                    <?php if ($show_line1 == 1): ?>
                      <div style="float:left; width:98%; border-bottom:1px solid; margin-top:20px;"><?= esc($footer_line1) ?>&nbsp;&nbsp;</div>
                    <?php endif; ?>
                    <?php if ($show_line2 == 1): ?>
                      <div style="float:left; width:98%; border-bottom:1px solid; margin-top:20px; margin-bottom:20px;"><?= esc($footer_line2) ?>&nbsp;&nbsp;</div>
                    <?php endif; ?>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js"></script>
<?= $this->endSection() ?>