<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url(); ?>resource/bootstrap-switch/css/bootstrap3/bootstrap-switch.min.css" />
<style>


    /* Page size setup for A4 */
    @page {
        size: A4;
        margin: 20mm;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-size: 14px;
        margin: 0;
        padding: 0;
        background: #fff;
        color: #000;
    }

    h1 {
        font-size: 36px;
        letter-spacing: 1px;
        word-spacing: 3px;
        text-align: center;
        margin-bottom: 5px;
    }

    h2 {
        font-size: 28px;
        text-align: center;
        margin-top: 10px;
        margin-bottom: 10px;
    }

    .student-result-card {
        page-break-inside: avoid;
        padding: 15px;
        margin-bottom: 30px;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-shadow: none;
        background-color: #fdfdfd;
    }

    .printable-header img {
        width: 100px;
        height: auto;
        object-fit: contain;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .table th, .table td {
        border: 1px solid #999;
        padding: 6px;
        text-align: center;
        font-size: 13px;
    }

    .table th {
        background-color: #004085;
        color: #fff;
    }

    .signature-section {
        margin-top: 50px;
        display: flex;
        justify-content: space-between;
        font-size: 14px;
        padding: 0 20px;
    }

    .signature-box {
        text-align: center;
        width: 45%;
    }

    .signature-line {
        margin-top: 40px;
        border-top: 1px solid #000;
        height: 1px;
    }

    .footer-note {
        font-size: 12px;
        color: #777;
        text-align: center;
        margin-top: 30px;
    }
</style>


<style>
    .student-result-card {
        page-break-inside: avoid;
        margin-bottom: 20px;
        clear: both;
    }
    .printable-header {
        overflow: hidden;
        border-bottom: 1px solid #000;
        margin-bottom: 10px;
        padding-bottom: 10px;
        clear: both;
    }
    .printable-header h1 {
        margin: 10px 0;
    }
    .list-group-item {
        width: 33% !important;
        float: left !important;
        padding: 5px 10px !important;
        border: none;
    }
    table {
        background-color: transparent;
        border: 2px solid #000;
        margin-top: 10px;
        width: 100%;
    }
    .table-bordered th, .table-bordered td {
        border: 1px solid #333;
        text-align: center;
        vertical-align: middle;
    }
    .heading, .heading2 {
        border: 2px solid #000;
        background-color: #800000;
        color: #000;
        text-align: center;
        font-weight: bold;
        padding: 8px;
        font-size: 18px;
        line-height: 24px;
        width: 100%;
        float: left;
    }
    @media print {
       @page {
            size: A4;
            margin: 15mm 10mm 15mm 10mm;
        }
        .btn, .btn-primary { display: none !important; }
        body { -webkit-print-color-adjust: exact !important; }
        .no-print, .no-print * {
            display: none !important;
        }
        .heading, .heading2 {
            background-color: #800000 !important;
        }
    }
    .column-toggle-container {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
        border: 1px solid #dee2e6;
    }
</style>

<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Students Results</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#/">Dashboard</a></li>
          <li class="breadcrumb-item active">Students Results</li>
        </ol>
      </div>
    </div>
  </div>
</section>

<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
        <div class="card-header p-0 pt-1 border-bottom-0">
          <ul class="nav nav-tabs">
            <li class="nav-item"><a class="nav-link" href="#/students_results?m=add">Add Results</a></li>
            <li class="nav-item"><a class="nav-link active" href="#/students_results_card">View Result Cards</a></li>
          </ul>
        </div>
        <div class="card-body">
          <div class="no-print">
            <div class="form-group">
              <label><strong>Select Exams</strong></label>
              <ul class="list-group list-group-horizontal">
                <?php foreach ($exams as $exam): ?>
                  <li class="list-group-item">
                    <div class="icheck-primary d-inline">
                      <input type="checkbox" class="examids" id="eid<?= $exam->eid ?>" name="exam_id" value="<?= $exam->eid ?>">
                      <label for="eid<?= $exam->eid ?>"> <?= $exam->exam_name ?> </label>
                    </div>
                  </li>
                <?php endforeach; ?>
              </ul>
            </div>

            <div class="column-toggle-container">
              <label><strong>Show Columns:</strong></label>
              <div class="row">
                <div class="col-md-4">
                  <div class="icheck-primary d-inline">
                    <input type="checkbox" id="showMarks" checked>
                    <label for="showMarks"> Marks (Obt/Total)</label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="icheck-primary d-inline">
                    <input type="checkbox" id="showPercentage" checked>
                    <label for="showPercentage"> Percentage</label>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="icheck-primary d-inline">
                    <input type="checkbox" id="showGrades" checked>
                    <label for="showGrades"> Grades</label>
                  </div>
                </div>
              </div>
            </div>

            <div class="row mt-2">
              <div class="col-md-4">
                <div class="icheck-primary d-inline">
                  <input type="checkbox" id="showAttendance" checked>
                  <label for="showAttendance">Show Attendance</label>
                </div>
              </div>
              <div class="col-md-4">
                <div class="icheck-primary d-inline">
                  <input type="checkbox" id="showPosition" checked>
                  <label for="showPosition">Show Position</label>
                </div>
              </div>
            </div>

            <label for="rowHeight">Row Height (px):</label>
                <input type="number" id="rowHeight" name="rowHeight" value="30" min="20" max="100" style="width:80px;">

               <input type="checkbox" id="useShortName" name="useShortName" value="1">
              <label for="useShortName">Use Short Subject Name</label>

            <div class="row">
              <div class="col-lg-6 form-group">
                <label><strong>Select Class</strong></label>
                <select class="form-control" name="cls_sec_id" id="cls_sec_id">
                  <option value="">All Classes</option>
                  <?php if (!empty($sectionsclassinfo)): ?>
                    <?php foreach ($sectionsclassinfo as $section): ?>
                      <option value="<?= $section['section_id'] ?>"> <?= $section['sectionclassname'] ?> </option>
                    <?php endforeach; ?>
                  <?php endif; ?>
                </select>
              </div>
            </div>

            <div class="form-group text-right">
              <button type="button" class="btn btn-primary" id="ViewResult">View Result Card</button>
              <button onclick="window.print();" class="btn btn-success">Export to PDF</button>
            </div>
          </div>

          <div id="loader-1" class="overlay text-center" style="display: none;">
            <i class="fas fa-2x fa-sync-alt fa-spin"></i>
          </div>

          <div id="resultContainer"></div>
        </div>
      </div>
    </div>
  </div>
</section>

<script src="<?php echo base_url(); ?>resource/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script>
  $(function () {
  $('#ViewResult').click(function () {
    $('#loader-1').show();

    var examids = $('.examids:checked').map(function () {
      return this.value;
    }).get();

    var cls_sec_id = $('#cls_sec_id').val();

    var showMarks = $('#showMarks').is(':checked');
    var showPercentage = $('#showPercentage').is(':checked');
    var showGrades = $('#showGrades').is(':checked');
    var useShortName = $('#useShortName').is(':checked') ? 1 : 0;
    var rowHeight = $('#rowHeight').val(); // ✅ fetch row height dynamically
    var showAttendance = $('#showAttendance').is(':checked') ? 1 : 0;
    var showPosition = $('#showPosition').is(':checked') ? 1 : 0;

    $.ajax({
      url: '<?= base_url('admin/students-results-card/data') ?>',
      type: 'POST',
      data: {
        examids: examids,
        cls_sec_id: cls_sec_id,
        showMarks: showMarks,
        showPercentage: showPercentage,
        showGrades: showGrades,
        rowHeight: rowHeight, // ✅ pass it properly
        useShortName: useShortName,
            showAttendance: showAttendance,   
        showPosition: showPosition        
      },
      success: function (res) {
        $('#resultContainer').html(res);
        $('#loader-1').hide();
      },
      error: function () {
        alert('Failed to load result card. Please try again.');
        $('#loader-1').hide();
      }
    });
  });
});



</script>
<style>
    h1 {
        font-size: 36px;
        letter-spacing: 1px;
        word-spacing: 3px;
        font-family: 'Bebas Neue', cursive;
        text-align: center;
        margin: 0 auto;
    }
</style>
<?= $this->endSection() ?>