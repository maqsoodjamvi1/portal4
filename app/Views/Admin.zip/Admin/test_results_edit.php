<?php
	if(isset($info) ){
		$header = 'Edit Test Results';
		$id = $info->student_id;
		$class_id = $info->class_id;
		$obtained_marks = $info->obtained_marks;
		$campus_id = $sessionData['campusid'];
		$session_id = $sessionData['sessionid'];

	}else{
		$header = 'Add Test Results';
		$id = '';
		$class_id = '';
		$subject_id = '';
		$obtained_marks = 0;
		$total_marks = 0;
		$campus_id = $sessionData['campusid'];
		$session_id = $sessionData['sessionid'];
	}
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
           Test Results
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Students Results</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
       	<div class="card-header p-0 pt-1 border-bottom-0">
        <ul class="nav nav-tabs">
	    		<li class="nav-item"><a class="nav-link" href="<?php echo '#/test_results';?>">Test Results</a></li>	
        </ul>
        <div class="card-body">
        <div class="tab-content">
		<?php
			echo form_open('c=test_results&m=save', 'role="form" id="user-edit-form"');
			echo form_hidden('id', $id);
		?>
		<?php foreach($academic_session as $session){ ?>
        <input type="hidden" value="<?php echo $session->session_id; ?>"  name="session_id" id="session_id" class="form-control">
		<?php } ?>
	<div class="row no-print">
		<input type="hidden" name="campus_id" id="campus_id" value="<?php echo $campus_id; ?>" />
			<div class="col-lg-2">
			 <div class="form-group">
       <label for="t_series_id">Test Series</label>
			  <select name="t_series_id" id="t_series_id" class="form-control">
			  <?php foreach($testSeriesinfo as $testSeries){ ?>
              <option value="<?php echo $testSeries->t_series_id; ?>"><?php echo $testSeries->series_name; ?></option>
			  <?php } ?>
			  </select>
			</div>
		</div>
          <div class="col-lg-3">
            <div class="form-group pull-left">
	              <label for="class">Sections</label>
	              <select class="form-control select2" name="cls_sec_id" id="cls_sec_id">
	              	 <option value="0">Select Section</option>
	                <?php if(isset($sectionsclassinfo)){
										  foreach ($sectionsclassinfo as  $secionvalue) { ?>
					                <option value="<?php echo $secionvalue['section_id']; ?>"><?php echo $secionvalue['sectionclassname']; ?></option>
	              	<?php } ?>
	                <?php } ?>
	              </select>
	            </div>
          </div>

          <div class="col-lg-2">
            <div class="form-group">
              <label>Subjects</label>
              <select class="form-control" name="subject_id" id="subject_id">
                
              </select>
            </div>
          </div>
		
		  </div>
		  <div class="row">          
		  <div class="col-lg-12">
         <div id="students_list_container"></div>
		 </div>
		  <div class="col-lg-12">
          <div class="form-group">
            <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
            <button type="reset" class="btn btn-default">Reset</button>
            <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
          </div>
		  </div>
		  </div>
		<?php echo form_close();?> 
 </div>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- /.content -->
<script>
	 $("#cls_sec_id").change(function(){
        var cls_sec_id = $("#cls_sec_id").val();
         $.ajax({
            url: "admin.php?c=tests&m=selectSubjectbySection",
            type: "POST",
            data:{cls_sec_id:cls_sec_id },
            success:function(res){
         $("#subject_id").html(res);
       }
         });
    });
 $("#subject_id,#t_series_id").change(function(){		
		var session_id = $('#session_id').val();
		var t_series_id = $('#t_series_id').val();
		var campus_id = $('#campus_id').val();
		var cls_sec_id = $('#cls_sec_id').val();
		var subject_id = $('#subject_id').val();
		$.ajax({
        	url: 'admin.php?c=test_results&m=get_students',
          type: "POST",
          data:{t_series_id:t_series_id,session_id:session_id,cls_sec_id: cls_sec_id,campus_id:campus_id,subject_id:subject_id },
          success:function(res){
 			   		$("#students_list_container").html(res);
 			    }
      });
 });
 

  $("#eid").change(function(){
        $('#students_list_container').html('');
    });
</script>
<script type="text/javascript">
$(function(){
	//$(".select").select2({closeOnSelect:false});	
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			//return $('#user-edit-form').valid();
			$('#submitBtn').html("Saving!");
      		//$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
			$('#submitBtn').html("Save");
      		//$('#submitBtn').prop('disabled', false);
			var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
				<?php
				if($id == ''){
					?>
					location.href = '#/test_results';
					<?php
				}else{
					?>
					location.href = '#/test_results?m=edit&id=<?php echo $id;?>&after=edit';
					<?php
				}
				?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
});
</script>