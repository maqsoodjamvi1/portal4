<?php
  if(isset($_GET['id'])){
    $header = 'Edit System';
  //   $system_name = $schoolinfo->system_name;
    // $address = $schoolinfo->address;
    // $city = $schoolinfo->city;
    // $state = $schoolinfo->state;
    // $zip = $schoolinfo->zip;
    // $country = $schoolinfo->country;
    // $owner_name = $schoolinfo->owner_name;
    // $landline_number = $schoolinfo->landline_number;
    // $mob_number = $schoolinfo->mob_number;
    // $reg_text = $schoolinfo->reg_text;
    // $logo = $schoolinfo->logo;
    // $slogan = $schoolinfo->slogan;
  }else{
    echo "<div class='mt-5 ml-5 alert-danger'>No Record Found </div>";
    exit;
  }
?>

<!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          <h1>
         Student Profile
          </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Student Profile</li>
            </ol> 
            </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- /.col -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-header p-2">
             <ul class="nav nav-tabs">  
              <li class="nav-item"><a style="cursor: pointer;" class="nav-link" id="profile"> Profile</a></li>
              <li class="nav-item"><a style="cursor: pointer;" class="nav-link " id="fee" > Fee</a></li>
              <li class="nav-item"><a style="cursor: pointer;" class="nav-link " id="result"> Result</a></li>
              <li class="nav-item"><a style="cursor: pointer;" class="nav-link"  id="attendance" > Attendance</a></li>
              <li class="nav-item"><a target="_blank" class="nav-link " href="<?php echo '#/fee_chalan_single?m=download&id='.$_GET['id']; ?>" > Chalan</a></li>
              <li class="nav-item"><a target="_blank" class="nav-link " href="<?php echo '#/leaving_certificate?m=edit&id='.$_GET['id']; ?>"> Certificate</a></li>
          </ul>
          </div>
          <div class="card-body">
            <div class="tab-content">
              <div class="active tab-pane" id="settings">
                  <div id="studentInfo"></div>
              </div>
              <!-- /.tab-pane -->
            </div>
          </div>
    <!-- /.tab-content -->
  </div>
  <!-- /.nav-tabs-custom -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->
</section>

<script type="text/javascript">
$(function(){

   $.ajax({
            url: 'admin.php?c=profile_student&m=data', 
            type: "POST",
            data:{student_id:<?php echo $_GET['id']; ?>},
            success:function(res){
              $("#studentInfo").html(res);
        }
    });

  $("#fee").click(function(){
    $.ajax({
            url: 'admin.php?c=profile_student&m=singleStudentFeedata', 
            type: "POST",
            data:{student_id:<?php echo $_GET['id']; ?>},
            success:function(res){
              $("#studentInfo").html(res);
        }
    });
 });

 $("#attendance").click(function(){
    $.ajax({
            url: 'admin.php?c=profile_student&m=singleStudentAttendancedata', 
            type: "POST",
            data:{student_id:<?php echo $_GET['id']; ?>},
            success:function(res){
              $("#studentInfo").html(res);
        }
    });
 }); 

 $('#result').on('click', function() { 
  $("#loader-1").css("display", "block"); 
  var academic_result = [];

  var student_id = <?php echo $_GET['id']; ?>;
  //var subject_id = $('#subject_id').val();

  
  $.ajax({
        url: 'admin.php?c=student_results&m=data',
        type: "POST",
        data:{academic_result:academic_result,student_id:student_id},
        success:function(res){
         $("#studentInfo").html(res);
         $("#loader-1").css("display", "none");
        }
        });
  });
  
});     
</script> 