<?= $this->extend('layouts/admin_template') ?>

<?= $this->section('content') ?>
<?php
	if(isset($info)){

			$header = 'Edit Academic Session';
			$id = $info->session_id;
			$session_name = $info->session_name;
			$start_date = $info->start_date;
			$end_date = $info->end_date;

		}else{
			$header = 'Add Academic Session';
			$id = '';
			$session_name = date('Y').'-'.(date("y")+1);
			if($academic_session_info){
				$date = new DateTime($academic_session_info->end_date);
				$date->modify('+1 day');
				$start_date = $date->format('Y-m-d');
			}else{
				$start_date = '';
			}
			$end_date = '';

		}
?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-8">
            <h1>
               Academic Session
            <?php 
            	//$schoolinfo = getSchoolInfo();
            	//$this->db->where('system_id', $schoolinfo->system_id);
				//$academic_session_info = $this->db->get('academic_session')->row();
				if(empty($academic_session_info->session_id)){ ?>
					
					<span style='background: green;color: #fff !important;float: right;padding: 5px 10px;margin-top: 0px;
    font-size: 16px;'>Step 1 Of 10 To Complete System Configuration</span>
    				<audio autoplay  controls>
						 <source src="audio/Step2Session.m4a" type="audio/ogg">
						  <source src="audio/Step2Session.m4a" type="audio/mpeg">
						Your browser does not support the audio element.
						</audio> 
			
						<?php	} ?>        	
            </h1>
          </div>
          <div class="col-sm-4">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '<?php echo base_url(); ?>/admin';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Academic Session</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
  <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
		  <div class="card card-primary card-outline card-tabs">
          	<div class="card-header p-0 pt-1 border-bottom-0">
			<ul class="nav nav-tabs">
			<li class="nav-item">
				<a class="nav-link" href="<?php echo base_url(); ?>admin/academic_session">Academic Session</a>
			</li>
			<?php if($id == ''){ ?>
			<li class="nav-item">
				<a class="nav-link active" href="<?php echo base_url('/admin/academic_session/add');?>"><?php echo $header;?></a>
			</li>
			<?php }else{ ?>
			<li class="nav-item">
				<a class="nav-link active" href="<?php echo base_url('/admin/academic_session/edit/id=' . $id); ?>">
					<?php echo $header;?>
				</a>
			</li>
			<?php } ?>
			</ul>
		<div class="card-body">	
		<div class="tab-content">
		<?php
			echo form_open('admin/academic_session/save', 'role="form" id="academic-session-edit-form"');
			echo form_hidden('id', $id);
		?>
		    <div class="form-group">
              <label for="session_name">Session Name (e.g 2019-20)</label>
                <input type="text" class="form-control" name="session_name" id="session_name"  data-inputmask='"mask": "9999-99"' data-mask value="<?php echo $session_name;?>">
				<input type="hidden" id="originalsession_name" value="<?php echo $session_name;?>">
			</div>
			<div class="form-group">
                <label for="start_date">Start Date</label>
              <?php if($start_date){?>
                <input type="text" readonly class="form-control" name="start_date" id="start_date" value="<?php echo $start_date;?>">
            <?php }else{ ?>
								<div class="input-group date" id="reservationdate1" data-target-input="nearest">
                  <input type="text" readonly class="form-control datetimepicker-input" autocomplete="off" id="startdatepicker" name="start_date" value="<?php echo date('Y-03-01'); ?>" data-target="#reservationdate1"/>
                  <div class="input-group-append" data-target="#reservationdate1" data-toggle="">
                  <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                  </div>
                </div>
						<?php } ?>
			</div>
			<div class="form-group">
						<label>End Date:</label>
						<?php if(empty($end_date)){ ?>
							<div class="input-group date" id="reservationdate" data-target-input="nearest">
                <input type="text" readonly class="form-control datetimepicker-input" autocomplete="off" id="enddatepicker" name="end_date" value="<?php echo date("Y-03-01", strtotime(date("Y-03-01", strtotime(date('Y-03-01'))) . " + 1 year"));//echo $end_date;?>" data-target="#reservationdate"/>
                <div class="input-group-append" data-target="#reservationdate" data-toggle="">
                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
             </div>
          <?php }else{ ?>
          	<div class="input-group date" id="reservationdate" data-target-input="nearest">
                <input type="text" readonly class="form-control datetimepicker-input" autocomplete="off" id="enddatepicker" name="end_date" value="<?php echo $end_date;?>" data-target="#reservationdate"/>
                <div class="input-group-append" data-target="#reservationdate" data-toggle="">
                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
             </div>
          <?php } ?>
			</div>
            <div class="form-group">
            <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
			<button type="reset" class="btn btn-default">Reset</button>
			<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
            </div>
            <?php echo form_close();?>
			</div>
		</div>
		  </div>
        </div>
      </div>
  </div>
</section>
<!-- /.content -->
<script type="text/javascript">

$(function(){
	$( "#startdatepicker" ).datepicker({
		showWeek: true,
		firstDay: 1,
		onSelect: function(date){
			var d = new Date(date);
			var index = d.getDay();
			if(index == 0) {
				d.setDate(d.getDate() - 6);
			}
			else if(index == 1) {
				d.setDate(d.getDate());
			}
			else if(index != 1 && index > 0) {
				d.setDate(d.getDate() - (index - 1));
			}
			var ye = new Intl.DateTimeFormat("en", { year: "numeric" }).format(d);
			var mo = new Intl.DateTimeFormat("en", { month: "numeric" }).format(d);
			var da = new Intl.DateTimeFormat("en", { day: "2-digit" }).format(d);
			$(this).val(ye+"-"+mo+"-"+da);
			}
	});
	$( "#enddatepicker" ).datepicker({
		showWeek: true,
		firstDay: 1,
		onSelect: function(date){
			var d = new Date(date);
			var index = d.getDay();
			if(index == 0) {
				d.setDate(d.getDate());
			}
			else if(index == 1) {
				d.setDate(d.getDate() - 1);
			}
			else if(index != 1 && index > 0) {
				d.setDate(d.getDate() - (index - 7));
			}
			var ye = new Intl.DateTimeFormat("en", { year: "numeric" }).format(d);
			var mo = new Intl.DateTimeFormat("en", { month: "numeric" }).format(d);
			var da = new Intl.DateTimeFormat("en", { day: "2-digit" }).format(d);
			$(this).val(ye+"-"+mo+"-"+da);
			}
	});
	$('[data-mask]').inputmask();
	$('#academic-session-edit-form').validate({
		rules:{
			session_name:{
				required:true,
			}
		},
		messages:{
			session_name:{
				required:'Session is Required',
			}
		}
	});
	$('#academic-session-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			return $('#academic-session-edit-form').valid();
			$('#submitBtn').html("Saving!");
			$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
			var json = $.parseJSON(responseText);
			$('#submitBtn').html("Save");
			$('#submitBtn').prop('disabled', false);
			if(json.term_id == false){
	        	window.location.href = '<?php echo base_url(); ?>admin/terms/add';
	        	return;
	      	}
			if(json.success){
				toastr.success(json.msg);
				<?php
				if($id == ''){
					?>
					location.href = '<?php echo base_url(); ?>admin/academic_session';
					location.reload();
					<?php
				}else{
					?>
					location.href = '<?php echo base_url(); ?>admin/academic_session/edit/id=<?php echo $id;?>&after=edit';
					<?php
				}
				?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
});
</script>
<?= $this->endSection() ?>