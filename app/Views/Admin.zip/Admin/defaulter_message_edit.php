<?php
	if(isset($info)){

		$header = 'Edit Defaulter Message';
		$id = $info->enquiry_id;
		$name = $info->name;
		$email = $info->email;
		$contact = $info->contact;
		$address = $info->address;
		$description = $info->description;
		$date = $info->date;

	}else{
		$header = 'Add  Defaulter Message';
		$id = '';
		$name = '';
		$contact = '';
		$email = '';
		$address = '';
		$description = '';
		$date = '';
	}
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
           Defaulter Message
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Defaulter Message</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-lg-12">
  <div class="card card-primary card-outline card-tabs">
    <div class="card-header p-0 pt-1 border-bottom-0">
	<ul class="nav nav-tabs">
		<?php if($id == ''){ ?>
		<li class="nav-item"><a class="nav-link active" href="<?php echo '#/defaulter_message';?>"><?php echo $header;?></a></li>
		<li class="nav-item"><a class="nav-link" href="<?php echo '#/defaulter_message?m=parent_sms';?>">Unique sms to parent</a></li>
		<?php }else{ ?>
		<li class="nav-item"><a class="nav-link active" href="<?php echo '#/defaulter_message?m=edit&id=' . $id;?>"><?php echo $header;?></a></li>
		<?php } ?>
	</ul>
	<div class="card-body">
	<div class="tab-content">
	<?php
		echo form_open('c=defaulter_message&m=save', 'role="form" id="user-edit-form"');
		echo form_hidden('id', $id);
	?>
	<div class="row">
	<div class="col-lg-3">
    <?php //$months = array(1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec');?>
    <select class="form-control select2" id="month" name="month">
        <option value="">Select Fee Month</option>
        <?php
            foreach ($months as $key => $name) {
            		//print_r($name);
                printf('<option value="%s">%s</option>', $name['id'], $name['value']);
            }
        ?>
    </select>
	</div>
	<div class="col-lg-3">
	    <select class="form-control select2" id="fee_type" name="fee_type" style="max-width: 100%;">
	        <option value="">Select Fee Type</option>
	        <?php
	            foreach ($fee_types as $value) {
	                printf('<option value="%u">%s</option>', $value->fee_type_id, $value->fee_type_name);
	            }
	        ?>
	    </select> 
	</div>
	<div class="col-lg-2">	<a href="/admin.php#/defaulter_message" style="height: 33px;line-height: 17px;margin-top: 0px;"  onclick="submitFilter();" class="btn btn-primary">View</a></div>
	<div class="col-md-12 bg">
		    <div id="loader-1" class="overlay text-center" style="display: none;"><i class="fas fa-2x fa-sync-alt fa-spin"></i></div>
		</div>  
	</div>
	<div id="defaultersList"></div>		
	<div style="clear: both;"></div>
	<div class="form-group">
    <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
		<button type="reset" class="btn btn-default">Reset</button>
		<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
  </div>
  <?php echo form_close();?> 
	</div>
	</div>
	</div>
</div>
</div>
</div>
</section>
<!-- /.content -->
<script type="text/javascript">
	 	function submitFilter(){
			var month = $('#month').val();
			var fee_type_id = $('#fee_type').val();
				$("#loader-1").css("display", "block");
			 $.ajax({
            url: 'admin.php?c=defaulter_message&m=data',
            type: "POST",
            data:{month:month,fee_type_id:fee_type_id },
            success:function(res){
 			   $("#defaultersList").html(res);
 			   	$("#loader-1").css("display", "none");
 			   }
         });	
		}

</script>
<script type="text/javascript">
$(function(){
	$('#datepicker').datetimepicker({
       format: 'YYYY-MM-DD'
     });
    $('#datepicker2').datetimepicker({
        format: 'YYYY-MM-DD'
    });
	$('#user-edit-form').validate({
		rules:{
			name:{
				required:true,
			}
		},
		messages:{
			name:{
				required:'Term is Required',	
			}
		}
	});
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			//return $('#user-edit-form').valid();
			$('#submitBtn').html("Saving!");
      		$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
			$('#submitBtn').html("Save");
      	$('#submitBtn').prop('disabled', false);
			var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
				<?php
				if($id == ''){
					?>
					location.href = '#/messages';
					<?php
				}else{
					?>
					location.href = '#/messages';
					<?php
				}
				?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
})
</script>