<div class="row">
  <div class="col-lg-4">
    <div class="form-group">
      <label for="exam_start_date">Exam Start Date</label>
      <div class="input-group date" id="exam_start_date" data-target-input="nearest">
        <input type="text" name="exam_start_date" class="form-control datetimepicker-input" data-target="#exam_start_date"/>
        <div class="input-group-append" data-target="#exam_start_date" data-toggle="datetimepicker">
          <div class="input-group-text"><i class="fa fa-calendar"></i></div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="form-group">
      <label for="exam_end_date">Exam End Date</label>
      <div class="input-group date" id="exam_end_date" data-target-input="nearest">
        <input type="text" name="exam_end_date" class="form-control datetimepicker-input" data-target="#exam_end_date"/>
        <div class="input-group-append" data-target="#exam_end_date" data-toggle="datetimepicker">
          <div class="input-group-text"><i class="fa fa-calendar"></i></div>
        </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$(function () {
  $('#exam_start_date').datetimepicker({
    format: 'DD/MM/YYYY',
    useCurrent: false,
    minDate: new Date("<?= esc($start_date) ?>"),
    maxDate: new Date("<?= esc($end_date) ?>")
  });

  $('#exam_end_date').datetimepicker({
    format: 'DD/MM/YYYY',
    useCurrent: false,
    minDate: new Date("<?= esc($start_date) ?>"),
    maxDate: new Date("<?= esc($end_date) ?>")
  });
});
</script>
