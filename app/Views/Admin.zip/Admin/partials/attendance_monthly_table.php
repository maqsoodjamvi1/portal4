<?php
$sectionInfo = getClassSection($section_id);
$students = getStudentsBySection($section_id);
$totalStudents = count($students);
?>

<div class="container-fluid">
    <h1 class="text-center">Monthly Attendance Report</h1>
    <div class="row">
        <div class="col-lg-4 text-center">
            <h6><?= esc($sectionInfo['sectionclassname']) ?></h6>
        </div>
        <div class="col-lg-4 text-center">
            <h6><?= esc($monthyear) ?></h6>
        </div>
        <div class="col-lg-4 text-center">
            <h6>Total Students: <?= $totalStudents ?></h6>
        </div>
    </div>

    <table class="table table-bordered table-striped table-sm">
        <thead class="bg-primary text-white text-center">
            <tr>
                <th>Photo</th>
                <th>Name</th>
                <?php foreach ($dates as $day): ?>
                    <?php
                        $timestamp = strtotime($day);
                        if ($timestamp > strtotime(date('Y-m-d'))) break;
                        $dayNum = date('d', $timestamp);
                        $dayName = substr(date('D', $timestamp), 0, 2);
                    ?>
                    <th><?= "$dayNum<br>$dayName" ?></th>
                <?php endforeach; ?>
                <th>P</th>
                <th>A</th>
                <th>LC</th>
                <th>EL</th>
                <th>L</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($students as $student): ?>
                <?php
                    $p = $a = $lc = $el = $l = 0;
                    $photoPath = 'uploads/' . $student->profile_photo;
                    $photoTag = file_exists(FCPATH . $photoPath) && !empty($student->profile_photo)
                        ? '<img src="' . base_url($photoPath) . '" class="rounded-circle" width="50" height="50">'
                        : '<i class="fa fa-user fa-2x"></i>';
                ?>
                <tr>
                    <td class="text-center"><?= $photoTag ?></td>
                    <td>
                        <?= esc($student->first_name . ' ' . $student->last_name) ?><br>
                        <strong><?= esc($student->reg_no) ?></strong>
                    </td>

                    <?php foreach ($dates as $day): ?>
                        <?php
                            $timestamp = strtotime($day);
                            if ($timestamp > strtotime(date('Y-m-d'))) break;

                            $db = db_connect();
                            $attn = $db->table('attendance')->where([
                                'student_id' => $student->student_id,
                                'date'       => $day
                            ])->get()->getRow();

                            $statusHTML = '-';
                            if ($attn) {
                                if ($attn->status === 'P') {
                                    if ($attn->el_duration > 0 && $attn->lc_duration > 0) {
                                        $statusHTML = '<span class="badge bg-warning text-dark">LE</span>';
                                        $el++; $lc++;
                                    } elseif ($attn->el_duration > 0) {
                                        $statusHTML = '<span class="badge bg-warning text-dark">EL</span>';
                                        $el++;
                                    } elseif ($attn->lc_duration > 0) {
                                        $statusHTML = '<span class="badge bg-warning text-dark">LC</span>';
                                        $lc++;
                                    } else {
                                        $statusHTML = '<span class="badge bg-success">P</span>';
                                        $p++;
                                    }
                                } elseif ($attn->status === 'A') {
                                    $statusHTML = '<span class="badge bg-danger">A</span>';
                                    $a++;
                                } elseif ($attn->status === 'L') {
                                    $statusHTML = '<span class="badge bg-secondary">L</span>';
                                    $l++;
                                }
                            }
                        ?>
                        <td class="text-center"><?= $statusHTML ?></td>
                    <?php endforeach; ?>

                    <td><?= $p ?></td>
                    <td><?= $a ?></td>
                    <td><?= $lc ?></td>
                    <td><?= $el ?></td>
                    <td><?= $l ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
