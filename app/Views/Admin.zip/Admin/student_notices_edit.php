<?php
	if(isset($info)){
		$header = 'Edit Notice';
		$id = $info->notice_id;
		$notice_name = $info->notice_name;
		$notice_date = $info->notice_date;
		$notice_detail = $info->notice_detail;
		$notice_audio = $info->notice_audio;
		$status = $info->status;
	}else{
		$header = 'Add Notice';
		$id = '';
		$notice_name = '';
		$notice_date = '';
		$notice_detail = '';
		$notice_audio = '';
		$status = 1;
	}
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
          Student Notices
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Student Notices</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>    
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-lg-12">
	<div class="card card-primary card-outline card-tabs">
    <div class="card-header p-0 pt-1 border-bottom-0">
	<ul class="nav nav-tabs">
		<li class="nav-item"><a class="nav-link" href="<?php echo '#/notices';?>">Student Notice</a></li>
		<?php if($id == ''){ ?>
		<li class="nav-item"><a class="nav-link active" href="<?php echo '#/student_notices?m=add';?>"><?php echo $header;?></a></li>
		<?php }else{ ?>
		<li class="nav-item"><a class="nav-link" href="<?php echo '#/student_notices?m=edit&id=' . $id;?>"><?php echo $header;?></a></li>
		<?php } ?>
	</ul>
<div class="card-body">	
<div class="tab-content">
	<?php
		echo form_open('c=student_notices&m=save', 'role="form" id="classes-edit-form"');
		echo form_hidden('id', $id);
	?>
<div class="col-lg-6">
   <div class="form-group">
      <label for="class">Notices</label><br>
      <select class="form-control select2" name="notice_id" id="notice_id" style="height: 24px;">
      	 <option value="0">Select Notice</option>
      </select>
 	</div>
	<div class="form-group">
       <label for="notice_date">Classes</label><br>
       <?php foreach ($sectionsclassinfo as $key => $value) { 
       	//print_r($value);
        ?>
       <label><input type="checkbox" name="section_id[]" id="section_id" value="<?php echo $value['section_id']; ?>"> <?php echo $value['sectionclassname']; ?></label>	<br>
       <?php } ?>
	</div>	
</div>
<div class="row">
 <div class="col-lg-12">
    <div class="form-group">
        <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
		<button type="reset" class="btn btn-default">Reset</button>
		<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
    </div>
</div>
</div>
<?php echo form_close();?>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- /.content -->
<script type="text/javascript">
$(function(){
	$("#notice_id").select2({
    minimumInputLength: 2,
    tags: [],
    ajax: {
        url: 'admin.php?c=student_notices&m=get_noticeinfo',
        dataType: 'json',
        type: "POST",
        quietMillis: 50,
        data: function (term) {
            return {
                term: term
            }
        },
       processResults: function (response) {
       	console.log(response);
              return {
                 results: response
              };
           },
           cache: true
    }
 });
	
	$('#classes-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			$('#submitBtn').html("Saving");
      		$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){	
			$('#submitBtn').html("Save");
      		$('#submitBtn').prop('disabled', false);	
			var json = $.parseJSON(responseText);
			console.log(json);
			if(json.success){
				toastr.success(json.msg);
				<?php
				if($id == ''){
					?>
					location.href = '#/student_notices';
					<?php
				}else{
					?>
					location.href = '#/student_notices';
					<?php
				}
				?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
});
</script>
