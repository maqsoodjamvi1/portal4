<?php if (!empty($grouped_data)): ?>
    <div class="table-responsive">
        <?php foreach($grouped_data as $class): ?>
            <div class="mb-4" style="page-break-inside: avoid;">
                <h4 class="text-center font-weight-bold mb-3"><?= $class['class_name'] ?></h4>
                <table class="table table-bordered">
                    <thead class="thead-light">
                        <tr>
                            <th style="width:20%;">Subject</th>
                            <?php foreach($class['terms'] as $term_id => $term_name): ?>
                                <th><?= $term_name ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($class['subjects'] as $subject): ?>
                            <tr>
                                <td><?= $subject['subject_name'] ?></td>
                                <?php foreach($class['terms'] as $term_id => $term_name): ?>
                                    <td style="direction: <?= in_array($subject['subject_name'], ['Urdu','Islamiat','Nazra']) ? 'rtl' : 'ltr' ?>">
                                            <?php if (isset($subject['objectives'][$term_id])): ?>
                                                <?= nl2br(htmlspecialchars($subject['objectives'][$term_id]['text'])) ?>
                                                <a href="<?= site_url('Top_level_planning_gradewise/edit/' . $subject['objectives'][$term_id]['tlp_id']) ?>"
                                                   class="btn btn-sm btn-primary mt-1">
                                                    <i class="fas fa-edit"></i> Edit
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <hr class="my-4">
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <div class="alert alert-info">No data found with selected filters</div>
<?php endif; ?>
