<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>
<link rel="stylesheet" href="<?= base_url('resource/bootstrap-switch/css/bootstrap3/bootstrap-switch.min.css') ?>" />

<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Class Sections</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= base_url('admin/dashboard') ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Class Sections</li>
        </ol>
      </div>
    </div>
  </div>
</section>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
        <div class="card-header p-0 pt-1 border-bottom-0">
          <ul class="nav nav-tabs">
            <li class="nav-item">
              <a class="nav-link active" href="<?= base_url('admin/class_section') ?>">Class Sections</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?= base_url('admin/class_section/add') ?>">Add Class Section</a>
            </li>
          </ul>
        </div>
        <div class="card-body">
          <div class="col-lg-12">
            <table class="table table-striped table-bordered table-hover" id="class-subjects-datatable" width="100%">
              <thead>
                <tr>
                  <th nowrap>Class Code</th>
                  <th nowrap>Class</th>
                  <th nowrap>Section</th>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<script src="<?= base_url('resource/bootstrap-switch/js/bootstrap-switch.min.js') ?>"></script>
<script type="text/javascript">
$(function(){
  var table = $('#class-subjects-datatable').DataTable({
    deferRender: true,
    select: {
      style: 'single',
      blurable: true
    },
    ajax: {
      url: '<?= base_url('admin/class_section/data') ?>',
      type: 'post',
      data: function(d) {
        // CSRF token if needed
      }
    },
    columns: [
      {
        data: 'id',
        className: 'select-checkbox',
        render: function(data, type, row) {
          return data;
        }
      },
      { data: 'class_name' },
      { data: 'section_name' }
    ],
    fnDrawCallback: function(oSettings) {
      $(".switchchk").bootstrapSwitch({
        onSwitchChange: function(e, state) {
          var fieldval = state ? 1 : 0;
          var $element = $(e.currentTarget);
          var tablename = $element.attr('data-table');
          var fieldname = $element.attr('data-field');
          var rowid = $element.attr('data-pk');

          $.post(
            "<?= base_url('admin/ajax/setboolattribute') ?>",
            {
              act: 'upsort',
              tbname: tablename,
              tbfield: fieldname,
              tbfieldvalue: fieldval,
              id: rowid
            },
            function(data) {
              if (data === 'success') {
                toastr.success('Change successful');
              } else {
                toastr.error('Change error');
              }
            }
          );
        }
      });
    }
  });
});
</script>
<?= $this->endSection() ?>
