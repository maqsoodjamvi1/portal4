<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-8">
                <h1>Daily Fee Collection Report</h1>
            </div>
            <div class="col-sm-4">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= base_url('#/') ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Daily Collection</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-3">
                            <select class="form-control" id="month">
                                <option value="">Select Month</option>
                                <?php foreach($months as $key => $name): ?>
                                    <option value="<?= $key ?>" <?= ($key == $selected_month) ? 'selected' : '' ?>>
                                        <?= $name ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-control" id="year">
                                <option value="">Select Year</option>
                                <?php foreach($years as $year): ?>
                                    <option value="<?= $year ?>" <?= ($year == $selected_year) ? 'selected' : '' ?>>
                                        <?= $year ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="card-body">
                    <div id="loader" class="overlay" style="display: none;">
                        <i class="fas fa-2x fa-sync-alt fa-spin"></i>
                    </div>
                    
                    <table class="table table-bordered table-striped" id="report-table" style="display: none;">
                        <thead class="thead-dark">
                            <tr>
                                <th>Date</th>
                                <th>Total Collection</th>
                                <th>Total Discount</th>
                                <th>Net Collection</th>
                            </tr>
                        </thead>
                        <tbody id="report-body"></tbody>
                        <tfoot class="bg-secondary text-bold">
                            <tr>
                                <td>Grand Total</td>
                                <td id="grand-total">0</td>
                                <td id="grand-discount">0</td>
                                <td id="grand-net">0</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
$(document).ready(function() {
    $('#month, #year').change(function() {
        const month = $('#month').val();
        const year = $('#year').val();
        
        if(month && year) {
            $('#loader').show();
            $('#report-table').hide();
            
            $.ajax({
                
                url:'<?php echo site_url('c=profit_loss_report&m=get_daily_collection');?>', 
                type: 'POST',
                data: {month, year},
                success: function(response) {
                    const data = JSON.parse(response);
                    const tbody = $('#report-body');
                    
                    tbody.empty();
                    if(data.data.length > 0) {
                        data.data.forEach(row => {
                            tbody.append(`
                                <tr>
                                    <td>${row.date}</td>
                                    <td>${row.total}</td>
                                    <td>${row.discount}</td>
                                    <td>${row.net}</td>
                                </tr>
                            `);
                        });
                        
                        $('#grand-total').text(data.grand_total);
                        $('#grand-discount').text(data.grand_discount);
                        $('#grand-net').text(data.net_total);
                        $('#report-table').show();
                    } else {
                        tbody.append('<tr><td colspan="4" class="text-center">No data found for selected period</td></tr>');
                        $('#report-table').show();
                    }
                    $('#loader').hide();
                }
            });
        }
    }).trigger('change');
});
</script>