<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
          Delete Fee Chalan
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Delete Fee Chalan</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-lg-12">
  <div class="card card-primary card-outline card-tabs">
    <div class="card-header p-0 pt-1 border-bottom-0">
	<ul class="nav nav-tabs">
		<li class="nav-item"><a class="nav-link" href="<?php echo '#/admission_enquiry';?>">Delete Fee Chalan</a></li>
	</ul>
	<div class="card-body">
	<div class="tab-content">

	<?php
	if($studentFeeDetail){
		echo form_open('c=delete_fee_chalan&m=delete', 'role="form" id="user-edit-form"');
	
	?>
	<table class="table">
			<tr>
				<th>#</th>
				<th>Student Name</th>
					<th>Amount</th>
				<th>Created Date</th>
			</tr>
	<?php foreach ($studentFeeDetail as $key => $value) { ?>
			<tr>
				<td><?php echo $value['chalan_id']; ?></td>
				<td><?php echo $value['student_name']; ?></td>
				<td><?php echo $value['amount']; ?></td>
				<td><?php echo $value['created_date']; ?></td>
			</tr>
		
	<?php } ?>
	</table>
	<div class="form-group">
            <button type="submit" id="submitBtn" class="btn btn-danger">Delete Current Month Fee Chalan</button>
			<button type="reset" class="btn btn-default">Reset</button>
			<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
    </div>
    <?php echo form_close();
  }else{ ?>
  	Only Current Date Fee Chalan can be deleted
  <?php } ?> 
		</div>
		</div>
        </div>
      </div>
      </div>
      </div>
</section>
    <!-- /.content -->
<script type="text/javascript">
$(function(){
	$('#datepicker').datetimepicker({
       format: 'YYYY-MM-DD'
     });
    $('#datepicker2').datetimepicker({
        format: 'YYYY-MM-DD'
    });
	$('#user-edit-form').validate({
		rules:{
			name:{
				required:true,
			}
		},
		messages:{
			name:{
				required:'Term is Required',	
			}
		}
	});
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			//return $('#user-edit-form').valid();
			$('#submitBtn').html("Saving!");
      		$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
			$('#submitBtn').html("Save");
      	$('#submitBtn').prop('disabled', false);
			var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
				<?php
				if($id == ''){
					?>
					location.href = '#/admission_enquiry';
					<?php
				}else{
					?>
					location.href = '#/admission_enquiry';
					<?php
				}
				?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
})
</script>