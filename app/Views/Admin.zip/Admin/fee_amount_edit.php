<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>
<?php
$header = isset($info) ? 'Edit Fee Type' : 'Add Fee Type';
$id = $info->amount_id ?? '';
$fee_type_id = $info->fee_type_id ?? '';
$class_id = $info->class_id ?? '';
$fee_amount = $info->amount ?? '';
?>

<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
          Fee Structure for Session <?= esc($current_academic_sessioninfo->session_name ?? '') ?>
          <?php if (!empty($is_first_time)): ?>
            <span style="background: green; color: #fff; float: right; padding: 5px 10px; margin-top: 0px; font-size: 16px;">
              Step 10 Of 10 To Complete System Configuration
            </span>
            <audio autoplay controls>
              <source src="<?= base_url('assets/audio/setup-complete.mp3') ?>" type="audio/mpeg">
              Your browser does not support the audio element.
            </audio>
          <?php endif; ?>
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= base_url('admin/dashboard') ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Fee Amount</li>
        </ol>
      </div>
    </div>
  </div>
</section>

<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
        <div class="card-header p-0 pt-1 border-bottom-0">
          <div class="card-body">
            <div class="tab-content">

              <?= form_open( base_url('admin/fee_amount/save'), ['id' => 'user-edit-form', 'role' => 'form']) ?>
              <?= form_hidden('id', $id) ?>

              <div class="form-group row">
                <div class="col-sm-2">
                  <label for="session_id">Choose Session</label>
                </div>
                <div class="col-sm-6">
                  <select name="session_id" id="session_id" class="form-control">
                    <option value="">Select Session</option>
                    <?php foreach ($academic_sessioninfo as $session): ?>
                      <option value="<?= esc($session->session_id) ?>" <?= ($session->session_id == $session_id) ? 'selected' : '' ?>>
                        <?= esc($session->session_name) ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>

              <div class="col-lg-12">
                <div id="loader-1" class="overlay" style="display: none;">
                  <i class="fas fa-2x fa-sync-alt fa-spin"></i>
                </div>
              </div>

              <div id="feeamountarea" class="feeamountarea"></div>

              <div class="form-group">
                <button type="submit" id="submitBtn" class="btn btn-primary mr-2">Save</button>
                <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
              </div>

              <?= form_close() ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<script type="text/javascript">
$(function () {
  $('#session_id').on('change', function () {
    var session_id = $(this).val();
    $("#loader-1").show();
    $.ajax({
      url: '<?= base_url('admin/fee_amount/data') ?>',
      type: "POST",
      data: { session_id: session_id },
      success: function (res) {
        $("#feeamountarea").html(res);
        $("#loader-1").hide();
      }
    });
  });

  $('#session_id').trigger("change");

  $('#user-edit-form').validate({
    rules: {
      amount: {
        required: true
      }
    },
    messages: {
      amount: {
        required: 'Fee amount is required'
      }
    }
  });

  $('#user-edit-form').ajaxForm({
    beforeSubmit: function () {
      return $('#user-edit-form').valid();
      $('#submitBtn').html("Saving").prop('disabled', true);
    },
    success: function (responseText) {
      $('#submitBtn').html("Save").prop('disabled', false);
      var json = $.parseJSON(responseText);
      if (json.success) {
        toastr.success(json.msg);
        location.reload();
      } else {
        toastr.error(json.msg);
      }
      return false;
    }
  });
});
</script>

<?= $this->endSection() ?>
