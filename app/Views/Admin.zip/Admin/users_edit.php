<?php 
if(isset($info)){
		
	$header = 'Edit Employee';
	$id = $info->id;
	$username = $info->username;
	$campus_id = $info->campus_id;
	$email = $info->email;
	$status = intval($info->status);
	$password = $info->password;
	$first_name = $info->first_name;
	$last_name = $info->last_name;
	$dob = $info->dob;
	$f_name = $info->f_name;
	$cnic = $info->cnic;
	$gender = $info->gender;
	$marital_status = $info->marital_status;
	$joining_date = $info->joining_date;
	$mobile_no = $info->mobile_no;
	$mobile_no2 = $info->mobile_no2;
	$address = $info->address;
	$emergency_contact_person = $info->emergency_contact_person;
	$emergency_contact_no = $info->emergency_contact_no;
	$qualification = $info->qualification;
	$experience = $info->experience;
	$skills = $info->skills;
	if($emp_salary_info){
		$salary = $emp_salary_info->salary;
	}else{
		$salary = '';
	}
	
	$contract_start = $info->contract_start;
	$contract_end = $info->contract_end;
	$designation = $info->designation;
	$bank_name = $info->bank_name;
	$account_title = $info->account_title;
	$branch_code = $info->branch_code;
	$account_number = $info->account_number;
	$bank_address = $info->bank_address;
	$photo = $info->photo;
	// $halfday_checkin = $info->halfday_checkin;
	// $halfday_checkout = $info->halfday_checkout;
}else{
	$header = 'Add Employee';
	$id = '';
	$username = '';
	$campus_id = 0;
	$email = '';
	$status = 1;
	$password = '';
	$first_name = '';
	$last_name = '';
	$dob = '';
	$f_name = '';
  $cnic = '';
	$gender = '';
	$marital_status = '';
	$joining_date = '';
	$mobile_no = '';
	$mobile_no2 = '';
	$address = '';
	$emergency_contact_person = '';
	$emergency_contact_no = '';
	$qualification = '';
	$experience = '';
	$skills = '';	
	$contract_start = '';
	$contract_end = '';
	//$halfday_checkin = '';
	//$halfday_checkout = '';
	$salary = '';
	$designation = '';
	$bank_name = '';
	$account_title = '';
	$branch_code = '';
	$account_number = '';
	$bank_address = '';
	$photo = '';
}
?>
 <!-- Content Header (Page header) -->
 <section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
           Employee
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Employee</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
    <section class="content">
      <div class="row">
       <div class="col-lg-12">
		  <div class="card card-primary card-outline card-tabs">
       <div class="card-header p-0 pt-1 border-bottom-0">
				<ul class="nav nav-tabs">
				<?php if($id == ''){ ?>
				<li class="nav-item"><a class="nav-link active" href="<?php echo '#/users?m=add';?>"><?php echo $header;?></a></li>
				<?php }else{ ?>
				<li class="nav-item"><a class="nav-link active" href="<?php echo '#/users?m=edit&id=' . $id;?>"><?php echo $header;?></a></li>
				<?php if($_SERVER['HTTP_HOST'] != 'demo.timesoftsol.com'){ ?>
				<li class="nav-item"><a class="nav-link" href="<?php echo '#/users?m=edit_password&user_id=' . $id;?>">Change Password</a></li>
				<?php } ?>
				<?php } ?>
				<li class="nav-item"><a class="nav-link" href="<?php echo '#/users?status=1';?>">Current Employee</a></li>
				<li class="nav-item"><a class="nav-link" href="<?php echo '#/users?status=0';?>">Dropped Employee</a></li>			
			</ul>
		<div class="card-body">	
		<div class="tab-content">
		<?php 
			echo form_open_multipart('c=users&m=save', 'role="form" id="user-edit-form"');
			echo form_hidden('id', $id);
		?>           
		<div class="row">
			<div class="col-lg-3">
				 <div class="form-group">
                  <label for="first_name">First Name</label>
                  <input type="text" class="form-control" name="first_name" id="first_name" value="<?php echo $first_name;?>">
				</div>
				<div class="form-group">
					<label for="last_name">Last Name</label>
					<input type="text" class="form-control" name="last_name" id="last_name" value="<?php echo $last_name;?>">
				</div>
				<div class="form-group">
                  <label for="username">Username</label>
                  <input type="text" class="form-control" name="username" pattern="^\S*$"  maxlength="30" id="username" value="<?php echo $username;?>">
				  <input type="hidden" id="originalusername"    value="<?php echo $username;?>">
                </div>
				
                <div class="form-group">
                  <label for="tpl_directory">Email</label>
                  <input type="email" class="form-control" name="email" id="email" value="<?php echo $email;?>">
				  <input type="hidden" id="originalemail" value="<?php echo $email;?>">
                </div>
				<?php 
				if($id == ''){
				?>
                <div class="form-group">
                  <label for="password">Password</label>
                  <input type="password" class="form-control" name="password" id="password" value="<?php echo $password;?>">
                </div>
				<?php 
				}
				?>
				<div class="form-group">
				<label for="skills">Skills</label>
				<input type="text" class="form-control" name="skills" id="skills" value="<?php echo $skills;?>">
			</div>
       <div class="form-group">
					<label for="designation">Designation</label>
					<input type="text" class="form-control" name="designation" id="designation" value="<?php echo $designation;?>">
				</div> 

    </div>
    <div class="col-lg-3">
    	  <div class="form-group">
          <label for="dob">CNIC</label>
          <input type="text" class="form-control" name="cnic" required="" id="cnic" value="<?php echo $cnic;?>"  pattern="^[0-9+]{5}-[0-9+]{7}-[0-9]{1}$" data-inputmask='"mask": "99999-9999999-9"' data-mask>
				</div>
				<div class="form-group">
                  <label for="f_first_name">Father Name</label>
                  <input type="text" class="form-control" name="f_name" id="f_first_name" value="<?php echo $f_name;?>">
				</div>
				<div class="form-group">
                  <label for="salary">Salary</label>
                  <input type="text" class="form-control" name="salary" id="salary" value="<?php echo $salary; ?>">
				</div>
			<div class="form-group" style="margin-bottom:23px;">
				  <label for="gender">Gender</label><br>
					<label> <input type="radio" name="gender"  value="male" <?php if($gender == 'male') {?> checked="checked" <?php } ?>> Male</label>
					<label><input type="radio" name="gender" value="female" <?php if($gender == 'female') {?> checked="checked" <?php } ?>> Female</label>
				</div>
				<div class="form-group" style="margin-bottom:23px;">
					<label for="marital_statusmarital_status">Marital Status</label><br>
					<label> <input type="radio" name="marital_status" value="married"  <?php if($marital_status == 'married') {?> checked="checked" <?php } ?> > Married</label>
					<label> <input type="radio" name="marital_status" value="single" <?php if($marital_status == 'single') {?> checked="checked" <?php } ?>> Single</label>
				</div>
				<div class="form-group">
					<label for="contract_start">Contract Start Date</label>
					<input type="date" class="form-control" name="contract_start" id="contract_start" value="<?php echo $contract_start;?>">
				</div> 

	</div>
	<div class="col-lg-3">
		  <div class="form-group">
                  <label for="dob">Date Of Birth</label>
                  <input type="date" class="form-control" name="dob" required="" id="dob" value="<?php echo $dob;?>">
				</div>
		<div class="form-group">
			<label for="joining_date">Joining Date</label>
			<input type="date" class="form-control" name="joining_date" required="" id="joining_date" value="<?php echo date($joining_date);?>">
		</div>
		<div class="form-group">
			<label for="mobile_no">Mobile No</label>
			<input type="text" class="form-control" name="mobile_no" id="mobile_no"  value="<?php echo $mobile_no;?>"  data-inputmask="'mask': '0399-99999999'"  type = "number" maxlength = "12"  data-mask>
		</div>
		<div class="form-group">
			<label for="land_line">Mobile 2</label>
			<input type="text" class="form-control" name="mobile_no2" id="mobile_no2" value="<?php echo $mobile_no2;?>" data-inputmask="'mask': '0399-99999999'"  type = "number" maxlength = "12"  data-mask>
		</div>
		<div class="form-group">
			<label for="address">Addrees </label>
			<input type="text" class="form-control" name="address" id="address" value="<?php echo $address;?>">
		</div>
		<div class="form-group">
			<label for="designation">Contract End Date</label>
			<input type="date" class="form-control" name="contract_end" id="contract_end" value="<?php echo $contract_end;?>">
		</div> 
	</div>
	<div class="col-lg-3">

		<div class="text-center">
    	<?php if($photo){ ?>
    		<img id="output" class="profile-user-img img-fluid img-circle" src="<?php echo base_url();?>employees-img/<?php echo $photo; ?>" alt="User profile picture">
    	<?php }else{ ?>
      <img id="output" class="profile-user-img img-fluid img-circle" src="<?php echo base_url();?>resource/adminlte/dist/img/user4-128x128.jpg" alt="User profile picture">
  		<?php } ?>
  	</div>
  	<div class="form-group text-center">
			<label for="" class="control-label">Photo</label><br>
			<input type="file"  accept="image/*" name="image" id="file"  onchange="loadFile(event)" style="display: none;">
			<label for="file" class="btn btn-default" style="cursor: pointer;"><i class="fa fa-image"></i> Upload Image</label>
		</div>
		<div class="form-group">
			<label for="emergency_contact_person">Emergency Contact Person</label>
			<input type="text" class="form-control" name="emergency_contact_person" id="emergency_contact_person" value="<?php echo $emergency_contact_person;?>">
		</div>
		<div class="form-group">
			<label for="emergency_contact_no">Emergency Contact No</label>
			<input type="text" class="form-control" name="emergency_contact_no" id="emergency_contact_no" value="<?php echo $emergency_contact_no;?>" data-inputmask="'mask': '0399-99999999'"  type = "number" maxlength = "12"  data-mask>
		</div>
		<div class="form-group">
			<label for="qualification">Qualification</label>
			<input type="text" class="form-control" name="qualification" id="qualification" value="<?php echo $qualification;?>">
		</div>
		<div class="form-group">
			<label for="experience">Experience</label>
			<input type="text" class="form-control" name="experience" id="experience" value="<?php echo $experience;?>">
		</div>
		
			
	</div>
	</div>
	<p class="page-header">Bank Account Detail</p>
	<div class="row">
		<div class="col-lg-3">
			<div class="form-group">
			<label for="bank_name">Bank Name</label>
			<input type="text" class="form-control" name="bank_name" id="bank_name" value="<?php echo $bank_name;?>">
			</div>
		</div>
		<div class="col-lg-3">
			<div class="form-group">
			<label for="account_title">Account Title</label>
			<input type="text" class="form-control" name="account_title" id="account_title" value="<?php echo $account_title;?>">
			</div>
		</div>
		<div class="col-lg-3">
			<div class="form-group">
			<label for="branch_code">Branch code</label>
			<input type="text" class="form-control" name="branch_code" id="branch_code" value="<?php echo $branch_code;?>">
			</div>
		</div>
		<div class="col-lg-3">
			<div class="form-group">
			<label for="account_number">Account Number</label>
			<input type="text" class="form-control" name="account_number" id="account_number" value="<?php echo $account_number;?>">
			</div>
		</div>
		<div class="col-lg-3">
			<div class="form-group">
			<label for="bank_address">Bank Address</label>
			<input type="text" class="form-control" name="bank_address" id="bank_address" value="<?php echo $bank_address;?>">
			</div>
		</div>
	</div>
<?php $curr_campus_id = $this->session->userdata['member_campusid'];
      $currentCampusBill = $this->db->query('select * from campus_bills where status=1 AND campus_id='.$curr_campus_id)->row();
      $plan_id = $currentCampusBill->plan_id;
      $this->db->where('plan_id', $plan_id);
      $plan_info = $this->db->get('system_plans')->row(); 
if($plan_info->plan_id == 3){
?>	
<p class="page-header">User Roles</p>
<div class="form-group">
<label>Roles(Select Multi)</label>
	<?php
		$roles = roles_list();
	?>
	<select multiple="multiple" name="roles[]" class="form-control select2" style="width:100%;">
	<?php 
		$userid = $this->session->userdata('member_userid');
		$strSQL = "SELECT * FROM `user_roles` WHERE `userID` = " . floatval($userid) . " ORDER BY `addDate` ASC";
		$currentuserrole = $this->db->query($strSQL)->row();
		$this->db->where('role_name_id', $currentuserrole->roleID);
		$roleNameInfo = $this->db->get('role_name')->row();
		$rolelist = ''; 
		if($roleNameInfo->parent_id == 0){
			$role_name = $this->db->get('role_name')->result();	
			foreach ($role_name as $key => $value) {
			$rolename = $value->rolename;		
		?>
		<option value="<?php echo $value->role_name_id;?>" <?php echo in_array($value->role_name_id, $userRoles) ? 'selected="selected"' : '';?>><?php echo $rolename;?></option>
	<?php } 
	}else{
			$rolenameids = $this->db->query('SELECT @pv:=role_name_id AS rolenameid,rolename,parent_id FROM role_name JOIN (SELECT @pv:= (SELECT MIN(roleid) FROM user_roles WHERE userid =  '.$userid.') ) tmp WHERE parent_id = @pv')->result();
		foreach ($rolenameids as $key => $value) {
			$rolename = $value->rolename;		
			?>
		<option value="<?php echo $value->rolenameid;?>" <?php echo in_array($value->rolenameid, $userRoles) ? 'selected="selected"' : '';?>><?php echo $rolename;?></option>
	<?php } 
		}
 ?>
</select>
</div>
<?php if($id != ''){ ?>
	<p class="page-header">User Permissions <a href="#/users?m=set_perms&user_id=<?php echo $id;?>" title="Change Permissions"><i class="fa fa-gear"></i></a></p>
		<div class="form-group">
			<ul>
			<?php 
				$my_acl = new Member_acl($id);
				$perms = $my_acl->getPermArr();
				foreach ($perms as $k => $v)
				{
					if ($v['value'] === false) { continue; }
					echo "<li>" . $v['Name'];
					if ($v['inheritted']) { echo "  (inherit)"; }
					echo "</li>";
				}
				?></ul>
			</div>
<?php } ?>
<?php } ?>
  <div class="form-group">
    <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
	<button type="reset" class="btn btn-default">Reset</button>
	<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
  </div>
<?php echo form_close();?>
</div>
</div>	
</div>
</div>
</div>
</div>
</section>
    <!-- /.content -->
    <script>
		var loadFile = function(event) {
			var image = document.getElementById('output');
			image.src = URL.createObjectURL(event.target.files[0]);
		};
	</script>
<script type="text/javascript">
$(function(){
	$('.clockpicker').clockpicker();
	$(".select2").select2({closeOnSelect:false});
	$('[data-mask]').inputmask();
	$('#user-edit-form').validate({
		rules:{
			username:{
				required:true,
				remote:{
					param:{
						url:'<?php echo site_url('c=ajax&m=check_emp_value&table=users&field=username');?>'
					},
					depends:function(element){
						var id = $(element).attr('id');
						return ($(element).val() !== $('#original' + id).val());
					}
				}
			},
			email:{
				required:true,
				email:true,
				remote:{
					param:{
						url:'<?php echo site_url('c=ajax&m=check_emp_value&table=users&field=email');?>' 
					},
					depends:function(element){
						var id = $(element).attr('id');
						return ($(element).val() !== $('#original' + id).val());
					}
				}
			},
			password:{
				required:true
			},
			'roles[]':{
				required:true,
				minlength:1
			}
		},
		messages:{
			username:{
				required:'Username is Required',
				remote:'Username is exists'
			},
			email:{
				required:'Email is Required',
				email:'Invalid Email',
				remote:'Email is exists'
			},
			password:{
				required:'password is required'
			},
			'roles[]':{
				required:'Choose A role',
				minlength:'Choose At least one item'
			}
		}
	});	
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			return $('#user-edit-form').valid();
			$('#submitBtn').html("Saving");
      		$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
			$('#submitBtn').html("Save");
      $('#submitBtn').prop('disabled', false);
			var json = JSON.stringify(responseText);
			//var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
				<?php 
				if($id == ''){
					?>
					location.href = '#/users';
					<?php 
				}else{
					?>
					location.href = '#/users?m=edit&id=<?php echo $id;?>&after=edit';
					<?php 
				}
				?>				
			}else{
				//toastr.error(json.msg);
				toastr.success("Edit Employee Success");
			}
			return false;
		}
	});			
});
</script>  