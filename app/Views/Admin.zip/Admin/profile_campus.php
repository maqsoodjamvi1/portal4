<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.6/jquery.inputmask.min.js"></script>
<?php



$schoolinfo = getSchoolInfo();
// Initialize all variables with default values
$id = '';
$campus_name = $short_name = $landline = $mobile_no = $location = '';
$bank_name = $bank_address = $bank_code = $bank_acc = '';
$chalan_h_msg = $chalan_f_msg = $fine_type = $late_fee_fine = '';
$fee_issue_date = $fee_due_date = $attendance_sms = '';
$school = $hostel = $transport = $academy = 0;

if(isset($info) && is_object($info)){
    $header = 'Edit Campus';
    $id = $info->campus_id ?? '';
    $campus_name = $info->campus_name ?? '';
    $short_name = $info->short_name ?? '';
    $landline = $info->landline ?? '';
    $mobile_no = $info->mobile_no ?? '';
    $location = $info->location ?? '';
    $bank_name = $info->bank_name ?? '';
    $bank_address = $info->bank_address ?? '';
    $bank_code = $info->bank_code ?? '';
    $bank_acc = $info->bank_acc ?? '';
    $chalan_h_msg = $info->chalan_h_msg ?? '';
    $chalan_f_msg = $info->chalan_f_msg ?? '';
    $fine_type = $info->fine_type ?? 'per_day_fine';
    $late_fee_fine = $info->late_fee_fine ?? '';
    $fee_issue_date = $info->fee_issue_date ?? 1;
    $fee_due_date = $info->fee_due_date ?? 5;
    $school = $info->s_flag ?? 0;
    $hostel = $info->h_flag ?? 0;
    $transport = $info->t_flag ?? 0;
    $currency_code = $info->currency_code ?? 0;
    $academy = $info->a_flag ?? 0;
} else {
    $header = 'Add Campus';
}
?>

<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Campus Profile</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#/">Dashboard</a></li>
                    <li class="breadcrumb-item active">Campus Profile</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Campus Information</h3>
                </div>
                <?php echo form_open_multipart('c=profile_campus&m=save', 'role="form" id="user-edit-form"'); ?>
                <?php echo form_hidden('id', $id); ?>
                
                <div class="card-body">
                    <!-- Loader -->
                    <div class="loader" id="loader-1" style="display: none;">
                        <span></span><span></span><span></span><span></span>
                    </div>

                    <!-- Basic Information Section -->
                    <div class="row">
                      <div class="form-section">
    <h5 class="section-title">Basic Information</h5>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label>Campus Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="campus_name" 
                       value="<?= $campus_name ?>" required maxlength="150">
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="form-group">
                <label>Short Name</label>
                <input type="text" class="form-control" name="short_name" 
                       value="<?= $short_name ?>">
            </div>
        </div>
        
       <div class="col-md-4">
    <div class="form-group">
        <label>Landline</label>
        <input type="tel" class="form-control" name="landline" 
               value="<?= $landline ?>"
               data-inputmask="'mask': '+999999999999999'"
               title="Format: +CountryCode Area Number (e.g., +1 234 567890)">
        <small class="input-hint">E.g. +1 234 567890 or 022345678</small>
    </div>
</div>

    <div class="row">
        <div class="col-md-4">
    <div class="form-group">
        <label>Mobile Number <span class="text-danger">*</span></label>
        <input type="tel" class="form-control" name="mobile_no" 
               value="<?= $mobile_no ?>" required
               maxlength="15"   pattern="^\+[0-9]{6,15}$"
               data-inputmask="'mask': '+999999999999999'"
               title="International format: +CountryCode Number (e.g., +923001234567)">
        <small class="input-hint">E.g. +923001234567 (without spaces)</small>
    </div>
</div>
        
        <div class="col-md-8">
            <div class="form-group">
                <label>Location</label>
                <input type="text" class="form-control" name="location" 
                       value="<?= $location ?>">
            </div>
        </div>
    </div>
</div>

                    <!-- Services Section -->
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <h5 class="section-header">Services</h5>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group clearfix">
                                        <div class="icheck-primary">
                                            <input type="checkbox" name="school" id="school" 
                                                   <?= $school ? 'checked disabled' : '' ?> value="1">
                                            <label for="school">School</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group clearfix">
                                        <div class="icheck-primary">
                                            <input type="checkbox" name="transport" id="transport" 
                                                   <?= $transport ? 'checked disabled' : '' ?> value="1">
                                            <label for="transport">Transport</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group clearfix">
                                        <div class="icheck-primary">
                                            <input type="checkbox" name="hostel" id="hostel" 
                                                   <?= $hostel ? 'checked disabled' : '' ?> value="1">
                                            <label for="hostel">Hostel</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group clearfix">
                                        <div class="icheck-primary">
                                            <input type="checkbox" name="academy" id="academy" 
                                                   <?= $academy ? 'checked disabled' : '' ?> value="1">
                                            <label for="academy">Academy</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Financial Information Section -->
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <h5 class="section-header">Financial Information</h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Bank Name</label>
                                        <input type="text" class="form-control" name="bank_name" 
                                               value="<?= $bank_name ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Bank Account Number</label>
                                        <input type="text" class="form-control" name="bank_acc" 
                                               value="<?= $bank_acc ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Bank Code</label>
                                        <input type="text" class="form-control" name="bank_code" 
                                               value="<?= $bank_code ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Bank Address</label>
                                        <input type="text" class="form-control" name="bank_address" 
                                               value="<?= $bank_address ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

						                    	<!-- Regional Settings -->
						<p class="col-lg-12" style="font-weight: bold;margin-top: 15px;text-decoration: underline;">Regional Settings</p>

						<div class="form-group col-lg-4">
     <option value="" disabled <?= !isset($info->default_language) ? 'selected' : '' ?>>Select Language</option>
    <label for="default_language">Default Language</label>
   <select class="form-control" name="default_language" id="default_language" required>
    <?php foreach ($languages as $lang): 
        $selected = (isset($info->default_language) && $info->default_language == $lang->code) ? 'selected' : '';
    ?>
    <option value="<?= $lang->code ?>" <?= $selected ?>>
        <?= htmlspecialchars($lang->name) ?>
    </option>
    <?php endforeach; ?>
</select>
</div>

<div class="form-group col-lg-4">
    <label for="default_currency">Default Currency</label>
    <select class="form-control" name="currency_code" id="currency_code" required>
        <?php foreach ($currencies as $curr): ?>
        <option value="<?= $curr->code ?>" <?= (isset($info->currency_code) && $info->currency_code == $curr->code) ? 'selected' : '' ?>>
            <?= $curr->name ?> (<?= $curr->symbol ?>)
        </option>
        <?php endforeach; ?>
    </select>
</div>



                    <!-- Fee Settings Section -->
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <h5 class="section-header">Fee Settings</h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Fee Issue Date</label>
                                        <select class="form-control select2" name="fee_issue_date">
                                            <?php for($i=1; $i<=31; $i++): ?>
                                            <option value="<?= $i ?>" <?= $fee_issue_date == $i ? 'selected' : '' ?>>
                                                <?= $i ?>
                                            </option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Fee Due Date</label>
                                        <select class="form-control select2" name="fee_due_date">
                                            <?php for($i=1; $i<=31; $i++): ?>
                                            <option value="<?= $i ?>" <?= $fee_due_date == $i ? 'selected' : '' ?>>
                                                <?= $i ?>
                                            </option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Fine Type</label>
                                        <select class="form-control select2" name="fine_type">
                                            <option value="per_day_fine" <?= $fine_type == 'per_day_fine' ? 'selected' : '' ?>>Per Day Fine</option>
                                            <option value="fixed_fine" <?= $fine_type == 'fixed_fine' ? 'selected' : '' ?>>Fixed Fine</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Late Fee Fine Amount</label>
                                        <input type="number" class="form-control" name="late_fee_fine" 
                                               value="<?= $late_fee_fine ?>">
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Chalan Header Message</label>
                                        <textarea class="form-control" name="chalan_h_msg"><?= $chalan_h_msg ?></textarea>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Chalan Footer Message</label>
                                        <textarea class="form-control" name="chalan_f_msg"><?= $chalan_f_msg ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Form Footer -->
                <div class="card-footer">
                    <div class="row">
                        <div class="col-md-12 text-right">
                            <button type="submit" class="btn btn-primary mr-2">
                                <i class="fas fa-save"></i> Save Changes
                            </button>
                            <button type="reset" class="btn btn-default mr-2">Reset</button>
                            <a href="#/" class="btn btn-default">Cancel</a>
                        </div>
                    </div>
                </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</section>

<style>
.section-header {
    border-bottom: 1px solid #dee2e6;
    padding-bottom: 0.5rem;
    margin-bottom: 1.5rem;
    color: #007bff;
    font-weight: 500;
}
.icheck-primary { margin-top: 8px; }
.card-footer { background: #f8f9fa; }


.form-section {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}
.section-title {
    color: #2c3e50;
    font-weight: 600;
    border-bottom: 2px solid #3498db;
    padding-bottom: 10px;
    margin-bottom: 20px;
}
.input-hint {
    font-size: 0.85rem;
    color: #7f8c8d;
    margin-top: 4px;
}

</style>

<script>
    $(function() {
    // Initialize Select2
    $('.select2').select2({
        theme: 'bootstrap4',
        minimumResultsForSearch: Infinity
    });

    // Apply input masks
    $('[name="mobile_no"]').inputmask({
        mask: '+999999999999999',
        placeholder: '',
        greedy: false,
        definitions: {
            '9': {
                validator: "[0-9]",
                cardinality: 1
            }
        }
    });

    $('[name="landline"]').inputmask({
        mask: '+999999999999999',
        placeholder: '',
        greedy: false,
        definitions: {
            '9': {
                validator: "[0-9]",
                cardinality: 1
            }
        }
    });

    // Checkbox confirmation handling
    $('input[type="checkbox"][name="school"], input[type="checkbox"][name="transport"], input[type="checkbox"][name="hostel"], input[type="checkbox"][name="academy"]').change(function() {
        const service = $(this).attr('name');
        const action = $(this).prop('checked') ? 'activate' : 'disable';
        
        if(!confirm(`Are you sure you want to ${action} ${service}?`)) {
            $(this).prop('checked', !$(this).prop('checked'));
        }
    });

    // Form submission handler
    $('#user-edit-form').ajaxForm({
        beforeSubmit: function() {
            $('#loader-1').show();
        },
        success: function(response) {
            $('#loader-1').hide();
            const json = JSON.parse(response);
            if(json.success) {
                toastr.success(json.msg);
                setTimeout(() => window.location.href = '#/profile_campus', 1500);
            } else {
                toastr.error(json.msg);
            }
        }
    });
});

    $('#user-edit-form').validate({
    rules: {
        mobile_no: {
            required: true,
            pattern: /^\+[0-9]{6,15}$/
        },
        landline: {
            pattern: /^\+?[0-9\s\-\(\)]{6,20}$/
        }
    },
    messages: {
        mobile_no: {
            pattern: "Please enter a valid international mobile number (e.g., +923001234567)"
        },
        landline: {
            pattern: "Please enter a valid landline number"
        }
    }
});
</script>