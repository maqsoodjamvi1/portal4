<?php
	if(isset($info)){
		$header = 'Edit Campus Chalan';
		$id = $info->campus_id;
		$campus_name = $info->campus_name;
		
	}else{
		$header = 'Add Campus Chalan';
		$id = '';
		$chalan_type_name = '';
		$chalan_type_detail = '';
	}
?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-8">
            <h1>
               Campus Chalan    	
            </h1>
          </div>
          <div class="col-sm-4">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Campus Chalan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
		  <div class="card card-primary card-outline card-tabs">
          	<div class="card-header p-0 pt-1 border-bottom-0">
			<ul class="nav nav-tabs">
				<?php if($id == ''){ ?>
					<li class="nav-item"><a class="nav-link active" href="<?php echo '#/campus_chalan';?>"><?php echo $header;?></a></li>
				<?php }else{ ?>
					<li class="nav-item"><a class="nav-link active" href="<?php echo '#/campus_chalan?m=edit&id=' . $id;?>"><?php echo $header;?></a></li>
				<?php } ?>
				<li class="nav-item"><a class="nav-link" href="<?php echo '#/campus_chalan_single?m=download&id='.$id.'&after=edit';?>">View Campus Chalan</a></li>
				<li class="nav-item"><a class="nav-link" href="<?php echo '#/campus_chalan_pay';?>">Pay Campus Chalan</a></li>
			</ul>
			<div class="card-body">
			<div class="tab-content">
				<div class="row">
					<div class="col-lg-12">
						<p class="page-header">Campus chalan of <?php echo $campus_name;?></p>
					</div>
				</div>
			<?php	
			echo form_open('c=campus_chalan&m=save', 'role="form" id="user-edit-form"');
			echo form_hidden('campus_id', $id);
			?>
				<div class="row">
				<?php if($bill_plans_data){ 
					foreach ($bill_plans_data as $key => $bill_plans_value) {
					echo "<div class='col-lg-12'><h4><input required name='plan_id' value='".$bill_plans_value['plan_id']."' type='radio'> ".$bill_plans_value['plan_name']."</h4></div>";
				 	if(isset($bill_type_info)){
					foreach ($bill_type_info as  $bill_type_value) { ?>
						<div class="col-lg-4"> <div class="form-group"><label><input  type="checkbox" name="bill_type_name_<?php echo $bill_plans_value['plan_id']; ?>[]" value="<?php echo $bill_type_value['bill_type_id']; ?>" checked="checked" required>
						</label> 
						<?php echo $bill_type_value['bill_type_name']; ?>
						<input type="text" class="form-control" name="bill_amount_<?php echo $bill_plans_value['plan_id']; ?>[<?php echo $bill_type_value['bill_type_id']; ?>]" value="<?php echo $bill_type_value['amount']; ?>" required />
						</div></div>
						<?php 
								} 
								} 
								}
							} 
						?>
			</div>		
			<div class="row">	
        	  <div class="col-lg-4">
				<div class="form-group">
                <label>Issue Date:</label>
                <div class="input-group date" id="datepicker2" data-target-input="nearest">
                	<input type="text" class="form-control datetimepicker-input" data-target="#datepicker2"  name="issue_date" required value=""/>
                	<div class="input-group-append" data-target="#datepicker2" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                	</div>
              	</div>
                <!-- /.input group -->
              </div>				
			  </div>
			   <div class="col-lg-4">      
				<div class="form-group">
                <label>Due Date:</label>
                <div class="input-group date" id="datepicker" data-target-input="nearest">
                	<input type="text" class="form-control datetimepicker-input" data-target="#datepicker"  name="due_date" required value=""/>
                	<div class="input-group-append" data-target="#datepicker" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                	</div>
              	</div>
                <!-- /.input group -->
              </div>
			  </div>
			  <div class="col-lg-4">			
						
       		</div>	</div>
			<div class="row">
            <div class="col-lg-12">  <div class="form-group">
                <button type="submit"  id="submitBtn" class="btn btn-primary">Save</button>
				<button type="reset" class="btn btn-default">Reset</button>
				<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
              </div>
			  </div>
			  </div>
            <?php echo form_close();?>
			</div>
		  </div>
        </div>
      </div>
    </div>
    </div>  
</section>
<!-- /.content -->
<script type="text/javascript">
	$(function () {

		$('#datepicker2').datetimepicker({
		  format: 'DD/MM/YYYY',
		  defaultDate:'now'
		});

		var myDate = new Date(new Date().getTime()+(10*24*60*60*1000));
		
	  $('#datepicker').datetimepicker({
		  format: 'DD/MM/YYYY',
		  defaultDate:myDate

		});

		$('#datetimepicker10').datetimepicker({
            viewMode: 'years',
            format: 'MM/YYYY',
        });
    });
	
</script>
<script type="text/javascript">
$(function(){
  	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			//return $('#user-edit-form').valid();
		},
		success:function(responseText, statusText, xhr, form){
			var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
				<?php if($id == ''){ ?>
				location.href = '#/campus_chalan_pay';
				<?php }else{ ?>
				location.href = '#/campus_chalan_pay';
				<?php } ?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
});
</script>
