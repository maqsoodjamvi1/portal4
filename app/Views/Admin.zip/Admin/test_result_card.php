<link rel="stylesheet" href="<?php echo base_url();?>resource/bootstrap-switch/css/bootstrap3/bootstrap-switch.min.css" />
<!-- Content Header (Page header) -->
<style>
	.list-group-item{
	  	width: 33% !important;
	    float: left !important;
	    padding: 1px 10px !important;
	    border-right: 0 none;
	    border-left: 0 none;
	}
	table{
	background-color: transparent;
    border: 2px solid #000;
    margin-top: 2px;
    float: left;
	}
	.table-bordered>thead>tr>th, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>tbody>tr>td, .table-bordered>tfoot>tr>td{
		border:1px solid #333;
	}
	.heading2{
   			border:2px solid #000;float:left;width:100%;background:#800000;text-align:center;font-weight:bold;padding: 5px;font-size: 18px;color: #fff;line-height: 20px;
   		}
.heading{
   		border:2px solid #000;float:left;width:100%;text-align:center;font-weight:bold;padding: 5px; background:#800000;font-size: 18px;color: #fff;line-height: 20px;
   		}
	@media print {
		body {-webkit-print-color-adjust: exact;}
   		.heading{
   			border:2px solid #000;float:left;width:100%;text-align:center;font-weight:bold;padding: 5px; background:maroon;font-size: 18px;color: #fff;line-height: 20px;background-color: #800000 !important;
        -webkit-print-color-adjust: exact;
   		}
   		.heading2{
   			border:2px solid #000;float:left;width:100%;background:maroon;text-align:center;font-weight:bold;padding: 5px;font-size: 18px;color: #fff;line-height: 20px;background-color: #800000 !important;
        -webkit-print-color-adjust: exact;
   		}

   	.no-print,.nav-tabs,.main-footer,.no-print *
      {
          display: none !important;
      }
  	}
</style>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
           Test Results
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Test Results</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content"> 
<div class="row">
  <div class="col-lg-12">
     <div class="card card-primary card-outline card-tabs" style="background: #fff !important;">
       	<div class="card-header p-0 pt-1 border-bottom-0">
     	<ul class="nav nav-tabs .no-print">
 			<li class="nav-item"><a class="nav-link" href="<?php echo '#/test_results?m=add';?>">Add Results</a></li>
	    <li class="nav-item"><a class="nav-link active" href="<?php echo '#/test_result_card';?>">View Results Cards</a></li>	
 		</ul>
		<div class="card-body">
		<div class="no-print">
		<div class="col-lg-12">
		<label for="class"><strong>Academic Result</strong></label><br>
		<ul class="list-group list-group-horizontal">
			<li class="list-group-item">
			<div class="icheck-primary d-inline">	
			<input type="checkbox" class="academic_results" id="marks" name="academic_result[]" value="marks"><label for="marks"> Marks</label>
			</div>
			</li>
			<li class="list-group-item">
			<div class="icheck-primary d-inline">	
			<input type="checkbox" class="academic_results" id="percentage" name="academic_result[]" value="percentage"><label for="percentage"> Percentage</label>
			</div>
			</li>
			<li class="list-group-item">
			<div class="icheck-primary d-inline">	
			<input type="checkbox" class="academic_results" id="grade" name="academic_result[]" value="grade"><label for="grade"> Grade</label>
			</div>
			</li>
			<li class="list-group-item">
			<div class="icheck-primary d-inline">	
			<input type="checkbox" class="academic_results" id="position" name="academic_result[]" value="position"> <label for="position">Position</label>
			</div>
			</li>
			
		</ul>
	</div>
		<div class="col-lg-12">
		<label for="class"><strong>Tests</strong></label><br>
		<ul class="">
		<?php  foreach ($test_series as $key => $test) { ?>
			<li class="list-group-item" style="width:20% !important;"><input type="checkbox" class="testids" id="test_id<?php echo $test->t_series_id; ?>" name="test_id" value="<?php echo $test->t_series_id; ?>">
				<div class="icheck-primary d-inline">
				 <label for="t_series_id<?php echo $test->series_name; ?>"><?php echo $test->series_name; ?></label>
				</div>
			</li>
		<?php } ?>
		</ul>
		</div>
		<div class="row" style="clear: both;">
		<div class="col-lg-6 form-group">
			<label for="class"><strong>Class</strong></label><br>
				<select class="form-control" name="cls_sec_id" id="cls_sec_id">
					<option value="">All Classes</option>
				<?php if(isset($sectionsclassinfo)){
					foreach ($sectionsclassinfo as  $sectionvalue) {
				 ?>
				<option value="<?php echo $sectionvalue['section_id']; ?>"><?php echo $sectionvalue['sectionclassname']; ?></option>
				<?php } ?>
				<?php } ?>	
				</select>
		</div>
		</div>
		<div class="col-lg-12"><input style="line-height: 19px;margin: 10px 0px;" type="button" class="btn btn-primary pull-right" value="View Result Card " name="View" id="ViewResutlt"></div>
	</div>
		<div id="loader-1" class="overlay col-md-12 text-center" style="display: none;"><i class="fas fa-2x fa-sync-alt fa-spin"></i></div>
	<div id="resultContainer"></div>
    </div>
    </div>
</div>
</div>
</div>
</section>
<!-- /.content -->
<script src="<?php echo base_url();?>resource/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script type="text/javascript">
$(function(){
	$('#ViewResutlt').on('click', function() {	
	$("#loader-1").css("display", "block");	
	var academic_result = [];
	var testids = [];
	var non_academics = [];
	$(".academic_results:checked").each(function(i, e) {
	    academic_result.push($(this).val());
	});

	$(".testids:checked").each(function(i, e) {
	    testids.push($(this).val());
	});

	$(".non_academics:checked").each(function(i, e) {
	    non_academics.push($(this).val());
	});

	var cls_sec_id = $('#cls_sec_id').val();
	
	$.ajax({
            url: 'admin.php?c=test_result_card&m=data',
            type: "POST",
            data:{academic_result:academic_result,testids:testids,non_academics:non_academics,cls_sec_id:cls_sec_id},
            success:function(res){
 			  // alert(res);		  
			   $("#resultContainer").html(res);
			   $("#loader-1").css("display", "none");
 			}
         });
	});
});
</script>