<?= $this->extend('layouts/admin_template') ?>

<?php $this->section('content') ?>

<?php  //$this->section('styles') ?>
<style type="text/css">
    ul.ztree {margin-top: 10px;overflow-y:none;overflow-x:auto;}
    .ztree li span.button.add {margin-left:2px; margin-right: -1px; background-position:-144px 0; vertical-align:top; *vertical-align:middle}
</style>
<link rel="stylesheet" href="<?= base_url('resource/ztree/css/zTreeStyle/zTreeStyle.css') ?>" />
<?php //$this->endSection() ?>

<?php //$this->section('scripts') ?>
<script type="text/javascript" src="<?= base_url('resource/ztree/js/jquery.ztree.core-3.5.js') ?>"></script>
<script type="text/javascript" src="<?= base_url('resource/ztree/js/jquery.ztree.excheck-3.5.js') ?>"></script>
<script type="text/javascript" src="<?= base_url('resource/ztree/js/jquery.ztree.exedit-3.5.js') ?>"></script>
<?php //$this->endSection() ?>

<?php //$this->section('content') ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Permissions</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= base_url('/') ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Permissions</li>
                </ol>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-primary card-outline card-tabs">
                <div class="card-header p-0 pt-1 border-bottom-0">    
                    <ul class="nav nav-tabs">
                        <li class="nav-item"><a class="nav-link active" href="<?= base_url('admin/permissions') ?>">Permissions</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?= base_url('admin/permissions/add') ?>">Add Permissions</a></li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="col-lg-12">
                        <div class="teachersection" id="teachersection"></div>
                        All nodes <a href="javascript:;" id="expandAllBtn">expand</a> | <a href="javascript:;" id="collapseAllBtn">collapse</a>
                        <ul id="treeDemo" class="ztree"></ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php //$this->endSection() ?>

<?php //$this->section('footer_scripts') ?>
<script type="text/javascript">
    $(function(){
        $.ajax({
            url: '<?= base_url('admin/permissions/data2') ?>', 
            type: "POST",
            data: {},
            success: function(res) {
                console.log(res);
                var json = $.parseJSON(responseText);
                $("#teachersection").html(json);
            }
        });
    });

    var IDMark_Switch = "_switch",
    IDMark_Icon = "_ico",
    IDMark_Span = "_span",
    IDMark_Input = "_input",
    IDMark_Check = "_check",
    IDMark_Edit = "_edit",
    IDMark_Remove = "_remove",
    IDMark_Ul = "_ul",
    IDMark_A = "_a";

    var setting = {
        view: {
            addHoverDom: addHoverDom,
            removeHoverDom: removeHoverDom,
            addDiyDom: addDiyDom,
            selectedMulti: false
        },
        edit: {
            enable: true,
            editNameSelectAll: true,
            showRemoveBtn: showRemoveBtn,
            showRenameBtn: showRenameBtn,
            removeTitle: 'delete permission',
            renameTitle: 'edit pemission'
        },
        async: {
            enable: true,
            url: '<?= base_url('admin/permissions/data') ?>',
            autoParam: [],
            otherParam: {}
        },
        callback: {
            beforeRemove: beforeRemove,
            beforeEditName: beforeEditName,
            onRemove: onRemove
        }
    };
    
    function beforeRemove(treeId, treeNode) {
        var zTree = $.fn.zTree.getZTreeObj(treeId);
        zTree.selectNode(treeNode);
        return confirm('Cofirm -- ' + treeNode.name + "？");
    }
    
    function onRemove(event, treeId, treeNode) {
        console.log(treeNode);
        $.get('<?= base_url('admin/permissions/delete') ?>', {id: treeNode.id}, function(data) {
            var json = $.parseJSON(data);
            if(json.success) {
                toastr.success(json.msg);
            } else {
                toastr.error(json.msg);
            }
        });
    }
    
    function beforeEditName(treeId, treeNode) {
        location.href = '<?= base_url('admin/permissions/edit') ?>?id=' + treeNode.id;
        return false;
    }
    
    function showRemoveBtn(treeId, treeNode) {
        if(treeNode.hasOwnProperty('children')) {
            return false;
        } else {
            return true;
        }
    }
    
    function showRenameBtn(treeId, treeNode) {
        return true;
    }
    
    var newCount = 1;
    
    function addHoverDom(treeId, treeNode) {
        var sObj = $('#' + treeNode.tId + '_span');
        if(treeNode.editNameFlag || $('#addBtn_' + treeNode.tId).length>0) return;
        var addStr = '<span class="button add" id="addBtn_' + treeNode.tId + '" title="" onfocus="this.blur();"></span>';
        sObj.after(addStr);
        var btn = $('#addBtn_' + treeNode.tId);
        if(btn) {
            btn.bind('click', function() {
                location.href = '<?= base_url('admin/permissions/add') ?>?parent_id=' + treeNode.id;
                return false;
            });
        } 
    }
    
    function removeHoverDom(treeId, treeNode) {
        $('#addBtn_' + treeNode.tId).unbind().remove();
    }
    
    function addDiyDom(treeId, treeNode) {
        var aObj = $('#' + treeNode.tId + IDMark_A);
        var diyStr = '(' + treeNode.permKey + ')';
        aObj.after(diyStr);
    }
            
    $(document).ready(function() {
        $.fn.zTree.init($("#treeDemo"), setting);
        $('#expandAllBtn').on('click', function() {
            var zTree = $.fn.zTree.getZTreeObj('treeDemo');
            zTree.expandAll(true);
        });
        $('#collapseAllBtn').on('click', function() {
            var zTree = $.fn.zTree.getZTreeObj('treeDemo');
            zTree.expandAll(false);
        });
    });
</script>
<?= $this->endSection() ?>