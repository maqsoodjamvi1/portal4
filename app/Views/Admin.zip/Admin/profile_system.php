<?php
	if(isset($info)){
		$header = 'Edit System';
		$id = $info->system_id;
		$system_name = $info->system_name;
		$address = $info->address;
		$city = $info->city;
		$state = $info->state;
		$zip = $info->zip;
		$country = $info->country;
		$owner_name = $info->owner_name;
		$landline_number = $info->landline_number;
		$mob_number = $info->mob_number;
		$reg_text = $info->reg_text;
		$logo = $info->logo;
		$chalan_header = $info->chalan_header;
		$slogan = $info->slogan;
		if($sms_settings_info){
			$masking_name = $sms_settings_info->masking_name;
			$api_secret = $sms_settings_info->api_secret;
			$api_token = $sms_settings_info->api_token;
		}else{
			$masking_name = '';
			$api_secret = '';
			$api_token = '';
		}
	}else{
		$header = 'Add System';
		$id = '';
		$id = '';
		$system_name = '';
		$short_name = '';
		$address = '';
		$city = '';
		$state = '';
		$zip = '';
		$country = '';
		
		$owner_name = '';
		$landline_number = '';
		$mob_number = '';
		$reg_text = '';
		$logo = '';
		$slogan = '';
		$masking_name = '';
		$api_secret = '';
		$api_token = '';
		$chalan_header = '';
	}
?>
<!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          <h1>
         System Profile
        <?php 
            $schoolinfo = getSchoolInfo();
            	if(empty($schoolinfo->reg_text)){ ?>
					<span style='background: green;color: #fff !important;float: right;padding: 5px 10px;margin-top: 0px;font-size: 16px;'>Step 1 Of 12 To Complete System Configuration</span>
    				<div style="text-align: center;">
    				<audio autoplay  controls>
						 <source src="audio/Step1CampusProfile.m4a" type="audio/ogg">
						  <source src="audio/Step1CampusProfile.m4a" type="audio/mpeg">
						Your browser does not support the audio element.
						</audio> 
					</div>
				<?php	} ?> 
          </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">System Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-3">
          <!-- Profile Image -->
          <div class="card card-primary card-outline">
            <div class="card-body box-profile">
            <div class="text-center">
            	<?php if($logo){ ?>
            		<img id="output" class="profile-user-img img-fluid" src="<?php echo base_url();?>system-logo/<?php echo $logo; ?>" alt="User profile picture">
            	<?php }else{ ?>
              <img id="output" class="profile-user-img img-fluid" src="<?php echo base_url();?>system-logo/Time-soft-sol-logo.png" alt="User profile picture">
          		<?php } ?>
          	</div>	
              <!-- <img id="output"  style="width:100px;" /> -->
             <h3 class="profile-username text-center"><?php echo $system_name;?></h3>
              <p class="text-muted text-center"></p>
              
              <a href="<?php echo site_url('c=logout');?>" class="btn btn-danger btn-block"><b>Logout</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
           <!-- Profile Image -->
          <div class="card card-primary card-outline">
            <div class="card-body box-profile">	
          	 <div class="text-center">
            	<?php if($chalan_header){ ?>
            		<img id="output2" class="profile-user-img img-fluid" src="<?php echo base_url();?>system-logo/<?php echo $chalan_header; ?>" alt="User profile picture">
            	<?php }else{ ?>
              <img id="output2" class="profile-user-img img-fluid" src="<?php echo base_url();?>system-logo/Time-soft-sol-logo.png" alt="User profile picture">
          		<?php } ?>
          	</div>	
              <!-- <img id="output"  style="width:100px;" /> -->       
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="card">
            <div class="card-header p-2">
              <ul class="nav nav-pills">
              <li class="nav-item"><a class="nav-link active" href="#settings" data-toggle="tab">Settings</a></li>
	        </ul>
        	</div>
        	<div class="card-body">
            <div class="tab-content">
              <div class="active tab-pane" id="settings">
               <?php 
				echo form_open_multipart('c=profile_system&m=save', 'role="form" id="user-edit-form"');
				echo form_hidden('id', $id);
				?>   
				<div class="row"> 
				<div class="col-md-12 bg">
		        <div class="loader" id="loader-1" style="display: none;">
		          <span></span>
		          <span></span>
		          <span></span>
		          <span></span>
		        </div>
		    </div> 
           <div class="col-lg-4">
              <div class="form-group">
                  <label for="inputName" class="control-label">System Name</label>
                  <input type="text" name="system_name" id="system_name" class="form-control"  value="<?php echo $system_name;?>">
            </div>
       			<div class="form-group">
                  <label for="tpl_directory">City</label>
                  <input type="text" class="form-control" name="city" id="city" value="<?php echo $city;?>">
				 		</div>
						<div class="form-group">
							<label for="address">Owner Name</label>
							<input type="text" class="form-control" name="owner_name" id="owner_name" value="<?php echo $owner_name;?>">
						</div>
						<div class="form-group">
							<label for="address">Address</label>
							<input type="text" class="form-control" name="address" id="address" value="<?php echo $address;?>">
						</div>
            </div>
            <div class="col-lg-4"> 	
            	 <div class="form-group">
								<label for="reg_text">System Short Name (e.g TSS in 19-TSS-02) <span class="text-danger">*</span></label>
								<input type="text" class="form-control" required="" name="reg_text" id="reg_text"  maxlength="3" value="<?php echo $reg_text;?>">	
						</div>    
				<div class="form-group">
					<label for="joining_date">State</label>
					<input type="text" class="form-control" name="state"  id="state" value="<?php echo $state;?>">
				</div>
				<div class="form-group">
					<label for="address_1">Zip </label>
					<input type="text" class="form-control" name="zip" id="zip" value="<?php echo $zip; ?>">
				</div>
				<div class="form-group">
					<label for="address_1">Country </label>
					<input type="text" class="form-control" name="country" id="country" value="<?php echo $country; ?>">
				</div>
		</div>
		<div class="col-lg-4">
		
		<div class="form-group">
			<label for="landline_number">Landline No</label>
			<input type="text" class="form-control" name="landline_number" id="landline_number" value="<?php echo $landline_number;?>">
		</div>
		<div class="form-group">
			<label for="mob_number">Mobile No</label>
			<input type="text" class="form-control" name="mob_number" id="mob_number" value="<?php echo $mob_number;?>"  required="" >
		</div>
		<div class="form-group">
			<label for="slogan">Slogan</label>
			<input type="text" class="form-control" name="slogan" id="slogan" value="<?php echo $slogan;?>">
		</div>
		<div class="form-group">
			<label for="" class="control-label">School Logo</label><br>
			<input type="file"  accept="image/*" name="image" id="file"  onchange="loadFile(event)" style="display: none;">
			<label for="file" class="btn btn-default" style="cursor: pointer;"><i class="fa fa-image"></i> Upload Logo</label>
		</div>
		<div class="form-group">
			<label for="" class="control-label">Fee Header</label><br>
			<input type="file"  accept="image/*" name="image2" id="file2"  onchange="loadFile2(event)" style="display: none;">
			<label for="file2" class="btn btn-default" style="cursor: pointer;"><i class="fa fa-image"></i> Upload Logo</label>
		</div>
		</div>
		<div class="col-lg-12">
			<h4>Branded SMS Settings</h4>
			<div class="row">
				<div class="col-lg-4">
					<div class="form-group">
						<label class="control-label">Masking Name</label><br>
						<input type="text"  class="form-control" readonly name="masking_name" id="masking_name" value="<?php echo $masking_name; ?>"  >
					</div>
				</div>
				<div class="col-lg-4">
					<div class="form-group">
						<label class="control-label">Api Token</label><br>
						<input type="text" class="form-control" readonly name="api_token" id="api_token" value="<?php echo $api_token; ?>">
					</div>
				</div>
				<div class="col-lg-4">
					<div class="form-group">
						<label class="control-label">Api Secret</label><br>
						<input type="text"  class="form-control" readonly name="api_secret" id="api_secret" value="<?php echo $api_secret; ?>">
					</div>
				</div>
			</div>
		</div>
	  <div class="col-lg-12">
      <div class="form-group">
      <button type="submit" id="saveProfile" class="btn btn-primary">Save</button>
			<button type="reset" class="btn btn-default">Reset</button>
			<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
      </div>
      </div>
     </div>     
    </form>
  </div>
  <!-- /.tab-pane -->
  </div>
</div>
    <!-- /.tab-content -->
  </div>
  <!-- /.nav-tabs-custom -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->
</section>
<script>
		var loadFile = function(event) {
			var image = document.getElementById('output');
			image.src = URL.createObjectURL(event.target.files[0]);
		};

		var loadFile2 = function(event) {
			var image2 = document.getElementById('output2');
			console.log(image2);
			image2.src = URL.createObjectURL(event.target.files[0]);
		};
	</script>
<script type="text/javascript">
	$(function(){
		
	$(".select2").select2({closeOnSelect:false});
	$('[data-mask]').inputmask();
	$('#user-edit-form').validate({
		rules:{
			reg_text:{
				required:true,
				// remote:{
				// 	param:{
				// 		url:'<?php //echo site_url('c=ajax&m=check_emp_value&table=system&field=reg_text');?>'
				// 	},
				// 	depends:function(element){
				// 		var id = $(element).attr('id');
				// 		return ($(element).val() !== $('#original' + id).val());
				// 	}
				// }
			},
			email:{
				required:true,
				email:true,
			} 
			
		},
		messages:{
			reg_text:{
				required:'Reg Text is Required',
				remote:'Reg Text is exists'
			},
			email:{
				required:'Email is Required',
				email:'Invalid Email',
			}
		}
	});	
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			return $('#user-edit-form').valid();
		},
		success:function(responseText, statusText, xhr, form){
			var json = $.parseJSON(JSON.stringify(responseText));
			if(json.session_id == false){
	        	window.location.href = '<?php echo base_url() . $this->config->item('index_page');?>#/academic_session?m=add';
	        	return;
	      	}
			if(json.success){
				toastr.success(json.msg);
				location.href = '#/profile_system';
							
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
	});			
</script> 