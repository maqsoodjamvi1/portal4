
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
               Roles
            </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Roles</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
          <div class="card card-primary card-outline card-tabs">
            <div class="card-header p-0 pt-1 border-bottom-0">	
			<ul class="nav nav-tabs">
				<li class="nav-item"><a class="nav-link active" href="<?php echo '#/roles';?>">Roles</a></li>
				<li class="nav-item"><a class="nav-link" href="<?php echo '#/roles?m=add';?>">Add Role</a></li>
			</ul>
		<div class="card-body">
		<div class="col-lg-12">
              <table class="table table-striped table-bordered table-hover" id="roles-datatable" width="100%">
				<thead>
					<tr>
						<th nowrap>#</th>
						<th nowrap>Role Name</th>
						<th nowrap>Plan</th>
						<th nowrap>Operation</th>
					</tr>
				</thead>
				<tbody>
				   
				</tbody>
			</table></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>    
    </section>
    <!-- /.content -->
<script type="text/javascript">
$(function(){
	var table = $('#roles-datatable').DataTable({
		deferRender: true,
		select:{
			style:'single',
			blurable: true
		},	
		ajax:{
			url:'<?php echo site_url('c=roles&m=data');?>',
			type:'post',
			data:function(d){
				//d.csrf_test_name = $.cookie(CSRF_COOKIE_NAME);
			}
		},
		columns:[
			{
				data:'id',
				className:'select-checkbox',
				render:function(data, type, row){
					return data;
				}
			},
			{data:'roleName'},
			{data:'plan_name'},
			{
				data:'id',
				sortable:false,
				render:function(data, type, row){
					var html = '';
					html += '<div class="btn-group">';
						  html += '<a href="<?php echo '#/roles?m=edit&id=';?>' + data + '" title="edit" class="btn btn-default btn-xs"><i class="fa fa-edit icon-pencil"></i></a><a href="javascript:;" onclick="del_confirm(\'Notice\', \'Are you sure delete\', \'<?php echo site_url('c=roles&m=delete&id=');?>' + data + '\',\'roles-datatable\');" title=" delete" class="btn btn-default btn-xs"><i class="fa fa-trash icon-trash"></i></a>';
					html += '</div>';
					return html;
				}
			}
		]
	});
});
</script>    