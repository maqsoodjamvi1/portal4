<link rel="stylesheet" href="<?php echo base_url();?>resource/bootstrap-switch/css/bootstrap3/bootstrap-switch.min.css" />
<style>
tr td:last-child{font-family:'nafees-nastaleeq'; font-size: 15px;}
tr td:first-child{font-weight:bold;}
tr td{vertical-align: middle !important;}
p{margin-bottom: 0px !important;}
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th{
	padding: 4px 8px !important;
}
</style>
<?php 
if(isset($_GET['cls_sec_id'])){
  $cls_sec_id = $_GET['cls_sec_id'];
}else{
  $cls_sec_id = '';
}

if(isset($_GET['hide_marks'])){
  $hide_marks = $_GET['hide_marks'];
}else{
  $hide_marks = '';
}

if(isset($_GET['footer_line1'])){
  $footer_line1 = $_GET['footer_line1'];
  }else{
    $footer_line1 = '';
  }

  if(isset($_GET['show_line1'])){
    $show_line1 = $_GET['show_line1'];
  }else{
    $show_line1 = '';
  }

  if(isset($_GET['footer_line2'])){
    $footer_line2 = $_GET['footer_line2'];
  }else{
    $footer_line2 = '';
  }

  if(isset($_GET['show_line2'])){
    $show_line2 = $_GET['show_line2'];
  }else{
    $show_line2 = '';
  }
?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
               Datesheet
            </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Datesheet</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
          <div class="card card-primary card-outline card-tabs">
          <div class="card-header p-0 pt-1 border-bottom-0">
			     <ul class="nav nav-tabs">
					   <li class="nav-item"><a class="nav-link active" href="<?php echo '#/datesheet';?>">Admit Card</a></li>
             <li class="nav-item"><a class="nav-link" href="<?php echo '#/datesheet2';?>">Admit Card 2</a></li>
             <li  class="nav-item"><a  class="nav-link" href="<?php echo '#/datesheet_without_syllabus';?>">Admit Card Without Syllabus</a></li>
             <li  class="nav-item"><a  class="nav-link" href="<?php echo '#/datesheet_classwise';?>">Date Sheet</a></li>
            <li  class="nav-item"><a  class="nav-link" href="<?php echo '#/datesheet?m=add';?>">Add Datesheet</a></li>
            
				  </ul>
				<div class="card-body">
        <div class="col-lg-12">
    <form action="/admin.php#/datesheet" role="form" id="user-edit-form" method="get" accept-charset="utf-8">  
      <div class="row no-print">
          <div class="col-lg-5 form-group">
              <label for="class"><strong>Class</strong></label><br>
                <select class="form-control" name="cls_sec_id" id="cls_sec_id">
                  <option value="">All Classes</option>
                <?php if(isset($sectionsclassinfo)){
                  foreach ($sectionsclassinfo as  $sectionvalue) {
                 ?>
                <option <?php if($cls_sec_id == $sectionvalue['section_id']){ ?> selected <?php } ?>  value="<?php echo $sectionvalue['section_id']; ?>"><?php echo $sectionvalue['sectionclassname']; ?></option>
                <?php } ?>
                <?php } ?>  
                </select>
            </div>
            <div class="col-sm-2"><label>Hide Marks</label><input <?php if($hide_marks == 1){ ?> checked <?php } ?> type="checkbox" name="hide_marks" value="1" class="form-control"></div>

            <div class="col-lg-4 form-group">
                <label>Footer Lines 1:</label>
                  <input type="text" class="form-control pull-right"  value="<?php echo $footer_line1; ?>" name="footer_line1">
                <!-- /.input group -->
            </div>
            
             <div class="col-lg-4 form-group">
                <label>Footer Lines 2:</label>
                  <input type="text" class="form-control pull-right"  value="<?php echo $footer_line2; ?>" name="footer_line2">
                <!-- /.input group -->
            </div>
            <div class="col-lg-2 form-group">
                <label>Show Footer Line 1:</label>
                  <input type="checkbox" class="form-control pull-right" <?php if($show_line1 == 1){ ?> checked <?php } ?>  value="1" name="show_line1">
                <!-- /.input group -->
            </div>
            <div class="col-lg-2 form-group">
                <label>Show Footer Line 2:</label>
                  <input type="checkbox" class="form-control pull-right" <?php if($show_line2 == 1){ ?> checked <?php } ?>  value="1" name="show_line2">
                <!-- /.input group -->
            </div>

            <div class="col-sm-2"><input style="margin-top: 25px;" class="btn btn-primary" name="submit" type="submit" value="view"></div>
      </div>       
     </form>
  <div id="printJS-form">
  <?php
  if($data){
  foreach ($data as  $value) {  
   $termlastkey = $value['terms'];
   $examName = $termlastkey;
   ?>
  <page style="font-family: Arial, Helvetica, sans-serif !important;">
    <div style="width:100%;text-align: right;padding-right: 10px;">Rs. <?php echo $value['remaining_dues']; ?>/-</div>
    <div style="border:1px dashed #000; border-radius:10px; text-align:center;height: 130px;" class="col-lg-12">
    <div  class="col-lg-3" style="float: left;width: 100px;">
  <?php if(!empty($value['profile_photo'])){ ?>
    <img style="width: 70px;margin-top: 16px;border-radius: 8px;height: 70px;" src="uploads/<?php echo $value['profile_photo']; ?>">
  <?php }else{ ?>
  <i style="font-size: 90px;text-align: center;display: block;margin-top: 16px;" class="fa fa-user"></i>
 <?php } ?>
	<!-- <img style="width: 70px;height:70px;margin-top: 10px; float: left;" src="uploads/logo_school.png"> --></div>
<div  class="col-lg-9" style="width: 815px;margin: 0 auto;">
<h1 style="margin-top:5px; font-size:40px; "><?php echo $value['campus_name']; ?></h1>
<h3 style="margin-top:5px;font-size: 22px;"><?php echo $value['campus_location']."<br>".$examName; ?> </h3>
 </div>
</div>
<div style="border:1px solid #000; float:left; width:100%;margin:10px auto;">
<div style="width:50%; padding-left:15px; border-bottom:1px solid #000; float:left;"> <strong>Name:</strong> <?php echo $value['name']; ?></div>
<div style="width:50%; padding-left:15px; border-bottom:1px solid #000; float:left;"><strong> Reg #:</strong> <?php echo $value['reg_no']; ?></div>
<div style="width:50%; padding-left:15px; border-bottom:1px solid #000; float:left;"> <strong>Father Name:</strong> <?php echo $value['f_name']; ?></div>
<div style="width:50%; padding-left:15px; border-bottom:1px solid #000; float:left;"> <strong>Grade:</strong> <?php echo $value['class']; ?></div>
<div style="width:50%; padding-left:15px;  float:left;"> <strong>Contact # 1:</strong> <?php echo $value['father_contact']; ?></div>
<div style="width:50%; padding-left:15px;  float:left;"> <strong>Contact # 2:</strong>  <?php echo $value['mother_contact']; ?></div>
</div>
<div style="border:2px solid #000; float:left; width:100%; margin:10px auto; padding:2px;">
<div style="border:2px solid #000;float:left;width:100%;text-align:center;font-weight:bold;padding: 5px;font-size: 18px;color: #000;line-height: 20px;">DATE SHEET</div>
<table class="table" style="margin-bottom: 2px;">
<thead>
<tr>
<th style="width: 10%; border-bottom:1px solid #000;">Date</th>
<th style="width: 10%;border-bottom:1px solid #000;">Day</th>
<th style="width: 12%;border-bottom:1px solid #000;">Subjects</th>
<?php if($hide_marks == ''){ ?>
 <th style="width: 10%;border-bottom:1px solid #000;">Total Marks</th>
<?php } ?>
<th style="text-align:center;border-bottom:1px solid #000;">Exam Syllabus</th>
</tr>
</thead>
<tbody>
<?php foreach ($value['datesheetbysubject'] as $key => $valueNo){ ?>
<tr>
<?php foreach($valueNo as $numbers){ ?>
<td style="border-bottom:1px solid #000;"><?php echo $numbers; ?></td>
<?php } ?>
</tr>
<?php } ?>
</tbody>
</table> 
</div></page>
 <?php if($show_line1 == 1){ ?>
  <div style="float:left;width:98%; border-bottom:1px solid;margin-top:10px;font-size: 20px !important;color: #000;"><?php echo $footer_line1; ?>&nbsp;&nbsp;</div>
  <?php } ?>
  <?php if($show_line2 == 1){ ?>
  <div style="float:left;width:98%; border-bottom:1px solid;margin-top:20px;margin-bottom: 20px;font-size: 20px !important;color: #000;"><?php echo $footer_line2; ?>&nbsp;&nbsp;</div>
  <?php } ?>
<br><br><br><br>
<div style="clear: both;margin-bottom: 60px;"></div>
<p style="page-break-before: always;">&nbsp;</p>
<?php } ?>
<?php } ?>
</div>
 </div>
<!-- /.box-body -->
</div>
<!-- /.box -->
</div>
</div>
</div>
</div>
</section>
<!-- /.content -->
<script src="<?php echo base_url();?>resource/bootstrap-switch/js/bootstrap-switch.min.js"></script>