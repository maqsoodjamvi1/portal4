<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>
<?php
	if(isset($info)){
		$header = 'Edit Class Section';
		$id = $info->sec_id;
		$class_id = $info->class_id;
		$subject_id = intval($info->subject_id);			
	}else{
		$header = 'Add Class Section';
		$id = 0;
		$class_id = '';
		$subject_id = '';
	}
?>
<!-- Content Header (Page header) -->
	<section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
               Class Section
           		<?php if (empty($classSections_info->cls_sec_id)) : ?>
							    <span style='background: green;color: #fff !important;float: right;padding: 5px 10px;margin-top: 0px;
							    font-size: 16px;'>Step 6 Of 10 To Complete System Configuration</span>
							    <audio autoplay controls>
							        <source src="<?= base_url('audio/Step8ClassSection.m4a') ?>" type="audio/ogg">
							    </audio>
							<?php endif; ?>
						 
            </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Class Section</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
         <div class="card-header p-0 pt-1 border-bottom-0">
         <div class="card-body">		
        <div class="tab-content">
      <?php
			//echo form_open('c=class_section&m=save', 'role="form" id="class-subjects-edit-form"');
			//echo form_hidden('id', $id);
			?>
			<div id="subjectsection"></div>
				<?php	if(empty($classSections_info->cls_sec_id)){ ?>
						<a class="btn btn-primary" href="<?php echo base_url(); ?>admin/subjects/add">Click here for next Step</a>
				<?php }   ?> 
        </div>
      </div>
    </div>
  </div>
  </div>
  </div>
</section> 
<!-- /.content -->
<script type="text/javascript">
$(function(){
          

	 $.ajax({
            url: '<?php echo base_url('admin/class_section/data2'); ?>', 
            type: "POST",
            data:{},
            success:function(res){
            	console.log(res);
 			   $("#subjectsection").html(res);
			  }
   });

	
	

});
</script>
<?= $this->endSection() ?>