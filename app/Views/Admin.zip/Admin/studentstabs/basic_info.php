  <?php echo form_open_multipart('', 'role="form" id="students-edit-form-basicinfo"');
        echo form_hidden('id', $id);
        echo form_hidden('campus_id', $campus_id);
  ?>
      <input type="hidden" name="parent_id" id="parent_id" value="<?php echo $parent_id; ?>"  /> 
      <div class="row">     	
        <div class="col-lg-3">
          <div class="form-group">
            <label for="reg_no">Registration No</label>
            <input type="text" readonly class="form-control" name="reg_no" id="reg_no" value="<?php echo $reg_no;?>">
            <input type="hidden" id="originalreg_no" value="<?php echo $reg_no;?>">
          </div>
        </div>
        <div class="col-lg-3">
        <div class="form-group">
              <label for="first_name">First Name <span class="text-danger">*</span></label>
              <input type="text" class="form-control" required name="first_name" id="first_name" value="<?php echo $first_name;?>">
            </div> 
        </div>
        <div class="col-lg-3">
            <div class="form-group">
              <label for="last_name">Last Name</label>
              <input type="text" class="form-control" name="last_name" id="last_name" value="<?php echo $last_name;?>">
            </div>
        </div>
        <div class="col-lg-3">
         <div class="form-group">
              <label for="student_cnic">Student CNIC <span class="text-danger">*</span></label>
              <input type="text" class="form-control" name="student_cnic" id="student_cnic" value="<?php echo $student_cnic;?>" data-inputmask='"mask": "99999-9999999-9"' data-mask>
          </div>
        </div>
	    <div class="col-lg-3">
            <div class="form-group" style="margin-bottom:23px;">
              <label for="gender">Gender <span class="text-danger">*</span></label>
              <br>
              <label>Male</label>
              <input type="radio" name="gender" required checked value="male" <?php if($gender == "male"){ echo "checked"; } ?> >
              <label>Female</label>
              <input type="radio" name="gender" value="female" <?php if($gender == "female"){ echo "checked"; } ?> >
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group">
              <label for="father_cnic">Father CNIC <span class="text-danger">*</span></label>
              <input type="text" class="form-control" required name="father_cnic" id="father_cnic"  onkeyup="checkfathercnic()"  value="<?php echo $father_cnic;?>" data-inputmask='"mask": "99999-9999999-9"' data-mask>
              <small><a href="#" data-toggle="modal" style="font-size: .75rem !important;" class="btn btn-default btn-xs dropdown-item" id="#createParent" data-target="#createParent"  data-id="<?php echo $id; ?>" class="btn btn-default btn-xs">Update Parent Info</a></small>
            </div>
        </div>
        <div class="col-lg-3">
          <div class="form-group">
            <label for="f_first_name">Father Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control" name="f_name" id="f_name" value="<?php echo $f_name;?>">
          </div>
        </div>
        <div class="col-lg-3">
        <div class="form-group">
          <label for="religion">Religion</label>
          <input type="text" class="form-control" name="religion" id="religion" value="<?php if(empty($religion)){ echo 'Islam';  }else{ echo $religion; }?>">
        </div>
        </div>
       <div class="col-lg-3">
        <div class="form-group">
          <label for="caste">Caste</label>
          <input type="text" class="form-control" name="caste" id="caste" value="<?php echo $caste; ?>">
        </div>
       </div>
       <div class="col-lg-3">
        <div class="form-group">
          <label for="gr_no">G.R #</label>
          <input type="text" class="form-control" name="gr_no" id="gr_no" value="<?php  echo $gr_no; ?>">
        </div>
        </div>
        <div class="col-lg-3">
            <?php 
              if(!empty($gr_date) && $gr_date != 0){
                $gr_date = DateTime::createFromFormat('Y-m-d',$gr_date);
                $gr_date = $gr_date->format('d/m/Y');
              }else{  
                $gr_date = date('d/m/Y');         
              } 
            ?>
            <div class="form-group">
              <label>G.R Date <span class="text-danger">*</span></label>
              <div class="input-group date" id="datepicker2" data-target-input="nearest">
                <input type="text" class="form-control datetimepicker-input"  id="datepicker2" name="gr_date" required 
                value="<?php echo $gr_date; ?>" data-target="#datepicker2"/>
                <div class="input-group-append" data-target="#datepicker2" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
              </div>
              <!-- /.input group -->
            </div>
        </div>
        <div class="col-lg-3">
            <?php 
              if(!empty($date_of_admission) && $date_of_admission != 0){
                $date_of_admission = DateTime::createFromFormat('Y-m-d',$date_of_admission);
                $date_of_admission = $date_of_admission->format('d/m/Y');
              }else{  
                $date_of_admission = date('d/m/Y');         
              } 
            ?>
            <div class="form-group">
              <label>Date Of Admission <span class="text-danger">*</span></label>
              <div class="input-group date" id="datepicker2" data-target-input="nearest">
                <input type="text" class="form-control datetimepicker-input"  id="datepicker2" name="date_of_admission" required 
                value="<?php echo $date_of_admission; ?>" data-target="#datepicker2"/>
                <div class="input-group-append" data-target="#datepicker2" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
              </div>
              <!-- /.input group -->
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group">
              <label for="class_id">Section <span class="text-danger">*</span></label>
              <select class="form-control" required name="section_id" id="section_id" >
                <option value="">Select Section</option>
              <?php if(isset($sectionsclassinfo)){
                foreach ($sectionsclassinfo as  $sectionvalue) { ?>
                <option <?php if($sectionvalue['section_id'] == $section_id) { ?> selected <?php } ?> value="<?php echo $sectionvalue['section_id']; ?>"><?php echo $sectionvalue['sectionclassname']; ?></option>
                <?php } ?>
                <?php } ?>
              </select>
            </div>
      </div>
      <div class="col-lg-3">
        <div class="form-group">
          <label for="class_fee">Class Fee <span class="text-danger">*</span></label>
          <input type="text" class="form-control" required name="class_fee" id="class_fee" value="<?php echo $classesfee; ?>">
        </div>
      </div>
      <div class="col-lg-3">
        <div class="form-group">
          <label for="discounted_amount">Student Fee</label>
          <input type="text" class="form-control" name="discounted_amount" id="discounted_amount" value="<?php  if(isset($classesfee)){ echo ($classesfee - $discounted_amount); }?>">
        </div>
      </div>
      <div class="col-lg-3">
        <div class="form-group">
          <label for="transport_fee">Transport Fee</label>
          <input type="text" class="form-control" name="transport_fee" id="transport_fee" value="<?php  if(isset($transportfee)){ echo ($transportfee - $transport_discount); }?>">
        </div>
      </div>
      <div class="col-lg-3">
        <div class="form-group">
          <label for="fee_plan">Student Fee Plan </label>
          <select class="form-control" name="fee_plan">
            <option <?php if(0 == $fee_plan) { ?> selected <?php } ?> value="0">Monthly</option>
            <?php foreach ($fee_plans as $key => $value) { ?>
                <option <?php if($value->plan_id == $fee_plan) { ?> selected <?php } ?> value="<?php echo $value->plan_id; ?>"><?php echo $value->plan_name; ?></option>
            <?php } ?>
              
          </select>
        </div>
      </div>
      </div> 
      <div class="row">
      <div class="col-lg-12 noprint">
        <div class="form-group">
          <button type="submit" id="submitBtn" class="btn btn-primary studentsubmit">Save</button>
          <button type="reset" class="btn btn-default">Reset</button>
          <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
        </div>
      </div>
      </div>
    <?php echo form_close();?>

     <div class="modal fade" id="createParent" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
        <form id="parentInfoUpdate">    
        <div class="modal-header">
          <h5 class="modal-title pull-left" id="exampleModalLabel">Update Parent Info</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="studentID" name="student_id">
          <label>Father CNIC</label>
          <input type="text" name="f_cnic" class="form-control" id="f_cnic" data-inputmask='"mask": "99999-9999999-9"' data-mask>
          <label>Father Name</label>
          <input type="text" name="father_name"  class="form-control" id="father_name">
        </div>
        <div class="modal-footer"> 
        <button type="button" id="createNewParent" class="btn btn-primary">Update Parent</button> 
        </div>
        </form>
        </div>
      </div>
    </div>
 <script>
$(function(){

    $('#createNewParent').click(function(){
            
         $.ajax({
            url: 'admin.php?c=students&m=updateParentInfo',
            type: 'POST',
            data:$('#parentInfoUpdate').serialize(),
            success:function(res){
             toastr.success('Updated Successfully');
            }
         });

        //$('#updatediscount').modal('hide');
    });

    $('#createParent').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget) // Button that triggered the modal
      var discount = button.data('discount') // Extract info from data-* attributes
      var studentID = button.data('id')

    $('#f_cnic').keyup(function(){
    var f_cnic = $('#f_cnic').val();

    $.ajax({
            url: 'admin.php?c=students&m=getParentInfo',
            type: "POST",
            data:{f_cnic: f_cnic},
            success:function(res){
             if(res){
               $("#father_name").val(res);
             }else{
                $("#father_name").val('');
             }
          
         }
         });
    });
      // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
      // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
      var modal = $(this)
      modal.find('#discount').val(discount)
      modal.find('#studentID').val(studentID)
      
    });


  $("#section_id").change(function(){
        var section_id = $('#section_id').val();
         $.ajax({
            url: 'admin.php?c=ajax&m=selectClassFee',
            type: "POST",
            data:{section_id:section_id },
            success:function(res){
              $("#class_fee").val(res);
            }
         });
    });

  $('[data-mask]').inputmask();
 
  $('#datepicker2').datetimepicker({
      format: 'DD/MM/YYYY'
    });

});


</script>   
<script>
    $(document).ready(function () {
        $('#loader').hide();
        $('#students-edit-form-basicinfo').validate({// <- attach '.validate()' to your form
            // Rules for form validation
            rules: {
                first_name: {
                    required: true
                },
                f_name: {
                    required: true
                },
                father_cnic: {
                    required: true
                }
            },
            // Messages for form validation
            messages: {
                first_name: {
                    required: 'Enter First Name'
                },
                cnic: {
                    required: 'father CNIC is Required'
                },
                f_name: {
                    required: 'Enter Father Name'
                }
            },
            submitHandler: function (form) {

                    var myData = new FormData($("#students-edit-form-basicinfo")[0]);

                    swal({
                        title: "Confirm to Update Student",
                        text: "Update Student Information!",
                        type: "warning",
                        showCancelButton: true,
                        closeOnConfirm: false,
                        showLoaderOnConfirm: true,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Yes, Assign!"
                    }, function () {

                        $.ajax({
                            url: 'admin.php?c=students&m=save_basicinfo',
                            type: 'POST',
                            data: myData,
                            dataType: 'json',
                            cache: false,
                            processData: false,
                            contentType: false,
                            beforeSend: function () {
                                $('#loader').show();
                                $("#submit").prop('disabled', true); // disable button
                            },
                            success: function (data) {

                                if (data.type === 'success') {
                                    swal("Done!", "It was succesfully done!", "success");
                                    location.href = '#/students?m=edit&id='+data.student_id;
                                    notify_view(data.type, data.message);
                                    $('#loader').hide(); 
                                    $("#submit").prop('disabled', false); // disable button
                                    $("html, body").animate({scrollTop: 0}, "slow");
                                    $('#myModal').modal('hide'); // hide bootstrap modal

                                } else {
                                    if (data.errors) {
                                        $.each(data.errors, function (key, val) {
                                            $('#error_' + key).html(val);
                                        });
                                    }
                                    $("#status").html(data.message);
                                    $('#loader').hide();
                                    $("#submit").prop('disabled', false); // disable button
                                    swal("Error sending!", "Please try again", "error");

                                }

                            }
                        });
                    });

                
            }
            // <- end 'submitHandler' callback
        });                    

        // <- end '.validate()'

    });
    </script>