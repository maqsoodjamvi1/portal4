<input type="hidden" class="student_id" name="student_id" value="<?php echo $id; ?>">
<?php
$attachment_id = 0;

foreach ($attachementTypesInfo as $key => $value) {
    $this->db->where('student_id', $id);
    $this->db->where('a_type_id', $value->a_type_id);
    $attachementsinfo = $this->db->get('attachements')->row();
    //print_r($attachementsinfo);
    if($attachementsinfo){
        $attachment_id = $attachementsinfo->attachement_id;
    }
?>
<li class="list-group-item active"><h5><?php echo $value->a_type_name; ?></h5></li>
<input type="hidden" name="a_type_id" class="a_type_id<?php echo $value->a_type_id; ?>" value="<?php echo $value->a_type_id; ?>">
<input type="hidden" name="attachement_id" class="attachement_id<?php echo $value->a_type_id; ?>" value="<?php echo $attachment_id; ?>">
<li class="list-group-item">
    <div class="input-group mb-3">
        <div class="custom-file ">
            <input type="file"  class="custom-file-input" name="thumbnail<?php echo $value->a_type_id; ?>" id="thumbnail<?php echo $value->a_type_id; ?>">
            <label class="custom-file-label" for="thumbnail">Choose file</label>
        </div>
    </div>
    <div class="img-thumbnail  text-center">
        <img src="<?php if(isset($attachementsinfo)) { echo 'studentattachements/'.$attachementsinfo->attachement_path; }  ?>" id="imgthumbnail<?php echo $value->a_type_id; ?>" class="img-fluid" alt="">
    </div>
</li>
<script>
$(function(){
$('#thumbnail<?php echo $value->a_type_id; ?>').on('change', function() {
    var file = $(this).get(0).files;
    //var atypeID = <?php echo $value->a_type_id; ?>;
    var formData = new FormData();
	formData.append('file', $(this)[0].files[0]);
    formData.append('a_type_id', $('.a_type_id<?php echo $value->a_type_id; ?>').val());
    formData.append('student_id', $('.student_id').val());
    formData.append('attachement_id', $('.attachement_id<?php echo $value->a_type_id; ?>').val());

    $.ajax({
        url:'<?php echo site_url('c=students&m=save_attachment');?>', 
       	type : 'POST',
       	data : formData,
       	processData: false,  // tell jQuery not to process the data
       	contentType: false,  // tell jQuery not to set contentType
        success:function(res){
        	var json = $.parseJSON(res);
			if(json.success){
				toastr.success(json.msg);
			}else{
				toastr.error('Update Error');
			}
		}
	});
    var reader = new FileReader();
    reader.readAsDataURL(file[0]);
    reader.addEventListener("load", function(e) {
    var image = e.target.result;
$("#imgthumbnail<?php echo $value->a_type_id; ?>").attr('src', image);
});
});
});
</script>
<?php } ?>

<style type="text/css">
	body {
font-family: Arial;
font-size: 14px;
}
.bgColor {
max-width: 440px;
height:150px;
background-color: #fff4be;
border-radius: 4px;
}
.bgColor label{
font-weight: bold;
color: #A0A0A0;
}
#targetLayer{
float:left;
width:150px;
height:150px;
text-align:center;
line-height:150px;
font-weight: bold;
color: #C0C0C0;
background-color: #F0E8E0;
border-bottom-left-radius: 4px;
border-top-left-radius: 4px;
}
#uploadFormLayer{
	float:left;
	padding: 20px;
}
.btnSubmit {
	background-color: #696969;
    padding: 5px 30px;
    border: #696969 1px solid;
    border-radius: 4px;
    color: #FFFFFF;
    margin-top: 10px;
}
.inputFile {
	padding: 5px;
	background-color: #FFFFFF;
	border:#F0E8E0 1px solid;
	border-radius: 4px;
}
.image-preview {	
width:150px;
height:150px;
border-bottom-left-radius: 4px;
border-top-left-radius: 4px;
}

</style>