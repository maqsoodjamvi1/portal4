<?php /** @var array $data */ ?>

<?php foreach ($data as $value): ?>
    <p style="page-break-before: always;">&nbsp;</p>
    <page style="width: 90%;">
        <style type="text/css">
            p { margin-bottom: 0px; font-size: 14px !important; }
            p span { font-size: 14px !important; }
        </style>

        <div style="border:2px solid #000; float:left; width:90%; margin:10px auto; padding:2px;">
            <div style="border:2px solid #000;float:left;width:100%;text-align:center;font-weight:bold;padding: 5px;font-size: 18px;color: #000;line-height: 20px;">
                Weekly Diary (<?= esc($value['session_name']) ?>)
                <div style="width:90%;padding-left:15px;float:left;font-size: 16px;font-weight: normal;margin-top: 0px;">
                    <?= esc($value['class']) ?>
                </div>
            </div>

            <table class="table" style="margin-bottom: 2px;width: 100%;">
                <thead>
                    <tr>
                        <th style="width:5%;border:1px solid #000;">Subject</th>
                        <?php $colWidth = 95 / count($value['week_dates']); ?>
                        <?php foreach ($value['week_dates'] as $weekdates): ?>
                            <?php
                                $dateformate = date('d-m-Y', strtotime($weekdates));
                                $nameOfDay = date('l', strtotime($weekdates));
                            ?>
                            <th style="border:1px solid #000;width:<?= $colWidth ?>%;">
                                <?= esc($dateformate . " ($nameOfDay)") ?>
                            </th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($value['result'] as $key => $valueNo): ?>
                        <tr>
                            <td style="border:1px solid #000;"> <?= esc($key) ?> </td>
                            <?php foreach ($value['week_dates'] as $weekDate): ?>
                                <?php $content = isset($valueNo[$weekDate]) ? $valueNo[$weekDate] : ''; ?>
                                <td style="border:1px solid #000;<?= in_array($key, ['Urdu', 'Nazra']) ? 'direction: rtl;' : '' ?>">
                                    <?= esc($content) ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </page>
    <div style="clear: both;margin-bottom: 60px;"></div>
<?php endforeach; ?>
