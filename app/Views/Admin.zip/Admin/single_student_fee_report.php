<?php
if(isset($info)){

	$header = 'Edit Term Session';
	$id = $info->term_session_id;
	$term_id = $info->term_id;
	$session_id = $info->session_id;
	$start_date = $info->start_date;
	$end_date = $info->end_date;

}else{
	$header = 'Add Term Session';
	$id = '';
	$term_id = '';
	$session_id = '';
	$start_date = '';
	$end_date = '';

}
?>
<style type="text/css">
	.table td, .table th{
		padding: 2px 0px;
    text-align: center;
    vertical-align: middle;
    font-size: 12px;
    border-top: 1px solid #dee2e6;
	}
	tr{border-bottom:2px solid #000;}
</style>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-8">
            <h1>
               Student Fee Report
            </h1>
          </div>
          <div class="col-sm-4">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Student Fee Report</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->	
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
		  <div class="card card-primary card-outline card-tabs">
          	<div class="card-header p-0 pt-1 border-bottom-0">
          	<div class="card-body">	
			<div class="tab-content">
			<?php
			//echo form_open('c=terms_session&m=save', 'role="form" id="user-edit-form"');
			//echo form_hidden('id', $id);
			?>
			<!-- <div class="form-group">
				<select class="form-control" name="session_id" id="session_id">
				<option value="">Select Session</option>
				<?php if(isset($academic_session)){
					foreach($academic_session as $session){ 
				 ?>
				<option value="<?php echo $session->session_id; ?>"><?php echo $session->session_name; ?></option>
				<?php } ?>
				<?php } ?>	
				</select>
			</div> -->
			<div class="row">
			<!-- <div class="col-lg-5">
			<div class="form-group">
				<select class="form-control" name="cls_sec_id" id="cls_sec_id">
					<option value="">All Classes</option>
				<?php if(isset($sectionsclassinfo)){
					foreach ($sectionsclassinfo as  $sectionvalue) {
				 ?>
				<option value="<?php echo $sectionvalue['section_id']; ?>"><?php echo $sectionvalue['sectionclassname']; ?></option>
				<?php } ?>
				<?php } ?>	
				</select>
			</div>
		</div> -->
		<div class="col-lg-5">
		<div class="form-group">
				<select class="form-control select2" name="student_id" id="student_id" style="height: 24px;width: 100%;">
		       <option value="0">Select Student</option>   
		    </select>
			</div>
		</div>
		<div class="col-lg-2"><input type="button" class="btn btn-primary btn-xs" value="View Report" id="viewReport"></div>
	</div>
			<div class="col-md-12 bg">
		        <div id="loader-1" class="overlay" style="display: none;"><i class="fas fa-2x fa-sync-alt fa-spin"></i></div>
		      </div> 
		    <div id="termssessionarea" class="termssessionarea">
			</div>	
			  <!-- <div class="form-group">
                <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
				<button type="reset" class="btn btn-default">Reset</button>
				<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
              </div> -->
            <?php //echo form_close();?>
			</div>
		  </div>
        </div>
      </div>
  	</div>
  </section>
    <!-- /.content -->
<script type="text/javascript">

$("#viewReport").click(function(){
     
   var student_id = $('#student_id').val();

   $("#loader-1").css("display", "block");
   $.ajax({
        url:'<?php echo site_url('c=student_fee_report&m=singleStudentFeedata');?>', 
        type: "POST",
        data:{student_id:student_id},
        success:function(res){
        	//console.log(res);
		  		 	$("#termssessionarea").html(res);
		   			$("#loader-1").css("display", "none");
	 			}
     });
	 
  });    

$(function(){
 $('.datepicker').datetimepicker({
      format: 'DD/MM/YYYY'
    })

	$('#user-edit-form').validate({
		
	});

	$("#student_id").select2({
    minimumInputLength: 2,
    tags: [],
    ajax: {
        url: 'admin.php?c=student_results&m=get_studentinfo', 
        dataType: 'json',
        type: "POST",
        quietMillis: 50,
        data: function (term) {
            return {
                term: term,
            }
        },
       processResults: function (response) {
        console.log(response);
              return {
                 results: response
              };
           },
           cache: true
    }
 });
	
	// $('#user-edit-form').ajaxForm({
	// 	beforeSubmit:function(formData, jqForm, options){
	// 		//return $('#user-edit-form').valid();
	// 		$('#submitBtn').html("Ajax Request is Processing!");
	// 		$('#submitBtn').prop('disabled', true);
	// 	},
	// 	success:function(responseText, statusText, xhr, form){
	// 		var json = $.parseJSON(responseText);
	// 		$('#submitBtn').html("Submit");
	// 		$('#submitBtn').prop('disabled', false);
	// 		if(json.term_weeks_id == false){
	//         	window.location.href = '<?php echo base_url() . $this->config->item('index_page');?>#/term_weeks?m=add';
	//         	return;
	//       	}
	// 		if(json.success){
	// 			toastr.success(json.msg);
	// 			<?php
	// 			if($id == ''){
	// 				?>
	// 				location.href = '#/terms_session';
	// 				<?php
	// 			}else{
	// 				?>
	// 				location.href = '#/terms_session?m=edit&id=<?php echo $id;?>&after=edit';
	// 				<?php
	// 			}
	// 			?>
	// 		}else{
	// 			toastr.error(json.msg);
	// 		}
	// 		return false;
	// 	}
	// });
})
</script>