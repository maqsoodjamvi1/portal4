<?= $this->extend('layouts/admin_template') ?>

<?= $this->section('content') ?>

<!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
               Profile
            </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin/');?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-3">
          <!-- Profile Image -->
          <div class="card card-primary card-outline">
            <div class="card-body box-profile">
            <div class="text-center">
              <?php if($user->photo){ ?>
                <img id="output" class="profile-user-img img-fluid img-circle" src="<?php echo base_url();?>employees-img/<?php echo $user->photo; ?>" alt="User profile picture">
              <?php }else{ ?>
              <img id="output" class="profile-user-img img-fluid img-circle" src="<?php echo base_url();?>resource/adminlte/dist/img/user4-128x128.jpg" alt="User profile picture">
              <?php } ?>
            </div>  
              <!-- <img id="output"  style="width:100px;" /> -->
             <h3 class="profile-username text-center"><?php echo $user->username;?></h3>
              <p class="text-muted text-center"></p>
              <ul class="list-group list-group-unbordered">
        <li class="list-group-item">
          <b>Join time</b> <a class="pull-right"><?php echo $user->reg_time;?></a>
        </li>       
        <li class="list-group-item">
          <b>Login times</b> <a class="pull-right"><?php echo $user->login_times;?></a>
        </li>
        <li class="list-group-item">
          <b>Cur Login time</b> <a class="pull-right"><?php echo $user->cur_login_time;?></a>
        </li>
        <li class="list-group-item">
          <b>Cur login ip</b> <a class="pull-right"><?php echo $user->cur_login_ip;?></a>
        </li> 
        <li class="list-group-item">
          <b>cur login area</b> <a class="pull-right"><?php echo $user->cur_login_area;?></a>
        </li> 
        <li class="list-group-item">
          <b>last login time</b> <a class="pull-right"><?php echo $user->last_login_time;?></a>
        </li>
        <li class="list-group-item">
          <b>last login ip</b> <a class="pull-right"><?php echo $user->last_login_ip;?></a>
        </li> 
        <li class="list-group-item">
          <b>last login area</b> <a class="pull-right"><?php echo $user->last_login_area;?></a>
        </li>       
              </ul>
              <a href="<?php echo base_url('/logout');?>" class="btn btn-danger btn-block"><b>Logout</b></a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="card">
            <div class="card-header p-2">
              <ul class="nav nav-pills">
              <li class="nav-item"><a class="nav-link active" href="<?php echo base_url(); ?>admin/settings" data-toggle="tab">Settings</a></li>
              <?php if($_SERVER['HTTP_HOST'] != 'demo.timesoftsol.com'){ ?>
        <li class="nav-item"><a class="nav-link" href="<?php echo base_url(); ?>admin/password1" data-toggle="tab">Change Password</a></li>
              <?php } ?>
            </ul>
          </div>
          <div class="card-body">
            <div class="tab-content">
              <div class="active tab-pane" id="settings">
               <?php 
        echo form_open_multipart(  base_url('admin/profile/save') , 'role="form" id="user-edit-form"');
        echo form_hidden('id', $user->id);
        ?>   
        <div class="row"> 
        <div class="col-md-12 bg">
            <div class="loader" id="loader-1" style="display: none;">
              <span></span>
              <span></span>
              <span></span>
              <span></span>
            </div>
        </div> 
             <div class="col-lg-4">
                  <div class="form-group">
                    <label for="inputName" class="control-label">Username</label>
                    <input type="text" class="form-control" readonly="" value="<?php echo $user->username;?>">
                   </div>
         <div class="form-group">
                  <label for="first_name">First Name</label>
                  <input type="text" class="form-control" name="first_name" id="first_name" value="<?php echo $user->first_name;?>">
        </div>
        <div class="form-group">
          <label for="last_name">Last Name</label>
          <input type="text" class="form-control" name="last_name" id="last_name" value="<?php echo $user->last_name;?>">
        </div>
        
                <div class="form-group">
                  <label for="tpl_directory">Email</label>
                  <input type="email" class="form-control" name="email" id="email" value="<?php echo $user->email;?>">
         </div>

                <div class="form-group">
                  <label for="dob">CNIC</label>
                  <input type="text" class="form-control" name="cnic" required="" id="cnic" value="<?php echo $user->cnic;?>"  pattern="^[0-9+]{5}-[0-9+]{7}-[0-9]{1}$" data-inputmask='"mask": "99999-9999999-9"' data-mask>
        </div>
              
        <div class="form-group">
                  <label for="f_first_name">Father Name</label>
                  <input type="text" class="form-control" name="f_name" id="f_first_name" value="<?php echo $user->f_name; ?>">
        </div>
        
            </div>
            <div class="col-lg-4">  
        <div class="form-group"> 
                  <label for="dob">Date Of Birth</label>
                  <input type="date" class="form-control" name="dob" required="" id="dob" value="<?php echo $user->dob;?>">
        </div>
        <div class="form-group">
          <label for="joining_date">Joining Date</label>
          <input type="date" class="form-control" name="joining_date"  id="joining_date" value="<?php echo date($user->joining_date); ?>">
        </div>
        <div class="form-group">
          <label for="mobile_no">Mobile No</label>
          <input type="text" class="form-control" name="mobile_no" id="mobile_no" required="" pattern="^((\+92)|(0092))-{0,1}\d{3}-{0,1}\d{7}$|^\d{11}$|^\d{4}-\d{7}$" value="<?php echo $user->mobile_no;?>"  data-inputmask="'mask': '0399-99999999'" required=""  type = "number" maxlength = "12"  data-mask>
        </div>
        <div class="form-group" style="margin-bottom:23px;">
          <label for="marital_statusmarital_status">Marital Status</label><br>
          <label> <input type="radio" name="marital_status" value="married"  <?php if($user->marital_status == 'married') {?> checked="checked" <?php } ?> > Married</label>
          <label> <input type="radio" name="marital_status" value="single" <?php if($user->marital_status == 'single') {?> checked="checked" <?php } ?>> Single</label>
        </div>
        <div class="form-group">
          <label for="land_line">Mobile 2</label>
          <input type="text" class="form-control" name="mobile_no2" id="mobile_no2" value="<?php echo $user->mobile_no2; ?>" data-inputmask="'mask': '0399-99999999'" required=""  type = "number" maxlength = "12"  data-mask>
        </div>
        <div class="form-group">
          <label for="address_1">Addrees </label>
          <input type="text" class="form-control" name="address" id="address" value="<?php echo $user->address; ?>">
        </div>
    </div>
    <div class="col-lg-4">
    
    <div class="form-group">
      <label for="emergency_contact_person">Emergency Contact Person</label>
      <input type="text" class="form-control" name="emergency_contact_person" id="emergency_contact_person" value="<?php echo $user->emergency_contact_person;?>">
    </div>
    <div class="form-group">
      <label for="emergency_contact_no">Emergency Contact No</label>
      <input type="text" class="form-control" name="emergency_contact_no" id="emergency_contact_no" value="<?php echo $user->emergency_contact_no;?>" data-inputmask="'mask': '0399-99999999'" required=""  type = "number" maxlength = "12"  data-mask>
    </div>
    
    <div class="form-group">
      <label for="qualification">Qualification</label>
      <input type="text" class="form-control" name="qualification" id="qualification" value="<?php echo $user->qualification;?>">
    </div>
    <div class="form-group">
      <label for="experience">Experience</label>
      <input type="text" class="form-control" name="experience" id="experience" value="<?php echo $user->experience;?>">
    </div>
    <div class="form-group">
      <label for="kills">Skills</label>
      <input type="text" class="form-control" name="skills" id="skills" value="<?php echo $user->skills;?>">
    </div>
    <div class="form-group">
      <label for="" class="control-label">Photo</label><br>
      <input type="file"  accept="image/*" name="image" id="file"  onchange="loadFile(event)" style="display: none;">
      <label for="file" class="btn btn-default" style="cursor: pointer;"><i class="fa fa-image"></i> Upload Image</label>
    </div>
  </div>
    <div class="col-xs-12">
      <div class="form-group">
            <button type="submit" id="saveProfile" class="btn btn-primary">Save</button>
      <button type="reset" class="btn btn-default">Reset</button>
      <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
      </div>
      </div>
     </div>     
    </form>
  </div>
  <!-- /.tab-pane -->
  <div class="tab-pane" id="password1">
  <?php echo form_open( base_url('admin/profile/update_password') , 'class="form-horizontal" id="password-edit-form"');
    echo form_hidden('user_id', $user->id);
  ?>
      <div class="form-group">
        <label for="password" class="col-sm-2 control-label">New Password</label>
        <div class="col-sm-10">
          <input type="password" class="form-control" name="password" id="password" >
        </div>
      </div>
      <div class="form-group">
        <label for="password" class="col-sm-2 control-label">Confirm Password</label>
        <div class="col-sm-10">
          <input type="password" class="form-control" name="confirm_password" id="confirm_password" >
        </div>
      </div>
      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
        <button type="submit"  class="btn btn-primary">Save</button>
      <button type="reset" class="btn btn-default">Reset</button>
      <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
        </div>
      </div>        
  <?php echo form_close(); ?>
  <script>
    var loadFile = function(event) {
      var image = document.getElementById('output');
      image.src = URL.createObjectURL(event.target.files[0]);
    };
  </script>
<script type="text/javascript">
  $(function(){
   $("#saveProfile").click(function(){
        $("#loader-1").css("display", "block");
    }); 
    
  $(".select2").select2({closeOnSelect:false});
  $('[data-mask]').inputmask();
  $('#user-edit-form').validate({
    rules:{
      email:{
        required:true,
        email:true,
      } 
      
    },
    messages:{
      email:{
        required:'Email is Required',
        email:'Invalid Email',
      }
    }
  }); 
  $('#user-edit-form').ajaxForm({
    beforeSubmit:function(formData, jqForm, options){
      return $('#user-edit-form').valid();
    },
    success:function(responseText, statusText, xhr, form){
      var json = $.parseJSON(JSON.stringify(responseText));
      if(json.success){
        $("#loader-1").css("display", "none");
        toastr.success(json.msg);
        location.href = '<?php echo base_url('admin/profile'); ?>';
              
      }else{
        toastr.error(json.msg);
      }
      return false;
    }
  });       
  $('#password-edit-form').validate({
    rules:{
      password:{
        required:true,
        minlength:6
      },
      confirm_password:{
        required:true,
        equalTo:'#password'
      }
    },
    messages:{
      password:{
        required:'New Password is Required',
        minlength:'At least 6 chars'
      },
      confirm_password:{
        required:'Confirm New Password',
        equalTo:'Two Password do not match'
      }
    }
  }); 
  $('#password-edit-form').ajaxForm({
    beforeSubmit:function(formData, jqForm, options){
      return $('#password-edit-form').valid();
    },
    success:function(responseText, statusText, xhr, form){
      var json = $.parseJSON(responseText);
      if(json.success){
        toastr.success(json.msg);
      }else{
        toastr.error(json.msg);
      }
      return false;
    }
  });     
});
</script> 
  </div>  
   </div>
</div>
    <!-- /.tab-content -->
  </div>
  <!-- /.nav-tabs-custom -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->
</section>
<?= $this->endSection() ?>