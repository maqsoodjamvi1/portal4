<?php
$header = isset($info) ? 'Edit Scheme of Studies' : 'Add Scheme of Studies';
$id = $info->id ?? '';
?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Scheme of Studies</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#/">Dashboard</a></li>
          <li class="breadcrumb-item active">Scheme of Studies</li>
        </ol>
      </div>
    </div>
  </div>
</section>

<section class="content">
  <div class="card card-primary card-outline card-tabs">
    <div class="card-header p-0 pt-1 border-bottom-0">
      <ul class="nav nav-tabs">
        <li class="nav-item"><a class="nav-link" href="#/top_level_planning">Scheme of Studies</a></li>
        <li class="nav-item"><a class="nav-link active" href="#/top_level_planning?m=<?= $id ? 'edit&id=' . $id : 'add' ?>"><?= $header ?></a></li>
        <li class="nav-item"><a class="nav-link" href="#/top_level_planning_sections?m=add">Add Classwise</a></li>
        <li class="nav-item"><a class="nav-link" href="#/top_level_planning_subject?m=add">Add Subjectwise</a></li>
        <li class="nav-item"><a class="nav-link" href="#/top_level_planning_gradewise">Grade Wise Views</a></li>
      </ul>
    </div>

    <div class="card-body">
      <?= form_open('c=top_level_planning&m=save', ['id' => 'user-edit-form']) ?>

      <div class="row">
        <div class="col-lg-4 form-group">
          <label for="session_id">Session</label>
          <select name="session_id" id="session_id" class="form-control">
            <?php foreach ($academic_session as $session): ?>
              <option value="<?= $session->session_id ?>"><?= $session->session_name ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-lg-3 form-group">
          <label for="section_id">Sections</label>
          <select class="form-control select2" name="section_id" id="section_id">
            <option value="0">Select Section</option>
            <?php foreach ($sectionsclassinfo ?? [] as $sec): ?>
              <option value="<?= $sec['section_id'] ?>"><?= $sec['sectionclassname'] ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-lg-3 form-group">
          <label for="subject_id">Subjects</label>
          <select name="subject_id" id="subject_id" class="form-control"></select>
        </div>

        <div class="col-lg-2 form-group">
          <label>Sync to all campuses</label><br>
          <input type="checkbox" name="synch" value="1">
        </div>

        <div class="col-md-12" id="loader-1" style="display: none;">
          <div class="text-center"><i class="fas fa-sync-alt fa-spin fa-2x"></i></div>
        </div>

        <div class="col-lg-12" id="subjects_list"></div>
      </div>

      <div class="form-group">
        <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
        <button type="reset" class="btn btn-default">Reset</button>
        <button type="button" class="btn btn-default" onclick="history.back();">Cancel</button>
      </div>

      <?= form_close() ?>
    </div>
  </div>
</section>

<!-- <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script> -->
<script>
$(document).ready(function () {
  // function loadSummernote() {
  //   $('.editor').summernote({height: 150});
  // }

  $('#section_id').change(function () {
    $('#subject_id').html('');
    $('#subjects_list').html('');
    $.post('admin.php?c=ajax&m=selectsubjectbySection', {
      section_id: $(this).val()
    }, function (res) {
      $('#subject_id').html(res);
    });
  });

  $('#subject_id').change(function () {
    $('#loader-1').show();
    $.post('admin.php?c=top_level_planning&m=selectSubjectsforTopLevelPlanning', {
      section_id: $('#section_id').val(),
      subject_id: $(this).val(),
      session_id: $('#session_id').val()
    }, function (res) {
      $('#subjects_list').html(res);
      $('#loader-1').hide();
      //loadSummernote();
    });
  });

  $('#user-edit-form').ajaxForm({
    beforeSubmit: function () {
      $('.editor').each(function () {
        $(this).val($(this).summernote('code'));
      });
      $('#submitBtn').html("Saving...").prop('disabled', true);
    },
    success: function (response) {
      $('#submitBtn').html("Save").prop('disabled', false);
      let json = JSON.parse(response);
      if (json.success) {
        toastr.success(json.msg);
        $('#subjects_list').html(json.msg);
      } else {
        toastr.error(json.msg);
      }
    }
  });
});
</script>
