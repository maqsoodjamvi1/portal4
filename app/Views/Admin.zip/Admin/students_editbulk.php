<?php
  $status = ''; 
  if(!empty($_GET['status'])){
   $status = $_GET['status']; 
  }
	if(isset($info)){
		$header = 'Edit Student Bulk';
		$id =  $info->student_id;
		$parent_id = $parentsinfo->parent_id;
		$reg_no =  $info->reg_no;
		$first_name =  $info->first_name;
		$last_name =  $info->last_name;
		$date_of_birth =  $info->date_of_birth;
		$gender =  $info->gender;
		$religion =  $parentsinfo->religion;
		$father_cnic =  $parentsinfo->father_cnicnew;
		$f_name =  $parentsinfo->f_name;
		$father_contact =  $parentsinfo->father_contact;
		$father_email =  $parentsinfo->father_email;
		$father_occupation =  $parentsinfo->father_occupation;
		$father_office_address =  $parentsinfo->father_office_address;
		$m_name  =  $parentsinfo->m_name;
		$mother_contact =  $parentsinfo->mother_contact;
    $whatsapp_contact =  $parentsinfo->whatsapp;
    $address_line1 =  $parentsinfo->address_line1;
		$previous_school =  $info->previous_school;
		$ps_city =  $info->ps_city;
    $city =  $parentsinfo->city;
		$hear_source =  $parentsinfo->hear_source;
		$date_of_admission =  $info->date_of_admission;
		$discounted_amount =  $info->discounted_amount;
		$emergency_contact_person =  $parentsinfo->emergency_contact_person;
		$emergency_contact =  $parentsinfo->emergency_contact;
    $emergency_address = $parentsinfo->a_address;
		$health_conditions =  $info->health_conditions;
		$major_injuries =  $info->major_injuries;
		$profile_photo =  $info->profile_photo;
		if($studentclassinfo){
			$section_id =  $studentclassinfo->cls_sec_id;
		}else{
			$section_id =  $info->class_id;
		}
        $session_id =  $info->session_id;
      	$status = intval($info->status);
		    $campus_id = $sessionData['campusid'];
				
		}else{
		$header = 'Add Student Bulk';
		$id = '';
		$parent_id = '';
		$reg_no = $reg_no;
		$first_name = '';
		$last_name = '';
		$date_of_birth = '';
		$gender = '';
		$religion = '';
		$father_cnic = '';
		$f_name = '';
		$father_contact = '';
		$father_email = '';
		$father_occupation = '';
		$father_office_address = '';
		$father_office_contact = '';
		$m_name = '';
		$classesfee = '';
		$m_last_name = '';
		$mother_contact = '';
    $whatsapp_contact = '';
  	$address_line1 = '';
		$city = '';
		$previous_school = '';
		$ps_city = '';
		$hear_source = '';
		$date_of_admission = '';
		$class_id = 0;
		$section_id = 0;
		$session_id = 0;
		$discounted_amount = '';
		$emergency_contact_person = '';
		$emergency_contact = '';
		$emergency_address = '';
		$health_conditions = '';
		$major_injuries = '';
		$profile_photo =  '';
		$status = 0;
		$campus_id = $sessionData['campusid'];
	}
?>
<script>
function checkfathercnic() {
 	var father_cnic = $('#father_cnic').val();
 	      $.ajax({
            url: 'admin.php?c=ajax&m=check_father_cinic',
            type: "POST",
            data:{father_cnic: father_cnic, },
            success:function(res){
			if(res){

			var sjson = $.parseJSON(res);
			//console.log(sjson.parent_id);
			
			   $("#parent_id").val(sjson.parent_id);
			   $("#religion").val(sjson.religion);
			   $("#f_name").val(sjson.f_name);
			   $("#father_contact").val(sjson.father_contact);
			   $("#father_email").val(sjson.father_email);
			   $("#father_occupation").val(sjson.father_occupation);
			   $("#father_office_address").val(sjson.father_office_address);	
			   $("#address_line1").val(sjson.address_line1);
			   $("#city").val(sjson.city);
			   $("#m_name").val(sjson.m_name);
			   $("#mother_contact").val(sjson.mother_contact);
         $("#whatsapp_contact").val(sjson.whatsapp);
			   $("#hear_source").val(sjson.hear_source);
			   $("#emergency_contact_person").val(sjson.emergency_contact_person);
			   $("#emergency_contact").val(sjson.emergency_contact);
			   $("#a_address").val(sjson.a_address);
			}
			}
  });

 }
</script>
<style type="text/css">	
	@media print{
   .noprint{
       display:none;
   }
}
.nav-pills-custom .nav-link.active{
	color: #fff !important;
}
</style>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
           Entries through Excel
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Entries through Excel</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content"> 
  <div class="row">
    <div class="col-lg-12">
     <div class="card card-primary card-outline card-tabs">
        <div class="card-header p-0 pt-1 border-bottom-0">
        <ul class="nav nav-tabs">   
         <li class="nav-item"><a class="nav-link" href="<?php echo '#/addbulkstudents?m=add';?>"> Student Names</a></li> 
        <li class="nav-item"><a class="nav-link" href="<?php echo '#/students_enroll';?>"> Enroll Students</a>
        <li class="nav-item"><a href="<?php echo '#/students_bulk_cnic';?>" class="nav-link">Father Names</a></li>        
        <li class="nav-item"><a class="nav-link" href="<?php echo '#/studentsbulk';?>">Fee Detail</a></li>
        <?php if($campus_info->a_flag == 1){ ?>
        <li class="nav-item"><a class="nav-link"  href="#/students_bulk_academy_fee">Academy Fee Detail</a></li>
        <?php } ?>
        <?php if($campus_info->h_flag == 1){ ?>
        <li class="nav-item"><a class="nav-link"  href="#/h_student_beds?m=add">Student Bed</a></li>
        <?php } ?>
        <?php if($campus_info->t_flag == 1){ ?>
        <li class="nav-item"><a class="nav-link"  href="#/students_vehicle">Students Vehicle</a></li>
        <?php } ?>
        <li class="nav-item"><a class="nav-link" href="<?php echo '#/students_bulk_contacts';?>"> Contact Numbers</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo '#/students_bulk_info';?>"> Other Student Info</a>
        </li>
        <li class="nav-item"><a class="nav-link active"  href="#/students?m=addbulk">Entries through Excel</a></li>
        </ul>    
        
        <div class="card-body">  
            <a class="btn btn-primary" style="margin-left: 11px;float: left;margin-right: 15px;margin-top: 9px;" href="/uploads/addStudentSample_latest.csv">Download Sample CSV for Bulk Records</a>
         <audio autoplay  controls>
         <source src="audio/AddStudentBulk.m4a" type="audio/ogg">
          <source src="audio/AddStudentBulk.m4a" type="audio/mpeg">
        Your browser does not support the audio element.
        </audio>  
        <div class="tab-content p-3"  style="background: linear-gradient(to left, #dce35b, #45b649);">
      	<?php
      		 if(!empty($max_limit)){
      		echo $max_limit;
      		exit;

      	} ?>	
       
		<!-- <input type="hidden" name="parent_id" id="parent_id" value="<?php echo $parent_id; ?>"  /> -->
	<div class="row">
      <div class="col-12 col-sm-9">
      <div class="tab-content" id="v-pills-tabContent">  
      <?php echo form_open_multipart('c=students&m=import', 'role="form" id="students-edit-form-basicinfo"');
        echo form_hidden('id', $id);
        echo form_hidden('campus_id', $campus_id);
    	?>
   <input type="file" name="file">
	 <br>
	 <br>
   <div class="row">
      <div class="col-lg-12 noprint">
        <div class="form-group">
          <button type="submit" id="submitBtn" class="btn btn-primary studentsubmit">Save</button>
          <button type="reset" class="btn btn-default">Reset</button>
          <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
        </div>
      </div>
      </div>
   <?php echo form_close();?>
      </div>
      
    </div>
    </div>
  </div>
  </div>
  </div>
  <!-- Row End -->
  </div>
  </div>
  </div>
  </div>
</section>
<!-- /.content -->
<script>
$(function(){
 
  // $('#students-edit-form-basicinfo').validate({
  //   rules:{
  //     first_name:{
  //       required:true,
  //     },
  //     father_cnic:{
  //       required:true,
  //     }
  //   },
  //   messages:{
  //     father_cnic:{
  //       required:'father cnic No is Required',
  //     }
  //   },
  //   errorElement: 'span',
  //   errorPlacement: function (error, element) {
  //     error.addClass('invalid-feedback');
  //     element.closest('.form-group').append(error);
  //   },
  //   highlight: function (element, errorClass, validClass) {
  //     $(element).addClass('is-invalid');
  //   },
  //   unhighlight: function (element, errorClass, validClass) {
  //     $(element).removeClass('is-invalid');
  //   }
  // });

//   $('#students-edit-form-basicinfo').ajaxForm({
//     beforeSubmit:function(formData, jqForm, options){
//     return $('#students-edit-form-basicinfo').valid();
//     $('#submitBtn').html("Ajax Request is Processing!");
//     $('#submitBtn').prop('disabled', true);
//    },
//    success:function(responseText, statusText, xhr, form){
//       $('#submitBtn').html("Submit");
//       $('#submitBtn').prop('disabled', false);
//       var json = $.parseJSON(responseText);
//       console.log(json);
//       if(json.success){
//         toastr.success(json.msg);
//         <?php
//         if($id == ''){
//           ?>
//           location.href = '#/students?status=1';
//           <?php
//           }else{
//           ?>
//           location.href = '#/students?status=1';
//           <?php
//         }
//         ?>
//       }else{
//         toastr.error(json.msg);
//       }
//       return false;
//     }

// });

 $('#students-edit-form-basicinfo').validate({ // <- attach '.validate()' to your form
            // Rules for form validation
            rules: {
                file: {
                    required: true
                },
            },
            // Messages for form validation
            messages: {
                file: {
                    required: 'Document Required to Upload'
                }
            },
            submitHandler: function (form) {

                    var myData = new FormData($("#students-edit-form-basicinfo")[0]);
                    //var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                   // myData.append('_token', CSRF_TOKEN);
                    // myData.append('roles', list_id);


                    swal({
                        title: "Confirm to Upload Student in <?php echo $campusInfo->campus_name; ?>",
                        text: "Update Student Information!",
                        type: "warning",
                        showCancelButton: true,
                        closeOnConfirm: false,
                        showLoaderOnConfirm: true,
                        confirmButtonClass: "btn-danger",
                        confirmButtonText: "Yes, Upload!"
                    }, function () {

                        $.ajax({
                            url: 'admin.php?c=students&m=import',
                            type: 'POST',
                            data: myData,
                            dataType: 'json',
                            cache: false,
                            processData: false,
                            contentType: false,
                            beforeSend: function () {
                                $('#loader').show();
                                $("#submit").prop('disabled', true); // disable button
                            },
                            success: function (data) {

                                if (data.type === 'success') {
                                    swal("Done!", "It was succesfully done!", "success");
                                    location.href = '#/students?status=1';
                                    notify_view(data.type, data.message);
                                    $('#loader').hide(); 
                                    $("#submit").prop('disabled', false); // disable button
                                    $("html, body").animate({scrollTop: 0}, "slow");
                                    $('#myModal').modal('hide'); // hide bootstrap modal

                                } else if(data.type === 'error') {
                                    // if (data.error_msg) {
                                    //     $.each(data.errors, function (key, val) {
                                    //         $('#error_' + key).html(val);
                                    //     });
                                    // }
                                    $("#status").html(data.message);
                                    $('#loader').hide();
                                    $("#submit").prop('disabled', false); // disable button
                                    swal("Error sending!", "Please try again", "error");

                                }

                            }
                        });
                    });

                
            }
            // <- end 'submitHandler' callback
        });                    



});
</script>   
