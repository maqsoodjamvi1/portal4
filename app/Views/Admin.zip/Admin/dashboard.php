<?= $this->extend('layouts/admin_template') ?>

<?= $this->section('content') ?>
 <!-- Content Header (Page header) -->
 <style type="text/css">
   .info-box{
    min-height: 110px !important;
   }
   .config_steps li{
    color: red;
   }
 </style>
   <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
               Dashboard
            </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="">
        <ul class="config_steps">
        <?php 
        $this->session = \Config\Services::session();
        $campus_id = session()->get('member_campusid');;
        $schoolinfo = getSchoolInfo();
        $db = \Config\Database::connect();

        $academic_session_info = $db->table('academic_session')->where('system_id', $schoolinfo->system_id)->get()->getRow();
        //print_r($academic_session_info);
        /*$this->db->where('system_id', $schoolinfo->system_id);
        $academic_session_info = $this->db->get('academic_session')->row();*/
        if(empty($academic_session_info->session_id)){
          echo "<li>Step 1 Of 10 add <strong>Academic Session</strong> To Complete System Configuration. 
          <a style='text-decoration: underline;' href='admin.php#/academic_session?m=add'>click here</a></li>";  
        }
        ?> 
       <?php 
        // $this->db->where('system_id', $schoolinfo->system_id);
        // $term_info = $this->db->get('terms')->row();
        // if(empty($term_info->term_id)){
        //   echo "<li>Step 2 Of 10 add <strong>Terms</strong> To Complete System Configuration. <a style='text-decoration: underline;' href='admin.php#/terms?m=add'>click here</a></li>";  
        // }
        ?>
       <?php 
        // $this->db->where('system_id', $schoolinfo->system_id);
        // $terms_session_info = $this->db->get('terms_session')->row();
        
        // if(empty($terms_session_info->term_session_id)){
        //   echo "<li>Step 3 Of 10 add <strong>Terms Session</strong> To Complete System Configuration. <a style='text-decoration: underline;' href='admin.php#/terms_session?m=add'>click here</a></li>";  
        // }
        ?>
        <?php 
        // $this->db->where('system_id', $schoolinfo->system_id);
        // $classes_info = $this->db->get('classes')->row();
        // if(empty($classes_info->class_id)){
        //   echo "<li>Step 4 Of 10 add <strong>Classes</strong> To Complete System Configuration. <a style='text-decoration: underline;' href='admin.php#/classes?m=add'>click here</a></li>";  
        // }
        ?>   
        <?php 
        // $this->db->where('system_id', $schoolinfo->system_id);
        // $sections_info = $this->db->get('sections')->row();
        // if(empty($sections_info->section_id)){
        //   echo "<li>Step 5 Of 10 add <strong>Sections</strong> To Complete System Configuration. <a style='text-decoration: underline;' href='admin.php#/sections?m=add'>click here</a></li>";  
        // }
        ?>   
        <?php 
        // $classSections_info = $this->db->query('SELECT * FROM class_section WHERE campus_id='.$campus_id)->row();
        
        // if(empty($classSections_info->cls_sec_id)){
        //   echo "<li>Step 6 Of 10 add <strong>Class Section</strong> To Complete System Configuration. <a  style='text-decoration: underline;' href='admin.php#/class_section?m=add'>click here</a></li>";  
        // }
        ?> 
        <?php 
        // $this->db->where('system_id', $schoolinfo->system_id);
        // $subjects_info = $this->db->get('allsubject')->row();
        // if(empty($subjects_info->sid)){
        //   echo "<li>Step 7 Of 10 add <strong>Subjects</strong> To Complete System Configuration. <a  style='text-decoration: underline;' href='admin.php#/subjects?m=add'>click here</a></li>";  
        // }
        ?>
        <?php 
        // $SectionsSubject_info = $this->db->query('SELECT * FROM section_subjects WHERE subject_id IN (SELECT sid FROM allsubject WHERE system_id ='.$schoolinfo->system_id.') AND cls_sec_id IN(SELECT cls_sec_id FROM class_section WHERE campus_id='.$campus_id.')')->row();
        // if(empty($SectionsSubject_info->sec_sub_id)){
        //   echo "<li>Step 8 Of 10 add <strong>Section Subjects</strong> To Complete System Configuration. <a  style='text-decoration: underline;' href='admin.php#/section_subjects?m=add'>click here</a></li>";  
        // }
        ?>
        <?php 
        // $this->db->where('system_id', $schoolinfo->system_id);
        // $fee_type_info = $this->db->get('fee_type')->row();    
        // if(empty($fee_type_info->fee_type_id)){
        //   echo "<li>Step 9 Of 10 add <strong>Fee Types</strong> To Complete System Configuration. <a  style='text-decoration: underline;' href='admin.php#/fee_type?m=add'>click here</a></li>";  
        // }
        ?>    
        <?php 
        // $this->db->where('campus_id', $campus_id);
        // $fee_amount_info = $this->db->get('fee_amount')->row();   
        // if(empty($fee_amount_info->amount_id)){
        //   echo "<li>Step 10 Of 10 add <strong>Fee Structure</strong> To Complete System Configuration. <a  style='text-decoration: underline;' href='admin.php#/fee_amount?m=add'>click here</a></li>";  
        // }
        ?> 
      </ul>  
    </div>
      <!-- Info boxes -->
      <div class="row">
        <?php //if(hasPermission('admin-db-students')){ ?>
          
        <div class="col-md-3 col-sm-6 col-xs-12">
          <a href="<?php echo '#/students?status=1';?>" >  
          <div class="info-box">
            <span class="info-box-icon bg-primary" style="background-color: #3c8dbc !important;"><i class="fas fa-user-graduate"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Students</span>
              <span class="info-box-number"><?php print_r($noOfstudent); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          </a>
          <!-- /.info-box -->
        </div>
      <?php //} ?>
        <!-- /.col -->
        <?php if(hasPermission('admin-db-teacher')){ ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <a href="<?php echo '#/users?status=1';?>" >  
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fas fa-chalkboard-teacher"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Teachers</span>
              <span class="info-box-number"><?php print_r($infoteachers); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          </a>
          <!-- /.info-box -->
        </div>
      <?php } ?>
        <!-- /.col -->
        <!-- fix for small devices only -->
        <?php if(hasPermission('admin-db-fee-collection')){ ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <a href="<?php echo '#/fee_chalan';?>"> 
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="far fa-money-bill-alt"></i></span>
            <div class="info-box-content">
              <?php if($monthlyFee){ ?>
              <span class="info-box-text"><?php echo date('M Y').' '.$monthlyFee->fee_type_name; ?></span>
              <?php } ?>
              <?php if($prjectedFee_info){ ?> 
              <span class="info-box-number" style="font-size: 12px !important;font-weight: normal;"><?php echo "Projected : ".$prjectedFee_info->project_fee; ?><br><?php echo "Paid : ".$PaidFee_info->paid_fee; ?><br><?php echo "Unpaid : ".$RemainingBalance_info->remaining_balance; ?></span>
              <?php } ?>
            </div>
            <!-- /.info-box-content -->
          </div>
          </a>
          <!-- /.info-box -->
        </div>
      <?php } ?>
        <!-- /.col -->
        <?php if(hasPermission('admin-db-attendance')){ ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <a href="<?php echo '#/students_attendance?m=add';?>"> 
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fas fa-receipt"></i></span>
            <div class="info-box-content">
              <span class="info-box-text"><?php echo date('D j M Y'); ?></span>
              <span class="info-box-number" style="font-size: 12px !important;font-weight: normal;"><?php echo "Present : ".$totalPresent->present_total; ?><br><?php echo "Absent : ".$totalabsent->absent_total; ?><br><?php echo "Leaves : ".$totalLeaves->leaves_total; ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <?php } ?>
        <!-- /.col -->
     <!--  </div> -->
      <!-- /.row -->
      <!-- Info boxes Session Info -->
      <!-- <div class="row"> -->
        <?php if(hasPermission('admin-db-session')){ ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <a href="<?php echo '#/academic_session';?>" >  
          <div class="info-box">
            <span class="info-box-icon bg-primary" style="background-color: #3c8dbc !important;"><i class="far fa-calendar-alt"></i></span>
            <div class="info-box-content">
             
              <span class="info-box-text">Session <?php if($academic_session){ ?> (<?php echo $academic_session->session_name; ?>)<?php } ?></span>
               <?php if($academic_session){ ?>
              <span class="info-box-number" style="font-size: 12px !important;font-weight: normal;">Start Date: <?php echo date('D j M Y', strtotime($academic_session->start_date)); ?> <br> End Date: <?php echo date('D j M Y', strtotime($academic_session->end_date)); ?></span>
               <?php } ?>
            </div>
            <!-- /.info-box-content -->
          </div>
          </a>
          <!-- /.info-box -->
        </div>
      <?php } ?>
        <!-- /.col -->
        <?php if(hasPermission('admin-db-term')){ ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <a href="<?php echo '#/terms?status=1';?>" >  
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fas fa-chalkboard-teacher"></i></span>
            <div class="info-box-content">
              <?php if($termInfo){ ?>
              <span class="info-box-text"> <?php  echo $termInfo->name; ?></span>
              <?php } ?>
              <?php if($termSessionInfo){ ?>
              <span class="info-box-number" style="font-size: 12px !important;font-weight: normal;">Start Date: <?php echo date('D j M Y', strtotime($termSessionInfo->start_date)); ?> <br> End Date: <?php echo date('D j M Y', strtotime($termSessionInfo->end_date)); ?></span>
              <?php } ?>
            </div>
            <!-- /.info-box-content -->
          </div>
          </a>
          <!-- /.info-box -->
        </div>
      <?php } ?>
        <!-- /.col -->
        <!-- fix for small devices only -->
        <?php if(hasPermission('admin-db-week')){ ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <a href="<?php echo '#/fee_chalan';?>"> 
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="far fa-money-bill-alt"></i></span>
            <div class="info-box-content">
              <?php if($termWeeksInfo){ ?>
              <span class="info-box-text"> Week: <?php  echo $termWeeksInfo->week_name; ?></span>
              <span class="info-box-number" style="font-size: 12px !important;font-weight: normal;">Start Date: <?php echo date('D j M Y', strtotime($termWeeksInfo->start_date)); ?> <br> End Date: <?php echo date('D j M Y', strtotime($termWeeksInfo->end_date)); ?></span>
              <?php } ?>
            </div>
            <!-- /.info-box-content -->
          </div>
          </a>
          <!-- /.info-box -->
        </div>
      <?php } ?>
        <!-- /.col -->
        <?php if(hasPermission('admin-db-exam')){ ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <a href="<?php echo '#/students_attendance?m=add';?>"> 
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fas fa-receipt"></i></span>
            <div class="info-box-content">
              <?php if($examsInfo){ ?>
              <span class="info-box-text"><?php echo $examsInfo->exam_name; ?></span>
              <span class="info-box-number" style="font-size: 12px !important;font-weight: normal;"><?php echo "Start Date : ".date('D j M Y', strtotime($examsInfo->exam_start_date)); ?><br><?php echo "End Date :".date('D j M Y', strtotime($examsInfo->exam_end_date)); ?></span>
              <?php } ?>
            </div>
            <!-- /.info-box-content -->
          </div>
          </a>
          <!-- /.info-box -->
        </div>
        <?php } ?>
        <!-- /.col -->
        <?php if(hasPermission('admin-db-expense')){ ?>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <a href="<?php echo '#/profit_loss_report';?>"> 
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="far fa-money-bill-alt"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Expense (<?php echo date('M Y'); ?>)</span>
              <span class="info-box-number" style="font-size: 12px !important;font-weight: normal;"><?php echo "Collection : ".$totalCollection->TotalCol; ?><br><?php echo "Expense : ".$expenseInfoTotal->totalSum; ?><br><?php echo "Profit/Loss : ".($totalCollection->TotalCol - $expenseInfoTotal->totalSum); ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
         </a>
          <!-- /.info-box -->
        </div>
        <?php } ?>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <div class="row">
      <?php if(hasPermission('admin-db-fee-collection')){ ?>
      <div class="col-sm-6">
         <!-- PIE CHART -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title"><?php if($monthlyFee){ echo $monthlyFee->fee_type_name; } ?> Collection (<?php echo date('M Y'); ?>)</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="pieChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
      </div>
      <div class="col-sm-6">
        <!-- STACKED BAR CHART -->
            <div class="card card-success">
              <div class="card-header">
                <h3 class="card-title">Fee Collection <?php if($academic_session){ ?>  (<?php echo $academic_session->session_name; ?>) <?php } ?></h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <div class="chart">
                  <canvas id="stackedBarChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
      </div>  
       
      </div>
      <!-- Main row -->
      <!-- /.row -->
      <!-- Attendance and Student Strength -->
      <div class="row">
      <div class="col-sm-6">
         <!-- PIE CHART -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Attendance (<?php echo date('D j M Y'); ?>) </h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="pieChartAttendance" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
      </div>
      <div class="col-sm-6">
        <!-- STACKED BAR CHART -->
            <div class="card card-success">
              <div class="card-header">
                <h3 class="card-title">Current Student Strength</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <div class="chart">
                  <canvas id="stackedBarChartSection" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
      </div>             
      </div>
      <!-- Main row -->
    </section>
    <!-- Page specific script -->
<?php 
    $period = '';
    if($academic_session){
    $start    = (new DateTime($academic_session->start_date))->modify('first day of this month');
    $end      = (new DateTime($academic_session->end_date))->modify('first day of next month');
    $interval = DateInterval::createFromDateString('1 month');
    $period   = new DatePeriod($start, $interval, $end);
    }
    $prStr = '';
    if(!empty($period)){
    foreach ($period as $dt) {
        $prStr .= "'".$dt->format("Y-m") . "', ";
    }
    }

    //echo $paidStr;

?>
<script>
  $(function () {
    /* ChartJS
     * -------
     * Here we will create a few charts using ChartJS
     */

    //--------------
    //- AREA CHART -
    //--------------

    // Get context with jQuery - using jQuery's .get() method.
    //var areaChartCanvas = $('#areaChart').get(0).getContext('2d')

    var areaChartData = {
      labels  : [<?php echo rtrim($prStr, ', '); ?>],
      datasets: [
        {
          label               : 'Paid',
          backgroundColor     : 'rgba(60,141,188,0.9)',
          borderColor         : 'rgba(60,141,188,0.8)',
          pointRadius          : false,
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(60,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : [<?php echo rtrim($paidStr, ', '); ?>]
        },
        {
          label               : 'Unpaid',
          backgroundColor     : 'rgba(210, 214, 222, 1)',
          borderColor         : 'rgba(210, 214, 222, 1)',
          pointRadius         : false,
          pointColor          : 'rgba(210, 214, 222, 1)',
          pointStrokeColor    : '#c1c7d1',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          data                : [<?php echo rtrim($unpaidStr, ', '); ?>]
        },
      ]
    }

    var areaChartOptions = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        display: false
      },
      scales: {
        xAxes: [{
          gridLines : {
            display : false,
          }
        }],
        yAxes: [{
          gridLines : {
            display : false,
          }
        }]
      }
    }

    
    var donutData = {
      labels: [
          'Paid',
          'Discounted',
          'Unpaid'
      ],
      datasets: [
        {
          data: [<?php echo $PaidFee_info->paid_fee; ?>,<?php echo $discountedFee_info->discounted_fee; ?>,<?php echo $RemainingBalance_info->remaining_balance; ?>],
          backgroundColor : ['#00a65a','#f39c12','#f56954'],
        }
      ]
    }
  
    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.

    var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
    var pieData        = donutData;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions
    })


    // PIAChart Attendance 

      var donutData = {
      labels: [
          'Present',
          'Absent',
          'Leaves'
      ],
      datasets: [
        {
          
          data: [<?php echo $totalPresent->present_total; ?>,<?php echo $totalabsent->absent_total; ?>,<?php echo $totalLeaves->leaves_total; ?>],
          backgroundColor : ['#00a65a','#f39c12','#f56954'],
        }
      ]
    }
  
    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.

    var pieChartCanvas = $('#pieChartAttendance').get(0).getContext('2d')
    var pieData        = donutData;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions
    })

    //-------------
    //- BAR CHART -
    //-------------
    //var barChartCanvas = $('#barChart').get(0).getContext('2d')
   
    var barChartData = $.extend(true, {}, areaChartData)
    
  //---------------------
  //- STACKED BAR CHART -
  //---------------------

 var areaChartData2 = {
      labels  : [<?php echo rtrim($clsStr, ', '); ?>],
      datasets: [
        {
          label               : 'Male',
          backgroundColor     : 'rgba(60,141,188,0.9)',
          borderColor         : 'rgba(60,141,188,0.8)',
          pointRadius          : false,
          pointColor          : '#3b8bba',
          pointStrokeColor    : 'rgba(60,141,188,1)',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(60,141,188,1)',
          data                : [<?php echo rtrim($stdMCountStr, ', '); ?>]
        },
        {
          label               : 'Female',
          backgroundColor     : 'rgba(210, 214, 222, 1)',
          borderColor         : 'rgba(210, 214, 222, 1)',
          pointRadius         : false,
          pointColor          : 'rgba(210, 214, 222, 1)',
          pointStrokeColor    : '#c1c7d1',
          pointHighlightFill  : '#fff',
          pointHighlightStroke: 'rgba(220,220,220,1)',
          data                : [<?php echo rtrim($stdFCountStr, ', '); ?>]
        },
      ]
    }

    var areaChartOptions = {
      maintainAspectRatio : false,
      responsive : true,
      legend: {
        display: false
      },
      scales: {
        xAxes: [{
          gridLines : {
            display : false,
          }
        }],
        yAxes: [{
          gridLines : {
            display : false,
          }
        }]
      }
    }


    var barChartData = $.extend(true, {}, areaChartData)
    var stackedBarChartCanvas = $('#stackedBarChart').get(0).getContext('2d')
    var stackedBarChartData = $.extend(true, {}, barChartData)

    var stackedBarChartOptions = {
      responsive              : true,
      maintainAspectRatio     : false,
      scales: {
        xAxes: [{
          stacked: true,
        }],
        yAxes: [{
          stacked: true
        }]
      }
    }

    new Chart(stackedBarChartCanvas, {
      type: 'bar',
      data: stackedBarChartData,
      options: stackedBarChartOptions
    })

    var barChartData = $.extend(true, {}, areaChartData2)
    var stackedBarChartCanvas2 = $('#stackedBarChartSection').get(0).getContext('2d')
    var stackedBarChartData = $.extend(true, {}, barChartData)

    var stackedBarChartOptions = {
      responsive              : true,
      maintainAspectRatio     : false,
      scales: {
        xAxes: [{
          stacked: true,
        }],
        yAxes: [{
          stacked: true
        }]
      }
    }

    new Chart(stackedBarChartCanvas2, {
      type: 'bar',
      data: stackedBarChartData,
      options: stackedBarChartOptions
    })
  })
</script><?php } ?>          
<?= $this->endSection() ?>