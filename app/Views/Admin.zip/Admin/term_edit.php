<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>
<?php
{
	$header = 'Add Term';
	$id = '';
	$name = '';
	$short_name = '';

}
?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-8">
            <h1>
               Terms
               <?php 
            	// $schoolinfo = getSchoolInfo();
            	// $this->db->where('system_id', $schoolinfo->system_id);
				// $terms_info = $this->db->get('terms')->row();
				if(empty($terms_info->term_id)){ ?>
					 <span style='background: green;color: #fff !important;float: right;padding: 5px 10px;margin-top: 0px;
    font-size: 16px;'>Step 2 Of 10 To Complete System Configuration</span>
    			<audio autoplay  controls>
				 <source src="audio/Step3Terms.m4a" type="audio/ogg">
				  <source src="audio/Step3Terms.m4a" type="audio/mpeg">
				Your browser does not support the audio element.
				</audio> 	
			<?php } ?>      
            </h1>
          </div>
          <div class="col-sm-4">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin/'); ?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Terms</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
		  <div class="card card-primary card-outline card-tabs">
          	<div class="card-header p-0 pt-1 border-bottom-0">
			<ul class="nav nav-tabs">
				<li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/terms'); ?>">Terms</a></li>
				<?php
				if($id == ''){
					?>
				<li class="nav-item"><a class="nav-link active" href="<?php echo base_url('admin/terms/add'); ?>"><?php echo $header;?></a></li>
					<?php
				}else{
					?>
				<li class="nav-item"><a class="nav-link active" href="<?php echo base_url('admin/terms/edit/id=') . $id;?>"><?php echo $header;?></a></li>
					<?php
				}
				?>
			</ul>
			<div class="card-body">	
			<div class="tab-content">
			<?php
			echo form_open( base_url('admin/terms/save') , 'role="form" id="user-edit-form"');
			echo form_hidden('id', $id);
			?>
			<div class="col-lg-12">
			<div class="table-responsive">  
                <table class="table table-bordered" id="dynamic_field"> 
                <thead>
			        <tr>
			           <td><label for="subject_name"> Name</label></td>
			           <td> <label for="subject_name">Short Name</label></td>
			        </tr>
			    </thead>	
				<?php 
				if(!empty($info)){
				$i = 0;	
				foreach ($info as $key => $value) { ?>
                    <tr>  
                        <td>
                        	<input type="hidden" name="rowscount[]" value="1" />	
                        	<input type="hidden" name="id<?php echo $i; ?>" value="<?php echo $value->term_id; ?>">
                        	<input type="text" name="name<?php echo $i; ?>"  value="<?php echo $value->name; ?>" placeholder="Term Name" class="form-control name_list" required="" /></td>  
                        <td><input type="text" name="short_name<?php echo $i; ?>" value="<?php echo $value->short_name; ?>" placeholder="Short Name" class="form-control name_list" required="" /></td> 
                    </tr>
                    <?php $i++ ?>  
                    <?php } ?>
                    <?php }else{ 
                    $i = 2;	
                    ?>
                    	 <tr>  
                        <td>
                        	<input type="hidden" name="rowscount[]" value="1" />	
                        	<input type="hidden" name="id0" value="0">
                        	<input type="text" name="name0"  value="1st Term" placeholder="Term Name" class="form-control name_list" required="" /></td>  
                        <td><input type="text" name="short_name0" value="T1" placeholder="Short Name" class="form-control name_list" required="" /></td> 
                    </tr>
                    <tr>  
                        <td>
                        	<input type="hidden" name="rowscount[]" value="1" />	
                        	<input type="hidden" name="id1" value="0">
                        	<input type="text" name="name1"  value="2nd Term" placeholder="Term Name" class="form-control name_list" required="" /></td>  
                        <td><input type="text" name="short_name1" value="T2" placeholder="Short Name" class="form-control name_list" required="" /></td> 
                    </tr>
                    <?php } ?>
                    <tr>    <td></td> <td><button type="button" name="add" id="add" class="btn btn-success">Add More</button></td>  </tr>
                </table>  
             
            </div>
			 
		  </div>
			  <div class="form-group">
                <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
				<button type="reset" class="btn btn-default">Reset</button>
				<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
              </div>
            <?php echo form_close();?>
			</div>
		  </div>
        </div>
      </div>
  </div>
</div>
</section>
    <!-- /.content -->
<script type="text/javascript">
$(document).ready(function(){      
      var i= <?php echo $i; ?>;  
      //alert(i);
   
      $('#add').click(function(){  
        
           $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added"><td><input type="hidden" name="id'+i+'" value="0"><input type="hidden" name="rowscount[]" value="1" /><input type="text" name="name'+i+'" placeholder="Term Name" class="form-control name_list" required /></td><td><input type="text" name="short_name'+i+'" placeholder="Short Name" class="form-control name_list" required /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove btn-sm">X</button></td></tr>'); 
              i++;   
      });
  
      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  
  
    });	
$(document).ready(function () {
    var counter = 1;
    $("#addrow").on("click", function () {
        var newRow = $("<tr>");
        var cols = "";

        cols += '<td><input type="hidden" name="rowscount[]" value="1" /><input type="text" class="form-control" name="name' + counter + '"/></td>';
         cols += '<td><input type="text" class="form-control" name="short_name' + counter + '" id="short_name' + counter + '" value=""></td>';
        cols += '<td><input type="button" class="ibtnDel btn-sm btn btn-md btn-danger " style="padding: 3px 10px;"  value="Delete"></td>';
        newRow.append(cols);
        $("table.order-list").append(newRow);
        counter++;
    });

    $("table.order-list").on("click", ".ibtnDel", function (event) {
        $(this).closest("tr").remove();       
        counter -= 1
    });

});		
$(function(){
	// $('#user-edit-form').validate({
	// 	rules:{
	// 		name:{
	// 			required:true,
				
	// 		}
	// 	},
	// 	messages:{
	// 		name:{
	// 			required:'Term is Required',
				
	// 		}
	// 	}
	// });
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			//return $('#user-edit-form').valid();
			$('#submitBtn').html("Saving");
			$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
			var json = $.parseJSON(responseText);
			$('#submitBtn').html("Save");
			$('#submitBtn').prop('disabled', false);
			if(json.term_session_id == false){
	        	window.location.href = '<?php echo base_url(); ?>admin/terms_session/add';
	        	return;
	      	}
			//console.log(json.success);
			if(json.success){
				toastr.success(json.msg);
				<?php if($id == ''){ ?>
					location.href = '<?php echo base_url('admin/terms'); ?>';
				<?php }else{ ?>
					location.href = '<?php echo base_url('admin/terms/edit/id/'.$id); ?>';
				<?php } ?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
})
</script>
<?= $this->endSection() ?>