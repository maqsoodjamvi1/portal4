<link rel="stylesheet" href="<?php echo base_url();?>resource/bootstrap-switch/css/bootstrap3/bootstrap-switch.min.css" />
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
               English Question T/F
            </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">English Question T/F</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
      <div class="card-header p-0 pt-1 border-bottom-0">
			<div class="card-body">
      <div class="col-lg-12">
        <?php if($data){ ?>
        <table class="table">
          <tr>
            <td><b>Subject:</b> <?php echo $data[0]['subject']; ?></td>
            <td><b>Category:</b> <?php echo $data[0]['subject_category']; ?></td>
            <td><b>Topic:</b> <?php echo $data[0]['topic']; ?></td>
          </tr>
        </table>
        <?php $i = 1;?>
				<?php foreach ($data as $key => $value) { ?>
				<h4><?php echo "<p>(".$i.")</p> ".$value['question_eng']; ?></h4>
				<ul>
					<?php //foreach($value['questionOptions'] as $value2) { ?>

						<li>True<?php //echo $value2; ?></li>

						<li>False<?php //echo $value2; ?></li>

					<?php //} ?>

				</ul>

        <?php $i++; ?>

				<?php } ?>
        <?php } ?>

			</div>

    </div>

    </div>

            <!-- /.box-body -->

    </div>

         <!-- /.box -->

    </div>

  </div>

</section>

<!-- /.content -->

<script src="<?php echo base_url();?>resource/bootstrap-switch/js/bootstrap-switch.min.js"></script>

<script type="text/javascript">

$(function(){

});

</script>