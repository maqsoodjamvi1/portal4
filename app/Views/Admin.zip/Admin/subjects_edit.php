<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>
<?php
	if (isset($info)) {
		$header = 'Edit Subject';
		$id = $info->sid;
		$subject_name = $info->subject_name;
		$subject_short_name = $info->subject_short_name;
	} else {
		$header = 'Add Subject';
		$id = '';
		$subject_name = '';
		$subject_short_name = '';
	}
?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
           Subjects
          <?php if (empty($subjects_info->sid)) : ?>
            <span style='background: green; color: #fff !important; float: right; padding: 5px 10px; margin-top: 0px; font-size: 16px;'>
                Step 7 Of 10 To Complete System Configuration
            </span>
            <audio autoplay controls>
                <source src="<?= base_url('audio/Step9Subject.m4a') ?>" type="audio/ogg">
            </audio>
        <?php endif; ?>
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= base_url('admin/dashboard') ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Subjects</li>
        </ol>
      </div>
    </div>
  </div>
</section>

<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
        <div class="card-header p-0 pt-1 border-bottom-0">
        <ul class="nav nav-tabs">
          <li class="nav-item"><a class="nav-link" href="<?= base_url('admin/subjects') ?>">Subjects</a></li>
          <?php if ($id == '') { ?>
          <li class="nav-item"><a class="nav-link active" href="<?= base_url('admin/subjects/add') ?>"><?= $header; ?></a></li>
          <?php } else { ?>
          <li class="nav-item"><a class="nav-link active" href="<?= base_url('admin/subjects/edit') ?>?id=<?= $id ?>"><?= $header; ?></a></li>
          <?php } ?>
        </ul>
        </div>
        <div class="card-body">
          <div class="tab-content">
          <div class="container">
            <div class="form-group">
              <?= form_open('admin/subjects/save', ['role' => 'form', 'id' => 'user-edit-form']) ?>
              <div class="table-responsive">
                <table class="table table-bordered" id="dynamic_field">
                  <?php if (!empty($subjectsinfo)) {
                    $i = 0;
                    foreach ($subjectsinfo as $key => $value) { ?>
                    <tr>
                      <td>
                        <input type="hidden" name="rowscount[]" value="1" />
                        <input type="hidden" name="id<?= $i ?>" value="<?= $value->sid ?>">
                        <input type="text" name="subject_name<?= $i ?>" value="<?= $value->subject_name ?>" placeholder="Subject Name" class="form-control name_list" required />
                      </td>
                      <td><input type="text" name="short_name<?= $i ?>" value="<?= $value->subject_short_name ?>" placeholder="Short Name" class="form-control name_list" required /></td>
                    </tr>
                  <?php $i++; } } else { $i = 3; ?>
                    <tr><td><input type="hidden" name="rowscount[]" value="1" /><input type="hidden" name="id0" value="0"><input type="text" name="subject_name0" value="Math" placeholder="Subject Name" class="form-control name_list" required /></td><td><input type="text" name="short_name0" value="Mth" placeholder="Short Name" class="form-control name_list" required /></td></tr>
                    <tr><td><input type="hidden" name="rowscount[]" value="1" /><input type="hidden" name="id1" value="0"><input type="text" name="subject_name1" value="English" placeholder="Subject Name" class="form-control name_list" required /></td><td><input type="text" name="short_name1" value="Eng" placeholder="Short Name" class="form-control name_list" required /></td></tr>
                    <tr><td><input type="hidden" name="rowscount[]" value="1" /><input type="hidden" name="id2" value="0"><input type="text" name="subject_name2" value="Urdu" placeholder="Subject Name" class="form-control name_list" required /></td><td><input type="text" name="short_name2" value="Ur" placeholder="Short Name" class="form-control name_list" required /></td></tr>
                  <?php } ?>
                  <tr><td></td><td></td><td><button type="button" name="add" id="add" class="btn btn-success">Add More</button></td></tr>
                </table>
              </div>
              <div class="row">
                <div class="col-lg-12">
                  <div class="form-group">
                    <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Reset</button>
                    <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
                  </div>
                </div>
              </div>
              <?= form_close() ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script>
$(document).ready(function(){
  var i = <?= $i ?>;
  $('#add').click(function(){
    $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added"><td><input type="hidden" name="id'+i+'" value="0"><input type="hidden" name="rowscount[]" value="1" /><input type="text" name="subject_name'+i+'" placeholder="Subject Name" class="form-control name_list" required /></td><td><input type="text" name="short_name'+i+'" placeholder="Short Name" class="form-control name_list" required /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove btn-sm">X</button></td></tr>');
    i++;
  });
  $(document).on('click', '.btn_remove', function(){
    var button_id = $(this).attr("id");
    $('#row'+button_id).remove();
  });
});
</script>
<?= $this->endSection() ?>