<?php
	if(isset($info)){		
			$header = 'Edit Time Table';
			$id = 0;
			$class_id = '';
			$tid = '';
			$subject_id = '';
			
		}else{
			$header = 'Add Time Table';
			$id = 0;
			$class_id = '';
			$tid = '';
			$subject_id = '';
		}
?>
<!-- Content Header (Page header) -->  
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
          Time Table
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Time Table</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
		   <div class="card card-primary card-outline card-tabs">
        	<div class="card-header p-0 pt-1 border-bottom-0">
			<ul class="nav nav-tabs">
			<?php if($id == ''){ ?>
				<li class="nav-item"><a class="nav-link active" href="<?php echo '#/timetable?m=add';?>"><?php echo $header;?></a></li>
			<?php }else{ ?>
				<li class="nav-item"><a class="nav-link" href="<?php echo '#/timetable?m=edit&id=' . $id;?>"><?php echo $header;?></a></li>
			<?php } ?>
			</ul>
	<div class="card-body"> 		
	<div class="tab-content">
		<?php
			echo form_open('c=timetable&m=save', 'role="form" id="user-edit-form"');
			echo form_hidden('cls_sec_id', (string) $id) 

			//echo form_hidden('id', $id);
		?>
			<div class="form-group">
				<select class="form-control" name="cls_sec_id" id="cls_sec_id">
					<option value="">Select Class</option>
				<?php if(isset($sectionsclassinfo)){
					foreach ($sectionsclassinfo as  $sectionvalue) {
				 ?>
				<option value="<?php echo $sectionvalue['section_id']; ?>"><?php echo $sectionvalue['sectionclassname']; ?></option>
				<?php } ?>
				<?php } ?>	
				</select>
			</div>
			<div class="col-md-12 bg">
		        <div id="loader-1" class="overlay text-center" style="display: none;"><i class="fas fa-2x fa-sync-alt fa-spin"></i></div>
		      </div>
			<div id="timetablearea" class="timetablearea">			
			</div>
		  <div class="form-group">
            <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
			<button type="reset" class="btn btn-default">Reset</button>
			<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
          </div>
        <?php echo form_close();?>
		</div>
		</div>
        </div>
      </div>
      </div>
      </div>
    </section>
    <!-- /.content -->
<script type="text/javascript">
$(function(){
	//$(".select2").select2({closeOnSelect:false});
	$("#cls_sec_id").change(function(){
        var cls_sec_id = $('#cls_sec_id').val();
        $("#loader-1").css("display", "block");
	     $.ajax({
            url:'<?php echo site_url('c=timetable&m=data');?>', 
            type: "POST",
            data:{cls_sec_id:cls_sec_id },
            success:function(res){
            	//console.log(res);
 			   $("#timetablearea").html(res);
 			   $("#loader-1").css("display", "none");
			 }
         });
    });
	
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			$('#submitBtn').html("Saving");
      		$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
			$('#submitBtn').html("Save");
      		$('#submitBtn').prop('disabled', false);
			var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
				<?php
				if($id == ''){
					?>
					location.href = '#/timetable?m=add';
					<?php
				}else{
					?>
					location.href = '#/timetable?m=add';
					<?php
				}
				?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
});
</script>