<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>
<?php

	if(isset($info)){
		$header = 'Edit Section';
		// $id = $info->section_id;
		// $section_name = $info->section_name;
		// $short_name = $info->short_name;
	}else{

		$header = 'Add Section';
		$id = '';
		$section_name = '';
		$short_name ='';
	}

	//print_r($_SERVER['HTTP_HOST']);

?>
    <!-- Content Header (Page header) -->
     <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
			   Sections
			   <?php
			   $sections_info = $sections_info ?? null;
			   if (empty($sections_info) || empty($sections_info->section_id)) :
			   ?>
			     <span style='background: green;color: #fff !important;float: right;padding: 5px 10px;margin-top: 0px;font-size: 16px;'>Step 5 Of 10 To Complete System Configuration</span>
			     <audio autoplay controls>
			         <source src="audio/Step7section.m4a" type="audio/ogg">
			         <source src="audio/Step7section.m4a" type="audio/mpeg">
			     </audio>
			   <?php endif; ?>
			</h1>

          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url('admin/dashboard');?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Sections</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
		  <div class="card card-primary card-outline card-tabs">
          	<div class="card-header p-0 pt-1 border-bottom-0">
			<ul class="nav nav-tabs">
				<li class="nav-item"><a class="nav-link" href="<?php echo base_url('admin/sections');?>">Sections</a></li>
				<li class="nav-item"><a class="nav-link active" href="<?php echo base_url('admin/sections/add'); ?>"><?php echo $header;?></a></li>
				
			</ul>
		<div class="card-body">		
		<div class="tab-content">
		<?php
			echo form_open( base_url('admin/sections/save') , 'role="form" id="user-edit-form"');
			//echo form_hidden('id', $id);
		?>
		<div class="col-lg-12">
			<div class="table-responsive">  
                <table class="table table-bordered" id="dynamic_field"> 
                <thead>
			        <tr>
			            <td><label for="subject_name">Section Name</label></td>
			            <td> <label for="subject_name">Short Name</label></td>
			        </tr>
			    </thead>	
				<?php 
				if(!empty($info)){
				$i = 0;
				foreach ($info as $key => $value) { ?>
                    <tr>  
                        <td>
                        	<input type="hidden" name="rowscount[]" value="1" />	
                        	<input type="hidden" name="id<?php echo $i; ?>" value="<?php echo $value->section_id; ?>">
                        	<input type="text" name="section_name<?php echo $i; ?>"  value="<?php echo $value->section_name; ?>" placeholder="Section Name" class="form-control name_list" required="" /></td>  
                        <td><input type="text" name="short_name<?php echo $i; ?>" value="<?php echo $value->short_name; ?>" placeholder=" Short Name" class="form-control name_list" required="" /></td> 
                    </tr>
                    <?php $i++ ?>  
                <?php } ?>
                <?php }else{ 
                $i=2;	
                ?> 
                	<tr>  
                        <td>
                        	<input type="hidden" name="rowscount[]" value="1" />	
                        	<input type="hidden" name="id0" value="0">
                        	<input type="text" name="section_name0"  value="Section A" placeholder="Section Name" class="form-control name_list" required="" /></td>  
                        <td><input type="text" name="short_name0" value="A" placeholder=" Short Name" class="form-control name_list" required="" /></td> 
                    </tr>
                    <tr>  
                        <td>
                        	<input type="hidden" name="rowscount[]" value="1" />	
                        	<input type="hidden" name="id1" value="0">
                        	<input type="text" name="section_name1"  value="Section B" placeholder="Section Name" class="form-control name_list" required="" /></td>  
                        <td><input type="text" name="short_name1" value="B" placeholder=" Short Name" class="form-control name_list" required="" /></td> 
                    </tr>
                <?php } ?>
                <tr><td></td> <td><button type="button" name="add" id="add" class="btn btn-success pull-right">Add More</button></td>  </tr>
                </table>  
             
            </div>
			 
		</div>	
        <div class="row">
		 <div class="col-lg-12">
        <div class="form-group">
            <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
			<button type="reset" class="btn btn-default">Reset</button>
			<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
        </div>
    	</div></div>
        <?php echo form_close();?>
			</div>
		  </div>
      </div>
      </div>
      </div>
      </div>
    </section>
    <!-- /.content -->
<script type="text/javascript">
$(document).ready(function(){      
      var i= <?php echo $i; ?>;  
      $('#add').click(function(){  
           $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added"><td><input type="hidden" name="id'+i+'" value="0"><input type="hidden" name="rowscount[]" value="1" /><input type="text" name="section_name'+i+'" placeholder="Section Name" class="form-control name_list" required /></td><td><input type="text" name="short_name'+i+'" placeholder="Short Name" class="form-control name_list" required /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove btn-sm">X</button></td></tr>'); 
              i++;   
      });
  
      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  
  
 });	
$(function(){
	//$(".select2").select2({closeOnSelect:false});	
$('#user-edit-form').ajaxForm({
	beforeSubmit:function(formData, jqForm, options){
			//return $('#user-edit-form').valid();
			$('#submitBtn').html("Saving");
			$('#submitBtn').prop('disabled', true);
		},
	success:function(responseText, statusText, xhr, form){
		$('#submitBtn').html("Save");
		$('#submitBtn').prop('disabled', false);
		var json = $.parseJSON(responseText);
		if(json.cls_sec_id == false){
	        window.location.href = '<?php echo base_url();?>admin/class_section/add';
	        	return;
	    }
		if(json.success){
			toastr.success(json.msg);	
			location.href = '<?php echo base_url();?>admin/sections';
			
		}else{
			toastr.error(json.msg);
		}
		return false;
	}
	});
});
</script>
<?= $this->endSection() ?>
