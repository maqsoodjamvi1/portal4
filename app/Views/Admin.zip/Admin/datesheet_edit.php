<?php

	if(isset($info) && count($info) > 0){
		$header = 'Edit Datesheet';
		$id = $info->id;
		$subject_name = $info->$subject_name;
	}else{
		$header = 'Add Datesheet';
		$id = '';
		$subject_name = '';
	}
?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
               Datesheet
            </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Datesheet</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
		  <div class="card card-primary card-outline card-tabs">
          <div class="card-header p-0 pt-1 border-bottom-0">
			<ul class="nav nav-tabs">
				<li class="nav-item"><a class="nav-link" href="<?php echo '#/datesheet';?>">Admit Card</a></li>
				<?php if($id == ''){ ?>
				<li class="nav-item"><a class="nav-link active" href="<?php echo '#/datesheet?m=add';?>"><?php echo $header;?></a></li>
				<?php }else{ ?>
				<li class="nav-item"><a class="nav-link active" href="<?php echo '#/datesheet?m=edit&id=' . $id;?>"><?php echo $header;?></a></li>
				<?php } ?>
			</ul>
			<div class="card-body">
			<div class="tab-content">
			<?php
				echo form_open('c=datesheet&m=save', 'role="form" id="datesheet-edit-form"');
				echo form_hidden('id', $id);
			?>
			<div class="row">
			<div class="col-lg-4">
				<div class="form-group">
                  <label for="term">Session</label>
				  <select name="session_id" id="session_id" class="form-control">
				 <!-- <option value="0">Select Session</option>-->
				  <?php foreach($academic_session as $session){ ?>
                  <option value="<?php echo $session->session_id; ?>"><?php echo $session->session_name; ?></option>
				  <?php } ?>
				  </select>
				</div>
			</div>
			<div class="col-lg-4">
			<div class="form-group">
              <label for="term">Exam</label>
			  <select name="eid" id="eid" class="form-control">
			  <?php foreach($examinfo as $exam){ ?>
              <option value="<?php echo $exam->eid; ?>"><?php echo $exam->exam_name; ?></option>
			  <?php } ?>
			  </select>
			</div>
			</div>
			<div class="col-lg-4">
              	<div class="form-group">
                  <label for="term">Section</label>
				  <select name="section_id" id="section_id" class="form-control">
				   <option value="0">Select Section</option>
				   <?php foreach($sectioninfo as $section){
				   ?>
                  <option value="<?php echo $section['section_id']; ?>"><?php echo $section['sectionclassname']; ?></option>
				  <?php } ?>
				  </select>
				</div>
			</div>
			<div class="col-lg-12">
				<div id="subjects_list"></div>	
			</div>	
		</div>
      <div class="form-group">
          <button type="submit" class="btn btn-primary">Save</button>
					<button type="reset" class="btn btn-default">Reset</button>
					<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
      </div>
     <?php echo form_close();?>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- /.content -->
<script type="text/javascript">
$(function(){
$('#session_id').on('change', function() {
	var session_id = $( "#session_id" ).val();
	$.ajax({
            url: 'admin.php?c=ajax&m=selectExam',
            type: "POST",
            data:{session_id: session_id, },
            success:function(res){
 			  // alert(res);		  
			   $("#eid").html(res);
 			   }
         });
	});
$('#section_id').on('change', function() {
	var section_id = $( "#section_id" ).val();
	var eid = $( "#eid" ).val();
	$.ajax({
            url: 'admin.php?c=datesheet&m=selectSubjects',
            type: "POST",
            data:{section_id: section_id,eid: eid, },
            success:function(res){
 			  // alert(res);		  
			   $("#subjects_list").html(res);
 			}
         });
	});
	$('#datesheet-edit-form').validate({
	});
	$('#datesheet-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			//return $('#user-edit-form').valid();
		},
		success:function(responseText, statusText, xhr, form){
			var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
			<?php if($id == ''){ ?>
			<?php }else{ ?>
					//location.href = '#/datesheet?m=edit&id=<?php echo $id;?>&after=edit';
			<?php } ?>
			}else{
				toastr.error(json.msg);
			}

			return false;

		}

	});

});

</script>