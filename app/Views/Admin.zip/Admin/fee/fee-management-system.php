<div class="fee-management-system">
    <!-- Parent Summary Section -->
    <div class="parent-summary">
        <div class="parent-info">
            <h2><?= $parent->f_name ?></h2>
            <div class="parent-contact">
                <span><i class="fas fa-phone"></i> <?= $parent->father_contact ?></span>
                <span><i class="fas fa-home"></i> <?= $parent->address_line1 ?></span>
            </div>
        </div>
        
        <div class="summary-cards">
            <div class="summary-card total-unpaid">
                <div class="card-icon"><i class="fas fa-file-invoice-dollar"></i></div>
                <div class="card-content">
                    <h4>Total Unpaid</h4>
                    <p><?= number_format($summaries['total_unpaid']) ?>/-</p>
                </div>
            </div>
            
            <div class="summary-card balance">
                <div class="card-icon"><i class="fas fa-wallet"></i></div>
                <div class="card-content">
                    <h4>Balance</h4>
                    <p><?= number_format($summaries['balance']) ?>/-</p>
                </div>
            </div>
            
            <div class="summary-card students-count">
                <div class="card-icon"><i class="fas fa-users"></i></div>
                <div class="card-content">
                    <h4>Students</h4>
                    <p><?= count($students) ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="action-buttons">
        <button class="btn btn-primary" onclick="payAll()">
            <i class="fas fa-money-bill-wave"></i> Pay All
        </button>
        <button class="btn btn-secondary" data-toggle="modal" data-target="#discountModal">
            <i class="fas fa-percentage"></i> Apply Discount
        </button>
        <button class="btn btn-info" onclick="sendReminders()">
            <i class="fas fa-sms"></i> Send Reminders
        </button>
    </div>

    <!-- Students and Fees Listing -->
    <div class="students-list">
        <?php foreach ($students as $student): ?>
        <div class="student-section">
            <div class="student-header">
                <div class="student-photo">
                    <img src="<?= base_url('uploads/'.$student->profile_photo) ?>" 
                         alt="<?= $student->first_name ?>" 
                         onerror="this.src='<?= base_url('assets/img/default-student.png') ?>'">
                </div>
                <div class="student-info">
                    <h3><?= $student->first_name.' '.$student->last_name ?></h3>
                    <div class="student-meta">
                        <span class="badge class-badge"><?= $student->class_name ?></span>
                        <span class="badge section-badge"><?= $student->section_name ?></span>
                        <span class="badge unpaid-badge"><?= count($student->unpaid_fees) ?> unpaid fees</span>
                    </div>
                </div>
                <div class="student-total">
                    <span>Total Due:</span>
                    <strong><?= number_format(array_sum(array_column($student->unpaid_fees, 'amount'))) ?>/-</strong>
                </div>
            </div>
            
            <div class="fees-table-container">
                <table class="fees-table">
                    <thead>
                        <tr>
                            <th>Fee Type</th>
                            <th>Period</th>
                            <th>Due Date</th>
                            <th>Amount</th>
                            <th>Discount</th>
                            <th>Payable</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($student->unpaid_fees as $fee): ?>
                        <tr>
                            <td><?= $fee->fee_type_name ?></td>
                            <td><?= date('M Y', strtotime($fee->fee_month)) ?></td>
                            <td><?= date('d M Y', strtotime($fee->due_date)) ?></td>
                            <td><?= number_format($fee->amount) ?>/-</td>
                            <td><?= number_format($fee->discount) ?>/-</td>
                            <td><strong><?= number_format($fee->amount - $fee->discount) ?>/-</strong></td>
                            <td class="actions">
                                <button class="btn-pay" 
                                        data-feeid="<?= $fee->chalan_id ?>"
                                        data-amount="<?= $fee->amount - $fee->discount ?>"
                                        onclick="showPaymentModal(this)">
                                    <i class="fas fa-money-bill-alt"></i> Pay
                                </button>
                                <a href="<?= site_url("admin/fee/generate_chalan/{$fee->chalan_id}") ?>" 
                                   class="btn-challan" target="_blank">
                                    <i class="fas fa-file-invoice"></i> Challan
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endforeach; ?>
        
        <?php if (empty($students)): ?>
        <div class="no-fees">
            <i class="fas fa-check-circle"></i>
            <h3>No Unpaid Fees Found</h3>
            <p>All fees for this parent are paid up to date.</p>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Payment Modal (will be loaded via AJAX) -->
<div class="modal fade" id="paymentModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <!-- Content loaded dynamically -->
        </div>
    </div>
</div>

<!-- Discount Modal -->
<div class="modal fade" id="discountModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Apply Discount</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="discountForm">
                    <div class="form-group">
                        <label>Discount Type</label>
                        <select class="form-control" name="discount_type">
                            <option value="percentage">Percentage</option>
                            <option value="fixed">Fixed Amount</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Discount Value</label>
                        <input type="number" class="form-control" name="discount_value" required>
                    </div>
                    <div class="form-group">
                        <label>Reason</label>
                        <textarea class="form-control" name="discount_reason" required></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="applyDiscount()">Apply</button>
            </div>
        </div>
    </div>
</div>

<style>
.fee-management-system {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: #333;
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.parent-summary {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.parent-info h2 {
    margin: 0 0 10px 0;
    color: #2c3e50;
}

.parent-contact {
    display: flex;
    gap: 15px;
    color: #7f8c8d;
}

.parent-contact i {
    margin-right: 5px;
}

.summary-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.summary-card {
    background: white;
    border-radius: 8px;
    padding: 15px;
    display: flex;
    align-items: center;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.summary-card.total-unpaid {
    border-left: 4px solid #e74c3c;
}

.summary-card.balance {
    border-left: 4px solid #3498db;
}

.summary-card.students-count {
    border-left: 4px solid #2ecc71;
}

.card-icon {
    font-size: 24px;
    margin-right: 15px;
    color: #7f8c8d;
}

.card-content h4 {
    margin: 0 0 5px 0;
    font-size: 14px;
    color: #7f8c8d;
}

.card-content p {
    margin: 0;
    font-size: 20px;
    font-weight: bold;
}

.action-buttons {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}

.action-buttons .btn {
    display: flex;
    align-items: center;
    gap: 8px;
}

.student-section {
    background: white;
    border-radius: 8px;
    margin-bottom: 20px;
    overflow: hidden;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.student-header {
    display: flex;
    align-items: center;
    padding: 15px 20px;
    background: #f8f9fa;
    border-bottom: 1px solid #eee;
}

.student-photo {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    overflow: hidden;
    margin-right: 15px;
}

.student-photo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.student-info {
    flex: 1;
}

.student-info h3 {
    margin: 0 0 5px 0;
    font-size: 18px;
}

.student-meta {
    display: flex;
    gap: 8px;
}

.badge {
    padding: 3px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
}

.class-badge {
    background: #e3f2fd;
    color: #1976d2;
}

.section-badge {
    background: #e8f5e9;
    color: #388e3c;
}

.unpaid-badge {
    background: #ffebee;
    color: #d32f2f;
}

.student-total {
    text-align: right;
}

.student-total span {
    display: block;
    font-size: 12px;
    color: #7f8c8d;
}

.student-total strong {
    font-size: 18px;
    color: #e74c3c;
}

.fees-table-container {
    overflow-x: auto;
}

.fees-table {
    width: 100%;
    border-collapse: collapse;
}

.fees-table th {
    background: #f5f5f5;
    padding: 12px 15px;
    text-align: left;
    font-size: 13px;
    color: #7f8c8d;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.fees-table td {
    padding: 12px 15px;
    border-bottom: 1px solid #eee;
}

.fees-table tr:last-child td {
    border-bottom: none;
}

.fees-table .actions {
    display: flex;
    gap: 8px;
}

.btn-pay, .btn-challan {
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 12px;
    display: flex;
    align-items: center;
    gap: 5px;
    text-decoration: none;
}

.btn-pay {
    background: #2ecc71;
    color: white;
    border: none;
    cursor: pointer;
}

.btn-pay:hover {
    background: #27ae60;
}

.btn-challan {
    background: #3498db;
    color: white;
}

.btn-challan:hover {
    background: #2980b9;
}

.no-fees {
    text-align: center;
    padding: 40px;
    color: #7f8c8d;
}

.no-fees i {
    font-size: 50px;
    color: #2ecc71;
    margin-bottom: 15px;
}

.no-fees h3 {
    margin: 0 0 10px 0;
}

@media (max-width: 768px) {
    .student-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .student-total {
        text-align: left;
        margin-top: 10px;
    }
    
    .fees-table .actions {
        flex-direction: column;
        gap: 5px;
    }
    
    .action-buttons {
        flex-direction: column;
    }
}
</style>

<script>
function showPaymentModal(btn) {
    const feeId = btn.dataset.feeid;
    const amount = btn.dataset.amount;
    
    $('#paymentModal').load(`<?= site_url('admin/fee/payment_form/') ?>${feeId}?amount=${amount}`, function() {
        $(this).modal('show');
    });
}

function payAll() {
    if (confirm('Are you sure you want to pay all outstanding fees for all students?')) {
        fetch(`<?= site_url('admin/fee/pay_all/') ?><?= $parent_id ?>`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('All fees paid successfully!');
                location.reload();
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while processing payment');
        });
    }
}

function applyDiscount() {
    const formData = new FormData(document.getElementById('discountForm'));
    
    fetch(`<?= site_url('admin/fee/apply_discount/') ?><?= $parent_id ?>`, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Discount applied successfully!');
            location.reload();
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while applying discount');
    });
}

function sendReminders() {
    if (confirm('Send payment reminders to this parent?')) {
        fetch(`<?= site_url('admin/fee/send_reminders/') ?><?= $parent_id ?>`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Reminders sent successfully!');
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while sending reminders');
        });
    }
}
</script>