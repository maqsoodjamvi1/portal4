<style>
@media print {
    .no-print {
        display: none !important;
    }
}
</style>

<section class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-primary card-outline card-tabs">
                <div class="card-header">
                    <h3 class="card-title">Top Level Planning (<?= $session_name ?>)</h3>
                </div>
                <div class="card-body">
                    <!-- Filters -->
                    <div class="row">
                        <div class="col-lg-12 no-print">
                            <!-- Terms -->
                            <div class="form-group">
                                <label>Terms:</label>
                                <div class="mb-2">
                                    <button type="button" class="btn btn-sm btn-link" onclick="toggleCheckboxes('term', true)">Select All</button>
                                    <button type="button" class="btn btn-sm btn-link" onclick="toggleCheckboxes('term', false)">Deselect All</button>
                                </div>
                                <div class="row">
                                    <?php foreach($filter_data['all_terms'] as $term): ?>
                                        <div class="col-md-3">
                                            <div class="form-check">
                                                <input class="form-check-input term-checkbox" type="checkbox" 
                                                       name="terms[]" value="<?= $term['term_session_id'] ?>" 
                                                       <?= in_array($term['term_session_id'], $selected_filters['terms']) ? 'checked' : '' ?>>
                                                <label class="form-check-label"><?= $term['term_name'] ?></label>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <!-- Classes -->
                            <div class="form-group mt-4">
                                <label>Classes:</label>
                                <div class="mb-2">
                                    <button type="button" class="btn btn-sm btn-link" onclick="toggleCheckboxes('class', true)">Select All</button>
                                    <button type="button" class="btn btn-sm btn-link" onclick="toggleCheckboxes('class', false)">Deselect All</button>
                                </div>
                                <div class="row">
                                    <?php foreach($filter_data['all_classes'] as $class): ?>
                                        <div class="col-md-3">
                                            <div class="form-check">
                                                <input class="form-check-input class-checkbox" type="checkbox" 
                                                       name="classes[]" value="<?= $class['class_id'] ?>" 
                                                       <?= in_array($class['class_id'], $selected_filters['classes']) ? 'checked' : '' ?>>
                                                <label class="form-check-label"><?= $class['class_name'] ?></label>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <!-- Subjects -->
                            <div class="form-group mt-4">
                                <label>Subjects:</label>
                                <div class="mb-2">
                                    <button type="button" class="btn btn-sm btn-link" onclick="toggleCheckboxes('subject', true)">Select All</button>
                                    <button type="button" class="btn btn-sm btn-link" onclick="toggleCheckboxes('subject', false)">Deselect All</button>
                                </div>
                                <div class="row">
                                    <?php foreach($filter_data['all_subjects'] as $subject): ?>
                                        <div class="col-md-3">
                                            <div class="form-check">
                                                <input class="form-check-input subject-checkbox" type="checkbox" 
                                                       name="subjects[]" value="<?= $subject['sid'] ?>" 
                                                       <?= in_array($subject['sid'], $selected_filters['subjects']) ? 'checked' : '' ?>>
                                                <label class="form-check-label"><?= $subject['subject_name'] ?></label>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <!-- Buttons -->
                            <div class="card-footer">
                                <button type="button" id="filterForm" class="btn btn-primary">Apply Filters</button>
                                <button type="button" class="btn btn-default" onclick="resetFilters()">Reset</button>
                            </div>
                        </div>
                    </div>

                    <!-- Results -->
                    <div id="tplhtmlresult">
                        <?php $this->load->view('top_level_planning_gradewise_result_view'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- JavaScript -->
<script>
function resetFilters() {
    document.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = true);
    $('#filterForm').click();
}

function toggleCheckboxes(type, check) {
    document.querySelectorAll(`.${type}-checkbox`).forEach(cb => cb.checked = check);
}

$(document).ready(function() {
    $('#filterForm').on('click', function() {
        $('#tplhtmlresult').html('<div class="text-center py-4"><i class="fas fa-spinner fa-spin"></i> Loading...</div>');

        let terms = [];
        $('input[name="terms[]"]:checked').each(function() { terms.push($(this).val()); });
        let classes = [];
        $('input[name="classes[]"]:checked').each(function() { classes.push($(this).val()); });
        let subjects = [];
        $('input[name="subjects[]"]:checked').each(function() { subjects.push($(this).val()); });

        $.ajax({
            '<?= site_url("Top_level_planning_gradewise") ?>', // Changed from admin.php?c=...
                method: 'POST',
            data: {
                terms: terms,
                classes: classes,
                subjects: subjects,
                is_ajax: 1
            },
            success: function(response) {
                $('#tplhtmlresult').html(response);
            },
            error: function(xhr) {
                $('#tplhtmlresult').html('<div class="alert alert-danger">Error loading data.</div>');
            }
        });
    });
});
</script>
