<?php
	// if(isset($_GET['id'])){
	// 	$header = 'Edit System';
	// }else{
	// 	echo "<div class='mt-5 ml-5 alert-danger'>No Record Found </div>";
	// 	exit;
	// }
?>

<!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          <h1>
         Reports
          </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Reports</li>
            </ol> 
            </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- /.col -->
        <div class="col-md-12">
          <div class="card">  
        	<div class="card-body">
            <div class="tab-content">
              <div class="active tab-pane" id="settings">
              <h1 class="col-sm-6">Fee Reports</h1>
              <a href="<?php echo '#/report'; ?>" class="btn btn-app col-sm-2">
                <i class="far fa-money-bill-alt"></i> All Reports
              </a>
              <a href="<?php echo '#/student_fee_report'; ?>" class="btn btn-app col-sm-2">
                <i class="far fa-money-bill-alt"></i> Class Fee Report
              </a>
              <a href="<?php echo '#/student_fee_report?m=report_by_fee_student'; ?>" class="btn btn-app col-sm-2">
                <i class="far fa-money-bill-alt"></i> Student Fee Report
              </a>
               <a href="<?php echo '#/family_fee_report'; ?>" class="btn btn-app col-sm-2">
                <i class="far fa-money-bill-alt"></i> Family Fee Report
              </a>
              <a  href="<?php echo '#/student_fee_report?m=report_by_fee_type'; ?>" class="btn btn-app col-sm-2">
                <i class="far fa-money-bill-alt"></i>  Report By Fee Types
              </a>
              <h1 class="col-sm-6">Exam Reports</h1>
              <a href="<?php echo '#/classwise_results'; ?>" class="btn btn-app col-sm-2">
                <i class="fas fa-chalkboard"></i> Class Result
              </a>
              <a href="<?php echo '#/students_results_list'; ?>" class="btn btn-app col-sm-2">
                <i class="fas fa-chalkboard"></i> Term Result
              </a>
              <a href="<?php echo '#/student_fee_report?m=report_by_fee_student'; ?>" class="btn btn-app col-sm-2">
                <i class="fas fa-chalkboard"></i> Student Result
              </a>
              <h1 class="col-sm-6">Attendance Reports</h1>
              <a href="<?php echo '#/attendance_monthlyreport'; ?>" class="btn btn-app col-sm-2">  <i class="nav-icon far fa-clock"></i> 
               Monthly Report
              </a>
                  
  						</div>
				  		<!-- /.tab-pane -->
				  	</div>
					</div>
    <!-- /.tab-content -->
  </div>
  <!-- /.nav-tabs-custom -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->
</section>