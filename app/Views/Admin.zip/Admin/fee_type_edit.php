<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>

<?php
	{
		$header = 'Add Fee Type';
		$id = '';
		$fee_type_name = '';
		$fee_type_detail = '';
	}
?>
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
               Fee Type
          		<?php 
            	$schoolinfo = getSchoolInfo();
            	$this->db->where('system_id', $schoolinfo->system_id);
				$fee_type_info = $this->db->get('fee_type')->row();
			
				if(empty($fee_type_info->fee_type_id)){ ?>
					<span style='background: green;color: #fff !important;float: right;padding: 5px 10px;margin-top: 0px;font-size: 16px;'>Step 9 Of 10 To Complete System Configuration</span>
    				<audio autoplay  controls>
					 <source src="audio/Step11FeeTypes.m4a" type="audio/ogg">
					  <source src="audio/Step11FeeTypes.m4a" type="audio/mpeg">
					Your browser does not support the audio element.
					</audio>		
				<?php } ?>
            </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Fee Type</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
		  <div class="card card-primary card-outline card-tabs">
          <div class="card-header p-0 pt-1 border-bottom-0">
			<ul class="nav nav-tabs">
				<li class="nav-item"><a class="nav-link" href="<?php echo '#/fee_type';?>">Fee Type</a></li>
				<?php if($id == ''){ ?>
					<li class="nav-item"><a class="nav-link active" href="<?php echo '#/fee_type?m=add';?>"><?php echo $header;?></a></li>
				<?php }else{ ?>
					<li class="nav-item"><a class="nav-link active" href="<?php echo '#/fee_type?m=edit&id=' . $id;?>"><?php echo $header;?></a></li>
				<?php } ?>
			</ul>
			<div class="card-body">
			<div class="tab-content">
			<?php
			echo form_open('c=fee_type&m=save', 'role="form" id="user-edit-form"');
			echo form_hidden('id', $id);
			?>
			<div class="col-lg-12">
            <div class="form-group">
              <select class="form-control" required name="module_fee" id="module_fee" >
              <option value="">Select Fee</option>
                <option selected value="s_flag">School Fee</option>
                <option value="t_flag">Transport Fee</option>
                <option value="h_flag">Hostel Fee</option>
                <option value="a_flag">Academy Fee</option>
              </select>
            </div>
          </div>
			<div class="col-lg-12">
				<div id="feeTypeForm"></div> 
			</div>
			<div class="col-lg-12">	
	        <div class="form-group">
				<button type="submit" id="submitBtn" class="btn btn-primary mr-2">Save</button>
				<!-- <button type="reset" class="btn btn-default mr-2">Reset</button> -->
				<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
			</div>
			</div>
		<?php echo form_close();?>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- /.content -->
<script type="text/javascript">
$(document).ready(function () {
 $("#module_fee").change(function(){
    var module_fee = $('#module_fee').val();
	  $.ajax({
        url: 'admin.php?c=fee_type&m=data2',
        type: "POST",
        data:{module_fee:module_fee },
        success:function(res){
          $("#feeTypeForm").html(res);
        }
    });
});
$('#module_fee').trigger("change");
});
</script>
<script type="text/javascript">
$(function(){
	$('#user-edit-form').validate({
		rules:{
			fee_type_name:{
				required:true,
			},
			is_monthly_fee:{
				required:true,
			}
		},
		messages:{ 
			fee_type_name:{
				required:'fee type name is Required',
				},
			is_monthly_fee:{
				required:'Is monthy fee field is Required',
				}	
		}
	});
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			return $('#user-edit-form').valid();
			$('#submitBtn').html("Saving!");
      		$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
			var json = $.parseJSON(responseText);
			if(json.amount_id == false){
	        	window.location.href = '<?php echo base_url() . $this->config->item('index_page');?>#/fee_amount?m=add';
	        	return;
	      	}
			if(json.success){
				toastr.success(json.msg);
			<?php
				if($id == ''){
					?>
				location.href = '#/fee_type';
			<?php
				}else{
			?>
			location.href = '#/fee_type?m=edit&id=<?php echo $id;?>&after=edit';
			<?php } ?>

			}else{

				toastr.error(json.msg);

			}

			return false;

		}

	});

});

</script>
<?= $this->endSection() ?>

