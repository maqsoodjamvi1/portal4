<?php
if(isset($info)){
	$header = 'Edit Student Class';
	$id = $info->sc_id;
	$student_id = $info->student_id;
	$class_id = $info->class_id;
	$session_id = $info->session_id;
	$section_id = $info->section_id;
	$status = intval($info->status);
}else{
	$header = 'Add Student Class';
	$id = 0;
	$student_id = '';
	$class_id = '';
  $session_id = '';
  $section_id = '';
	$status = '';
}
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
           Students Class
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Students Class</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
        <div class="card-header p-0 pt-1 border-bottom-0">
        <ul class="nav nav-tabs">
          <li class="nav-item"><a class="nav-link" href="<?php echo '#/student_class';?>">Student Class</a></li>
          <?php if($id == ''){ ?>
          <li class="nav-item"><a class="nav-link active" href="<?php echo '#/student_class?m=add';?>"><?php echo $header;?></a></li>
          <?php }else{ ?>
          <li class="nav-item"><a class="nav-link active" href="<?php echo '#/student_class?m=edit&id=' . $id;?>"><?php echo $header;?></a></li>
          <?php } ?>
        </ul>
      <div class="card-body">    
      <div class="tab-content">
      <?php
			echo form_open('c=student_class&m=save', 'role="form" id="user-edit-form"');
			echo form_hidden('id', $id);
			?>
      <div class="row">
        <div class="col-sm-3 col-xs-12">         
			  <div class="form-group">
         	  <div>Running Session<span class="required">*</span></div>
            <select class="form-control" name="session_id" id="session_id">
            <?php if(isset($academic_sessioninfo)){
						foreach ($academic_sessioninfo as  $academic_sessionvalue) { ?>
              <option <?php if($academic_sessionvalue->session_id == $session_id) { ?> selected <?php } ?> value="<?php echo $academic_sessionvalue->session_id?>"><?php echo $academic_sessionvalue->session_name?></option>
              <?php } ?>
              <?php	} ?>
            </select>
          </div>
		  </div>
          <div class="col-lg-3">
           <div class="item form-group">
             <div>Promote to Session <span class="required">*</span></div>
			     <select class="form-control" name="next_session_id" id="next_session_id" required="required">
                <?php if(isset($academic_sessioninfo)){
						foreach ($academic_sessioninfo as  $academic_sessionvalue) { ?>
              <option <?php if($academic_sessionvalue->session_id == $session_id) { ?> selected <?php } ?> value="<?php echo $academic_sessionvalue->session_id?>"><?php echo $academic_sessionvalue->session_name?></option>
              <?php } ?>
              <?php	} ?>
              </select>
            <div class="help-block"></div>
            </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group pull-left">
                <div>Current Class <span class="required">*</span></div>
                <select class="form-control select2"  name="current_class_id" id="current_class_id" required="required">
                   <option value="0">Select Section</option>
                  <?php if(isset($sectionsclassinfo)){
              foreach ($sectionsclassinfo as  $secionvalue) { ?>
                  <option value="<?php echo $secionvalue['section_id']; ?>"><?php echo $secionvalue['sectionclassname']; ?></option>
                  <?php } ?>
                  <?php } ?>
                </select>
              </div> 
            </div>
            <div class="col-sm-2">
                <div class="form-group pull-left">
                <div>Promote To Class <span class="required">*</span></div>
                <select class="form-control select2" name="next_class_id" id="next_class_id" required="required">
                   <option value="">Select Section</option>
                  <?php if(isset($sectionsclassinfo)){
              foreach ($sectionsclassinfo as  $secionvalue) { ?>
                  <option value="<?php echo $secionvalue['section_id']; ?>"><?php echo $secionvalue['sectionclassname']; ?></option>
                  <?php } ?>
                  <?php } ?>
                </select>
              </div>
            </div> 
            <div class="col-lg-2">
              <div class="form-group">
              <button type="button" onclick="getstudentscurrentclass();" class="btn btn-success btn-flat" style="margin-top: 19px;height: 30px;line-height: 10px;">Find</button>   
              </div>
            </div>
          </div>
           <div id="students_list_container"></div>
          <div class="form-group">
            <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
            <button type="reset" class="btn btn-default">Reset</button>
            <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
          </div>
          <?php echo form_close();?> </div>
      </div>
    </div>
  </div>
</div>
</div>
</section>
<script>
function getstudentscurrentclass() {
		var session_id = $('#session_id').val();
		var next_session_id = $('#next_session_id').val();		
		var current_class_id = $('#current_class_id').val();
		var next_class_id = $('#next_class_id').val();
 	      $.ajax({
            url: 'admin.php?c=student_class&m=getStdCurrentClass',
            type: "POST",
            data:{session_id:session_id,current_class_id: current_class_id,next_session_id:next_session_id,next_class_id:next_class_id},
            success:function(res){
 			   $("#students_list_container").html(res);	
 			   }
         });
 }
</script>
<script type="text/javascript">
$(function(){
	$('#user-edit-form').validate({});
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			return $('#user-edit-form').valid();
      $('#submitBtn').html("Saving");
      $('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
      $('#submitBtn').html("Save");
      $('#submitBtn').prop('disabled', false);
			var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
				<?php if($id == ''){ ?>
					location.href = '#/student_class?m=add';
				<?php }else{ ?>
					location.href = '#/student_class?m=edit&id=<?php echo $id;?>&after=edit';
				<?php } ?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
});
</script>
