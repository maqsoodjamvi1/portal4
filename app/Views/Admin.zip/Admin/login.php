<?php 
    $username = '';
    $password = '';
    if(isset($_GET['username'])){ 
      $username = $_GET['username'];
    }

    if(isset($_GET['pass'])){ 
      $password = $_GET['pass'];
    }
  ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>School | Login</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo base_url();?>resource/adminlte/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>resource/adminlte/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>resource/adminlte/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>resource/adminlte/plugins/toastr/toastr.min.css">
  <style type="text/css">
    .login-box, .register-box{margin: 0 auto;}
    .signupbtnsection{width: 350px; margin: 0 auto;}
    .btn-group-lg>.btn, .btn-lg{margin-bottom: 5px;}
  </style>
  <script src='https://www.google.com/recaptcha/api.js'></script>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <style type="text/css">
    .form-control{
      height: 30px !important;
    }
  </style>
</head>
<body class="hold-transition login-page">
<div class="container">
<?php  //form_open('/admin/login', ['id' => 'loginform']) ?>
<?= form_open('/admin/login/submit', ['id' => 'loginform']) ?>
   
<div <?php if($_SERVER['HTTP_HOST'] == 'demo.timesoftsol.com'){ ?> style="display: none;" <?php } ?> class="login-box" <?php if($_SERVER['HTTP_HOST'] == 'demo.timesoftsol.com'){ ?>  style="margin: 3% auto;" <?php } ?> >
  <div class="card card-outline card-primary">
  <div class="card-header text-center">
      <a href="<?php echo site_url('');?>" class="h1">TLive Education <?php if($_SERVER['HTTP_HOST'] == 'trial.timesoftsol.com'){ ?> Trial <?php } ?> <?php if($_SERVER['HTTP_HOST'] == 'demo.timesoftsol.com'){ ?> Demo <?php } ?></a>
  </div>  
  <!-- /.login-logo -->
  <div class="card-body">
  <div> 
    <p class="login-box-msg">Sign in</p>
      <div class="input-group mb-3">
        <input type="text" class="form-control" required name="username" id="username" placeholder="Email/Username" value="<?php echo $username; ?>">
        <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
		    <div class="text-danger col-12" id="usernameerror"></div>
      </div>
      <div class="input-group mb-3">
        <input type="password" class="form-control" required name="password" id="password" placeholder="Password" value="<?php echo $password; ?>">
       <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
		    <div class="text-danger col-12" id="passworderror"></div>
      </div>
      <div class="row">
        <div class="col-8"></div>
        <!-- /.col -->
        <div class="col-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat signin">Sign in</button>
        </div>
        <!-- /.col -->
      </div>
    </div>
    <!-- /.social-auth-links -->
    <?php if($_SERVER['HTTP_HOST'] != 'demo.timesoftsol.com'){ ?>
      <a href="<?php echo site_url('c=login&m=findpassword');?>">Forget Password?</a>
    <?php } ?>
  </div>
  <!-- /.login-box-body -->
</div>
</div>
<!-- /.login-box -->
<?php if($_SERVER['HTTP_HOST'] == 'demo.timesoftsol.com'){ ?>
  <section>
    <h1 class="text-center">TLive Education Demo</h1>
    <h2 class="text-center">Just Enter Contact Information And Click On Any Role Button</h2>
    <h3 class="text-center">No need of username and password</h3>
    <br>
    <div class="row">
      <div class="col-lg-7" style="margin: 0 auto;">
      <div class="row">
      <div class="col-lg-6  input-group mb-3">
        <input type="text" required="" class="form-control" required name="name" id="name" placeholder="Contact Name">
        <div class="text-danger col-12" id="nameerror"></div>
      </div>
      <div class="col-lg-6 input-group mb-3">
        <input type="text" required="" class="form-control" required name="phone" id="phone" placeholder="Contact Phone">
        <div class="text-danger col-12" id="phoneerror"></div>
      </div>
      </div>
          <!-- <h3 style="text-align: center;">Click on Roles-Button to auto login</h3> --><br>
            <div class="" role="group" aria-label="School-1">
                <!-- <div class=" btn-lg btn-info demo-button" style="float: left;background: black;">Premium Package: </div> -->
                <button class="btn btn-lg btn-info demo-button" id="system-admin">System Director</button>
                 <button class="btn btn-lg btn-danger demo-button" id="campus-director">Campus Director</button>
                <button class="btn btn-lg btn-primary demo-button" id="director-academic">Director Academic</button>
                <button class="btn btn-lg btn-success demo-button" id="director-finance">Director Finance</button>
                <button class="btn btn-lg btn-warning demo-button" id="principal">Principal</button>
                <button class="btn btn-lg btn-info demo-button" id="teacher">Teacher</button>
            </div>
          </div>
          </div>
        </section><br>
        <br><br><br>
        
	<?php } ?>
  <?php if($_SERVER['HTTP_HOST'] != 'portal.timesoftsol.com'){ ?>
    <br><br>
   <!-- <section class="signupbtnsection">
      <center>
        <h3>Create School With Blank Database</h3><br>
        <a href="https://timesoftsol.com/signup/" class="btn btn-lg btn-danger btn-block">Signup For 1 Month Free Trial</a>
      </center>
    </section> -->
  <?php } ?>
   <?php echo form_close();?>
   </div>
<!-- jQuery 2.1.4 -->
<script src="<?php echo base_url();?>resource/adminlte/plugins/jquery/jquery.min.js"></script>
<script src="<?php echo base_url();?>resource/adminlte/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>resource/js/jquery.form.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo base_url();?>resource/toastr/toastr.min.js"></script>
<script src="<?php echo base_url();?>resource/js/jquery.validate.min.js" type="text/javascript"></script>

<?php if(isset($_GET['username']) && isset($_GET['pass'])){ ?>
<script type="text/javascript">
   $( document ).ready(function() {
      $(".signin").click();
  });
</script>
<?php } ?>

<script type="text/javascript">

        $('#system-admin').click(function () {
            $("input[name=username]").val('system-admin');
            $("input[name=password]").val('123456');
            $( ".signin" ).click();
        });
        $('#campus-director').click(function () {
            $("input[name=username]").val('campus-director');
            $("input[name=password]").val('123456');
            $( ".signin" ).click();
        });
        $('#director-academic').click(function () {
            $("input[name=username]").val('director-academic');
            $("input[name=password]").val('123456');
            $( ".signin" ).click();
        });
        $('#director-finance').click(function () {
            $("input[name=username]").val('director-finance');
            $("input[name=password]").val('123456');
            $( ".signin" ).click();
        });
        $('#principal').click(function () {
            $("input[name=username]").val('principal');
            $("input[name=password]").val('123456');
            $( ".signin" ).click();
        });
        $('#teacher').click(function () {
            $("input[name=username]").val('teacher');
            $("input[name=password]").val('123456');
            $( ".signin" ).click();
        });
    
</script>
<script>
  $(function () {
	$.validator.setDefaults({
		ignore : "",
		errorPlacement : function (error, element) {
			if ($(document).find('#' + element.attr('id') + 'error')) {
				error.appendTo($('#' + element.attr('id') + 'error'));
			}
		},
		highlight : function (element) {
			$(element).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		unhighlight : function (element) {
			$(element).closest('.form-group').removeClass('has-error');
		}
	});
	$('#loginform').validate({
		rules:{
			username:{
				required:true
			},
			password:{
				required:true
			},
      name:{
        required:true
      },
      phone:{
        required:true
      }
		},
		messages:{
			username:{
				required:'Please Enter Username or Email'
			},
			password:{
				required:'Please Enter Password'
			},
			name:{
				required:'Pleace Enter Name'
			},
      phone:{
        required:'Pleace Enter Phone'
      }
		}

	});
	$('#loginform').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			return $('#loginform').valid();
		},
		success:function(responseText, statusText, xhr, form){

      window.location.href = '<?php echo base_url();?>/admin/dashboard';
			var json = $.parseJSON(responseText);
      console.log(json);

		  if(json.reg_text == false){
        window.location.href = '<?php echo base_url();?>#/profile_system';
        return;
      }
			if(json.session_id == false){ 
				window.location.href = '<?php echo base_url();?>#/academic_session?m=add';
				return;
			}

      if(json.term_id == false){
        window.location.href = '<?php echo base_url();?>#/terms?m=add';
        return;
      }
			if(json.success){
				window.location.href = '<?php echo base_url();?>/admin/dashboard';
			}else{
				//toastr.error(json.msg);
			}
			return false;
		}
	});
  });
</script>
</body>
</html>
