<?php
	{
	$header = 'Add Students';
    $id = '';
    $date1 = '';
    $class_id = '';
    $subject_id = '';
    $cat_id = '';
    $detail = '';
    $topic_id = '';
	}
  $cls_sec_id = ''; 
  if(!empty($_GET['cls_sec_id'])){
   $cls_sec_id = $_GET['cls_sec_id']; 
  }
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
           Student Names
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Student Names</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
        <div class="card-header p-0 pt-1 border-bottom-0">
        <ul class="nav nav-tabs">   
        <li class="nav-item"><a class="nav-link active" href="<?php echo '#/addbulkstudents?m=add';?>"> Student Names</a></li> 
         <li class="nav-item"><a class="nav-link" href="<?php echo '#/students_enroll';?>"> Enroll Students</a>
        <li class="nav-item"><a href="<?php echo '#/students_bulk_cnic';?>" class="nav-link">Father Names</a></li>        
        <li class="nav-item"><a class="nav-link" href="<?php echo '#/studentsbulk';?>">Fee Detail</a></li>
        <?php if($campus_info->a_flag == 1){ ?>
        <li class="nav-item"><a class="nav-link"  href="#/students_bulk_academy_fee">Academy Fee Detail</a></li>
        <?php } ?>
        <?php if($campus_info->h_flag == 1){ ?>
        <li class="nav-item"><a class="nav-link"  href="#/h_student_beds?m=add">Student Bed</a></li>
        <?php } ?>
        <?php if($campus_info->t_flag == 1){ ?>
        <li class="nav-item"><a class="nav-link"  href="#/students_vehicle">Students Vehicle</a></li>
        <?php } ?>
        <li class="nav-item"><a class="nav-link" href="<?php echo '#/students_bulk_contacts';?>"> Contact Numbers</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo '#/students_bulk_info';?>"> Other Student Info</a>
        </li>
        <li class="nav-item"><a class="nav-link"  href="#/students?m=addbulk">Entries through Excel</a></li>
      </ul>    
    <div class="card-body">
    <?php
        echo form_open_multipart('c=addbulkstudents&m=save', 'role="form" id="user-edit-form"');
		    echo form_hidden('id', $id);
		?>
		<div class="row"> 
	        <div class="col-lg-2">
            <div class="form-group">
              <label for="cls_sec_id">Section <span class="text-danger">*</span></label>
              <select class="form-control" required name="cls_sec_id" id="cls_sec_id" >
                <option value="">Select Section</option>
              <?php if(isset($sectionsclassinfo)){
                foreach ($sectionsclassinfo as  $sectionvalue) { ?>
                <option <?php if ($cls_sec_id == $sectionvalue['section_id']): ?>
                  selected
                <?php endif ?>  value="<?php echo $sectionvalue['section_id']; ?>"><?php echo $sectionvalue['sectionclassname']; ?></option>
                <?php } ?>
                <?php } ?>
              </select>
            </div>
          </div>
		    <div class="col-lg-2">
		    
		   </div>
		    <div class="col-lg-2">
		        
		   </div>
      </div>
		  <div class="row">
		  <div class="col-lg-12">
		  <div id="studentsList">
		  
	    </div>
		 <div class="row">
		 <div class="col-lg-12">
		 <div class="col-lg-3">
         <div class="form-group">
           <button type="submit" class="btn btn-primary">Save</button>
           <button type="reset" class="btn btn-default">Reset</button>
           <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
         </div>
		 </div>
		 </div>
		 </div>
         <?php echo form_close();?> </div>
      </div>
    </div>
  </div>
</section>
<!-- /.content -->
<?php if(!empty($cls_sec_id)){ ?>
  <script type="text/javascript">
$(document).ready(function () {
 
    var cls_sec_id = <?php echo $cls_sec_id; ?>;
    $.ajax({
        url: 'admin.php?c=addbulkstudents&m=selectStudentBySection',
        type: "POST",
        data:{cls_sec_id:cls_sec_id },
        success:function(res){
          $("#studentsList").html(res);
        }
    });

});
</script>
<?php } ?>
<script type="text/javascript">
$(document).ready(function () {
 $("#cls_sec_id").change(function(){
    var cls_sec_id = $('#cls_sec_id').val();
	  $.ajax({
        url: 'admin.php?c=addbulkstudents&m=selectStudentBySection',
        type: "POST",
        data:{cls_sec_id:cls_sec_id },
        success:function(res){
          $("#studentsList").html(res);
        }
    });
});

});
</script>

<script type="text/javascript">
$(function(){
  $(".select2").select2({closeOnSelect:false});
	$('#user-edit-form').validate({  
  });

$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
		},
		success:function(responseText, statusText, xhr, form){
			var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
				var cls_sec_id = $('#cls_sec_id').val();
        $.ajax({
            url: 'admin.php?c=addbulkstudents&m=selectStudentBySection',
            type: "POST",
            data:{cls_sec_id:cls_sec_id },
            success:function(res){
              $("#studentsList").html(res);
            }
        });
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
});
</script>