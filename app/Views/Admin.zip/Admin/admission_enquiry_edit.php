<?php
	if(isset($info)){

		$header = 'Edit Admission Enquiry';
		$id = $info->enquiry_id;
		$student_name = $info->student_name;
		$father_name = $info->father_name;
		$student_age = $info->student_age;
		$father_phone = $info->father_phone;
		$mother_phone = $info->mother_phone;
		$previous_school = $info->previous_school;
		$previous_fee = $info->previous_fee;
		$address = $info->address;
		$description = $info->description;
		$date = $info->date;

	}else{
		$header = 'Add Admission Enquiry';
		$id = '';
		$student_name = '';
		$father_name = '';
		$student_age = '';
		$father_phone = '';
		$mother_phone = '';
		$previous_school = '';
		$previous_fee = '';
		$address = '';
		$description = '';
		$date = '';
	}
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>
          Admission Enquiry
        </h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Admission Enquiry</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-lg-12">
  <div class="card card-primary card-outline card-tabs">
    <div class="card-header p-0 pt-1 border-bottom-0">
	<ul class="nav nav-tabs">
		<li class="nav-item"><a class="nav-link" href="<?php echo '#/admission_enquiry';?>">Admission Enquiry</a></li>
		<?php if($id == ''){ ?>
		<li class="nav-item"><a class="nav-link active" href="<?php echo '#/admission_enquiry?m=add';?>"><?php echo $header;?></a></li>
		<?php }else{ ?>
		<li class="nav-item"><a class="nav-link active" href="<?php echo '#/admission_enquiry?m=edit&id=' . $id;?>"><?php echo $header;?></a></li>
		<?php } ?>
	</ul>
	<div class="card-body">
	<div class="tab-content">
	<?php
		echo form_open('c=admission_enquiry&m=save', 'role="form" id="user-edit-form"');
		echo form_hidden('id', $id);
	?>
	<div class="row">	
			<div class="col-sm-6">	
		   <div class="form-group">
          <label for="student_name">Student Name</label>
          <input type="text" class="form-control" name="student_name" id="student_name" value="<?php echo $student_name;?>">
			</div>
			</div>
			<div class="col-sm-6">	
		   <div class="form-group">
          <label for="father_name">Father Name</label>
          <input type="text" class="form-control" name="father_name" id="father_name" value="<?php echo $father_name;?>">
			</div>
			</div>
			<div class="col-sm-6">	
		   <div class="form-group">
          <label for="student_age">Age of Student</label>
          <input type="text" class="form-control" name="student_age" id="student_age" value="<?php echo $student_age;?>">
			</div>
			</div>
			<div class="col-sm-6">
			 <div class="form-group">
          <label for="father_phone">Father Phone Number</label>
          <input type="text" class="form-control" name="father_phone" id="father_phone" value="<?php echo $father_phone;?>">
			</div>
			</div>
			<div class="col-sm-6">
			 <div class="form-group">
          <label for="mother_phone">Mother Phone Number</label>
          <input type="text" class="form-control" name="mother_phone" id="mother_phone" value="<?php echo $mother_phone;?>">
			</div>
			</div>
			<div class="col-sm-6">
			 <div class="form-group">
          <label for="previous_school">Previous School</label>
          <input type="text" class="form-control" name="previous_school" id="previous_school" value="<?php echo $previous_school;?>">
			</div>
			</div>
			<div class="col-sm-6">
			 <div class="form-group">
          <label for="previous_fee">Previous Fee</label>
          <input type="text" class="form-control" name="previous_fee" id="previous_fee" value="<?php echo $previous_fee;?>">
			</div>
			</div>
			<div class="col-sm-6">
			 <div class="form-group">
          <label for="address">Address</label>
          <input type="address" class="form-control" name="address" id="address" value="<?php echo $address;?>">
			</div>
			</div>
			<div class="col-sm-6">
					<div class="form-group">
              <label>Date</label>
		  		<div class="input-group date" id="datepicker" data-target-input="nearest">
          <input type="text" class="form-control datetimepicker-input" data-target="#datepicker"  name="date" required value="<?php  echo $date; ?>"/>
          <div class="input-group-append" data-target="#datepicker" data-toggle="datetimepicker">
              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
          </div>
        </div>
      	</div>
   		</div>
			<div class="col-sm-12">
					<div class="form-group">
              <label for="description">Description</label>
              <textarea class="form-control" name="description" id="description" ><?php echo $description; ?></textarea>
					</div>
			</div>

			        
    <div class="form-group">
      <button type="submit" id="submitBtn" class="btn btn-primary">Save</button>
			<button type="reset" class="btn btn-default">Reset</button>
			<button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
    </div>
    <?php echo form_close();?> 
		</div>
		</div>
    </div>
    </div>
    </div>
    </div>
</section>
    <!-- /.content -->
<script type="text/javascript">
$(function(){
	$('#datepicker').datetimepicker({
       format: 'YYYY-MM-DD'
     });
    $('#datepicker2').datetimepicker({
        format: 'YYYY-MM-DD'
    });
	$('#user-edit-form').validate({
		rules:{
			name:{
				required:true,
			}
		},
		messages:{
			name:{
				required:'Term is Required',	
			}
		}
	});
	$('#user-edit-form').ajaxForm({
		beforeSubmit:function(formData, jqForm, options){
			//return $('#user-edit-form').valid();
			$('#submitBtn').html("Saving!");
      		$('#submitBtn').prop('disabled', true);
		},
		success:function(responseText, statusText, xhr, form){
			$('#submitBtn').html("Save");
      	$('#submitBtn').prop('disabled', false);
			var json = $.parseJSON(responseText);
			if(json.success){
				toastr.success(json.msg);
				<?php
				if($id == ''){
					?>
					location.href = '#/admission_enquiry';
					<?php
				}else{
					?>
					location.href = '#/admission_enquiry';
					<?php
				}
				?>
			}else{
				toastr.error(json.msg);
			}
			return false;
		}
	});
})
</script>