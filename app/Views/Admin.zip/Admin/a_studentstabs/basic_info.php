  <?php echo form_open_multipart('c=a_students&m=save_basicinfo', 'role="form" id="students-edit-form-basicinfo"');
        echo form_hidden('id', $id);
        echo form_hidden('campus_id', $campus_id);
  ?>
      <input type="hidden" name="parent_id" id="parent_id" value="<?php echo $parent_id; ?>"  /> 
      <div class="row">     	
        <div class="col-lg-3">
          <div class="form-group">
            <label for="reg_no">Registration No</label>
            <input type="text" readonly class="form-control" name="reg_no" id="reg_no" value="<?php echo $reg_no;?>">
            <input type="hidden" id="originalreg_no" value="<?php echo $reg_no;?>">
          </div>
        </div>
        <div class="col-lg-3">
        <div class="form-group">
              <label for="first_name">First Name</label>
              <input type="text" class="form-control" name="first_name" id="first_name" value="<?php echo $first_name;?>">
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group">
              <label for="last_name">Last Name</label>
              <input type="text" class="form-control" name="last_name" id="last_name" value="<?php echo $last_name;?>">
            </div>
        </div>
			  <div class="col-lg-3">
            <div class="form-group" style="margin-bottom:23px;">
              <label for="gender">Gender</label>
              <br>
              <label>Male</label>
              <input type="radio" name="gender" value="male" <?php if($gender == "male"){ echo "checked"; } ?> >
              <label>Female</label>
              <input type="radio" name="gender" value="female" <?php if($gender == "female"){ echo "checked"; } ?> >
            </div>
        </div>
        <div class="col-lg-3">
            <div class="form-group">
              <label for="father_cnic">Father CNIC</label>
              <input type="text" class="form-control" name="father_cnic" id="father_cnic"  onkeyup="checkfathercnic()"  value="<?php echo $father_cnic;?>" data-inputmask='"mask": "99999-9999999-9"' data-mask>
            </div>
        </div>
        <div class="col-lg-3">
          <div class="form-group">
            <label for="f_first_name">Father Name</label>
            <input type="text" class="form-control" name="f_name" id="f_name" value="<?php echo $f_name;?>">
          </div>
        </div>
        <div class="col-lg-3">
        <div class="form-group">
          <label for="religion">Religion</label>
          <input type="text" class="form-control" name="religion" id="religion" value="<?php if(empty($religion)){ echo 'Islam';  }else{ echo $religion; }?>">
        </div>
        </div>
        <div class="col-lg-3">
            <?php 
              if(!empty($date_of_admission) && $date_of_admission != 0){
                $sec = strtotime($date_of_admission); 
                $date_of_admission = date("d/m/Y", $sec); 
              }else{  
                $date_of_admission = date('m/d/Y');         
              } 
            ?>
            <div class="form-group">
              <label>Date Of Admission</label>
              <div class="input-group date" id="datepicker2" data-target-input="nearest">
                <input type="text" class="form-control datetimepicker-input"  id="datepicker2" name="date_of_admission" required 
                value="<?php echo $date_of_admission; ?>" data-target="#datepicker2"/>
                <div class="input-group-append" data-target="#datepicker2" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
              </div>
              <!-- /.input group -->
              </div>
            </div>
     
      
      </div> 
      <div class="row">
      <div class="col-lg-12 noprint">
        <div class="form-group">
          <button type="submit" id="submitBtn" class="btn btn-primary studentsubmit">Save</button>
          <button type="reset" class="btn btn-default">Reset</button>
          <button type="button" class="btn btn-default" onclick="history.go(-1);">Cancel</button>
        </div>
      </div>
      </div>
    <?php echo form_close();?>
 <script>
$(function(){
 
  $('[data-mask]').inputmask();
  var dateNow = new Date();
  $('#datepicker').datetimepicker({
      format: 'L',
      defaultDate:moment(dateNow)
    });
  
  $('#datepicker2').datetimepicker({
      format: 'L'
    });

  $('#students-edit-form-basicinfo').validate({
    rules:{
      first_name:{
        required:true,
      },
      father_cnic:{
        required:true,
      }
    },
    messages:{
      father_cnic:{
        required:'father cnic No is Required',
      }
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    }
  });

  $('#students-edit-form-basicinfo').ajaxForm({
    beforeSubmit:function(formData, jqForm, options){
    return $('#students-edit-form-basicinfo').valid();
    $('#submitBtn').html("Ajax Request is Processing!");
    $('#submitBtn').prop('disabled', true);
   },
   success:function(responseText, statusText, xhr, form){
      $('#submitBtn').html("Submit");
      $('#submitBtn').prop('disabled', false);
      var json = $.parseJSON(responseText);
      console.log(json);
      if(json.success){
        toastr.success(json.msg);
        <?php
        if($id == ''){
          ?>
          location.href = '#/a_students?m=edit&id='+json.student_id;
          <?php
          }else{
          ?>
          location.href = '#/a_students?m=edit&id='+json.student_id;
          <?php
        }
        ?>
      }else{
        toastr.error(json.msg);
      }
      return false;
    }

});
});
</script>   