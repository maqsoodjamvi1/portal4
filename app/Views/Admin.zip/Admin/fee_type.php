<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>

<script src="<?php echo base_url();?>resource/adminlte/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>
               Fee Type
            </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo '#/';?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Fee Type</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-lg-12">
          <div class="card card-primary card-outline card-tabs">
          <div class="card-header p-0 pt-1 border-bottom-0">
			<ul class="nav nav-tabs">
				<li class="nav-item">
					<a class="nav-link active" href="<?php echo '#/fee_type';?>">Fee Type</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo '#/fee_type?m=add';?>">Add Fee Type</a>
				</li>
			</ul>
			<div class="card-body">
			<div class="col-lg-12">
              <table class="table table-striped table-bordered table-hover" id="users-datatable" width="100%">
					<thead>
						<tr>
							<th nowrap>#</th>
							<th nowrap>Fee Type Name</th>
							<th nowrap>Fee Type Detail</th>
							<th nowrap>Is Monthly</th>
							<th nowrap>Status</th>
						</tr>
					</thead>
					<tbody>
					</tbody>
				</table></div></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
<script src="<?php echo base_url();?>resource/bootstrap-switch/js/bootstrap-switch.min.js"></script> 
<script type="text/javascript">
$(function(){
	var table = $('#users-datatable').DataTable({
		deferRender: true,
		select:{
			style:'single',
			blurable: true
		},

		ajax:{
			url:'<?php echo site_url('c=fee_type&m=data');?>',
			type:'post',
			data:function(d){
				//d.csrf_test_name = $.cookie(CSRF_COOKIE_NAME);
			}
		},
		columns:[
			{
				data:'id',
				className:'select-checkbox',
				render:function(data, type, row){
					return data;
				}

			},

			{data:'fee_type_name'},
			{data:'fee_type_detail'},
			{
				data:'is_monthly_fee',
				render:function(data, type, row){
					var html = ''; 
					if(data == '1'){
						var html = 'Monthly'; 
					}else{
						var html = 'Other'; 
					}
					return html;	
					
				}
			},
			{
				data:'status',
				render:function(data, type, row){
				
					var status_1 = '';
					if(data == '1') status_1 = 'checked="checked"';
					return '<label class="switch"><input type="checkbox" ' + status_1 + ' class="switch-small switchchk"  data-on-text="Active" data-off-text="Diactive" data-table="fee_type" data-field="status" data-size="mini" data-pk="' + row.id + '" /></label>';
					
				}
			},
		],
		fnDrawCallback:function(oSettings){
			$(".switchchk").bootstrapSwitch({
				onSwitchChange:function(e, state){
				var fieldval = state;
				var $element = $(e.currentTarget);
				var tablename = $element.attr('data-table');
				var fieldname = $element.attr('data-field');
				var rowid = $element.attr('data-pk');
				if(fieldval){
					fieldval = 1;
				}else{
					fieldval = 0;
				}
				$.post( 
				   "<?php echo site_url('c=ajax&m=setfeetypestatus');?>",
				   {
					   act:'upsort',
					   tbname:tablename,
					   tbfield:fieldname,
					   tbfieldvalue:fieldval,
					   id:rowid//,
					   // csrf_test_name:$.cookie(CSRF_COOKIE_NAME)
				   
				   },
				   function(data){
					//alert(data);
					   if(data=='success'){
						   toastr.success('change success');
						   
					   }else{
						   toastr.error('change error');
					   }
				   }
				  );	
				}
			});			
		}

	});
});
</script>
<?= $this->endSection() ?>