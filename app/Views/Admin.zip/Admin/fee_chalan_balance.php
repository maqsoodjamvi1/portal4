<?= $this->extend('layouts/admin_template') ?>
<?= $this->section('content') ?>

<link rel="stylesheet" href="<?= base_url(); ?>resource/bootstrap-switch/css/bootstrap3/bootstrap-switch.min.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css" />

<!-- Content Header -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Balance</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= base_url('admin/dashboard') ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Balance</li>
        </ol>
      </div>
    </div>
  </div>
</section>

<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="card card-primary card-outline card-tabs">
        <div class="card-header p-0 pt-1 border-bottom-0">
          <div class="card-body">
            <div class="tab-content">
              <div class="row">

                <div class='col-md-5'>
                  <div class="form-group">
                    <label>Date Paid From:</label>
                    <div class="input-group date" id="datepicker" data-target-input="nearest">
                      <input type="text" class="form-control datetimepicker-input" data-target="#datepicker" name="paid_date_from" id="paid_date_from" required />
                      <div class="input-group-append" data-target="#datepicker" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class='col-md-5'>
                  <div class="form-group">
                    <label>Date Paid To:</label>
                    <div class="input-group date" id="datepicker2" data-target-input="nearest">
                      <input type="text" class="form-control datetimepicker-input" data-target="#datepicker2" name="paid_date_to" id="paid_date_to" required />
                      <div class="input-group-append" data-target="#datepicker2" data-toggle="datetimepicker">
                        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-lg-2">
                  <div class="form-group">
                    <button onclick="gettotalfee();" class="btn btn-primary btn-flat" style="margin-top: 27px;height: 30px;line-height: 11px;">View</button>
                  </div>
                </div>

                <div class="col-lg-12">
                  <div id="totalfeeinfo" style="float:left;"></div>
                </div>

                <div class='col-md-3'>
                  <div class="form-group">
                    <label>Fee Month:</label>
                    <input type='month' class="form-control" name="fee_month" id="fee_month" />
                  </div>
                </div>

                <div class='col-md-3'>
                  <div class="form-group">
                    <label>Fee Type:</label>
                    <select name="fee_type_id" id="fee_type_id" class="form-control">
                      <?php foreach ($fee_type as $feetypeinfo): ?>
                        <option value="<?= esc($feetypeinfo->fee_type_id) ?>"><?= esc($feetypeinfo->fee_type_name) ?></option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                </div>

                <div class='col-md-3'>
                  <div class="form-group">
                    <label>Fee Status:</label>
                    <select name="fee_status" id="fee_status" class="form-control">
                      <option value="paid">Paid</option>
                      <option value="unpaid">UnPaid</option>
                    </select>
                  </div>
                </div>

                <div class="col-lg-2">
                  <div class="form-group">
                    <button onclick="gettotalfeebymonth();" class="btn btn-primary btn-flat" style="margin-top: 27px;height: 30px;line-height: 11px;">View</button>
                  </div>
                </div>

                <div class="col-lg-12">
                  <div id="totalfeeinfobymonth"></div>
                </div>

              </div> <!-- /.row -->
            </div> <!-- /.tab-content -->
          </div> <!-- /.card-body -->
        </div> <!-- /.card-header -->
      </div> <!-- /.card -->
    </div>
  </div>
</section>

<!-- JS Scripts -->
<script src="<?= base_url(); ?>resource/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script src="<?= base_url(); ?>resource/js/jquery.autocomplete.js"></script>
<script>
function gettotalfeebymonth() {
  const fee_month = $("#fee_month").val();
  const fee_type_id = $("#fee_type_id").val();
  const fee_status = $("#fee_status").val();

  $.ajax({
    url: '<?= base_url('admin/fee-chalan-balance/get-total-fee-by-month') ?>',
    type: "POST",
    data: {
      fee_month,
      fee_type_id,
      fee_status
    },
    success: function (res) {
      $("#totalfeeinfobymonth").html(res);
    }
  });
}

function gettotalfee() {
  const paid_date_from = $("#paid_date_from").val();
  const paid_date_to = $("#paid_date_to").val();

  $.ajax({
    url: '<?= base_url('admin/fee-chalan-balance/get-total-fee') ?>',
    type: "POST",
    data: {
      paid_date_from,
      paid_date_to
    },
    success: function (res) {
      $("#totalfeeinfo").html(res);
    }
  });
}

$(function () {
  $('#datepicker').datetimepicker({ format: 'DD/MM/YYYY' });
  $('#datepicker2').datetimepicker({ format: 'DD/MM/YYYY' });
});
</script>

<?= $this->endSection() ?>
